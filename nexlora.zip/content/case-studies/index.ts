export type CaseStudy = {
  slug: string;
  meta: {
    industry: string;
    region: string;
    discipline: string;
    duration: string;
  };
  hero: {
    eyebrow: string;
    title: string;
    titleEm: string;
    sub: string;
  };
  challenge: { heading: string; body: string };
  approach: { heading: string; phases: { title: string; body: string }[] };
  outcome: { heading: string; body: string; metrics: { value: string; label: string }[] };
  reflection: { heading: string; body: string };
  related: string[];
};

export const fintechLoanAutomation: { en: CaseStudy; ar: CaseStudy } = {
  en: {
    slug: 'fintech-loan-automation',
    meta: { industry: 'Financial Services', region: 'United States', discipline: 'AI & Data Innovation', duration: '14 weeks' },
    hero: {
      eyebrow: 'Case Study · United States',
      title: 'How a US fintech cut loan',
      titleEm: 'processing time by 73%.',
      sub: 'A growth-stage US consumer lender was processing applications by hand at scale. The CFO wanted automation; the credit team wanted control. We delivered both — with an agentic AI underwriting system that runs in production today and processed every application in the second half of last year.'
    },
    challenge: {
      heading: 'The bottleneck was not the model. It was the workflow around the model.',
      body: 'When we arrived, the lender was originating around fifteen thousand loan applications a month. Each application was touched by between four and seven humans before a credit decision was issued, with an average end-to-end time of just under nine business days. The credit policy was sound, the data was reasonable, but the workflow had been built up over four years of compromise. Engineers had layered automations on automations; the credit team had added manual review steps after every fraud event; and nobody had stopped to redesign the system as a whole. The result was a process that was slow, expensive to operate, inconsistent across reviewers, and increasingly the reason customers were going to competitors.'
    },
    approach: {
      heading: 'We rebuilt the underwriting system as an orchestrated multi-agent workflow with humans at the decision points that mattered.',
      phases: [
        { title: 'Mapped the actual decision', body: 'In week one we sat with credit, fraud, ops, and engineering and mapped every decision the workflow was making. Many were not credit decisions at all — they were document chasing, tax-form reconciliation, and bank-statement parsing. The model was not the leverage; the orchestration was.' },
        { title: 'Built specialized agents for each task', body: 'Document intelligence agent for income verification. Bank-data normalization agent. Fraud-signal aggregator. Credit-policy agent that runs the actual underwriting rules. Each agent ran in isolation with its own evaluation harness. We knew exactly how each one performed before we connected them.' },
        { title: 'Kept humans where they earned their seat', body: 'Edge cases, policy exceptions, and any decision above a certain dollar threshold still went to human reviewers — but with the agents having done the assembly work. Reviewers stopped chasing documents and started actually underwriting.' },
        { title: 'Shipped to shadow before production', body: 'For six weeks the system ran in parallel with the human workflow on every application, with no customer-facing impact. We tracked agreement rates, edge cases, and false positives. Only when the deltas were boringly stable did we cut over to production for low-risk applications first, then expand.' }
      ]
    },
    outcome: {
      heading: 'The numbers were big, but the strategic outcome was bigger.',
      body: 'Within ten weeks of go-live, average loan processing time fell from 8.7 business days to 2.3. Cost per origination dropped by 61 percent. The credit team was reassigned from document chasing to portfolio analytics — work they were always supposed to be doing. Approval consistency, measured as variance across reviewers on identical files, improved by an order of magnitude.',
      metrics: [
        { value: '73%', label: 'Reduction in loan processing time' },
        { value: '$2.4M', label: 'Annual operational savings' },
        { value: '61%', label: 'Reduction in cost per origination' },
        { value: '14 wks', label: 'Kickoff to production' }
      ]
    },
    reflection: {
      heading: 'What we would tell another lender starting this work today.',
      body: 'Resist the temptation to start with the credit model. Most underwriting bottlenecks are workflow problems dressed up as modeling problems. Map the actual decisions before you touch the math. Build evaluation harnesses for every agent before you connect them. Run in shadow mode for longer than you think you need to. And keep humans where the leverage of judgment is highest — they are not the bottleneck; the work that surrounds them is.'
    },
    related: ['uk-retail-cloud-migration', 'gcc-proptech-launch']
  },
  ar: {
    slug: 'fintech-loan-automation',
    meta: { industry: 'الخدمات المالية', region: 'الولايات المتحدة', discipline: 'الذكاء الاصطناعي والبيانات', duration: '١٤ أسبوعاً' },
    hero: {
      eyebrow: 'قصة نجاح · الولايات المتحدة',
      title: 'كيف خفّضت شركة تقنية مالية أمريكية',
      titleEm: 'وقت معالجة القروض بنسبة ٧٣٪.',
      sub: 'شركة إقراض استهلاكية أمريكية في مرحلة نمو كانت تُعالج الطلبات يدوياً بأعداد كبيرة. أراد المدير المالي الأتمتة؛ وأراد فريق الائتمان السيطرة. سلّمنا الاثنين معاً — بنظام تقييم ائتماني مدفوع بوكلاء ذكاء اصطناعي يعمل اليوم في الإنتاج، وعالج كل طلب في النصف الثاني من العام الماضي.'
    },
    challenge: {
      heading: 'لم يكن النموذج هو عنق الزجاجة. بل سير العمل حوله.',
      body: 'عند وصولنا، كانت الشركة تُولّد نحو خمسة عشر ألف طلب قرض شهرياً. كل طلب يمرّ بين أربعة وسبعة أشخاص قبل صدور قرار ائتماني، بمتوسط زمن شامل يصل إلى تسعة أيام عمل تقريباً. كانت سياسة الائتمان سليمة، والبيانات معقولة، لكنّ سير العمل تراكم على مدى أربع سنوات من التسويات. أضاف المهندسون أتمتة فوق أتمتة؛ وأضاف فريق الائتمان خطوات مراجعة يدوية بعد كل حادثة احتيال؛ ولم يتوقف أحد لإعادة تصميم النظام كاملاً. النتيجة عملية بطيئة، مُكلفة التشغيل، متفاوتة بين المراجعين، وتحوّلت تدريجياً إلى السبب الذي يدفع العملاء نحو المنافسين.'
    },
    approach: {
      heading: 'أعدنا بناء نظام التقييم الائتماني كسير عمل متعدد الوكلاء مُنسَّق، مع وضع البشر عند نقاط القرار التي تستحق.',
      phases: [
        { title: 'رسم القرار الفعلي', body: 'في الأسبوع الأول جلسنا مع الائتمان والاحتيال والعمليات والهندسة، ورسمنا كل قرار يتخذه سير العمل. كثير منها لم يكن قرارات ائتمان أصلاً — بل ملاحقة مستندات وتسوية نماذج ضريبية وتحليل كشوف بنكية. النموذج لم يكن الرافعة؛ التنسيق كان.' },
        { title: 'بناء وكلاء متخصصين لكل مهمة', body: 'وكيل ذكاء مستندات لتحقّق الدخل. وكيل توحيد بيانات بنكية. مُجمّع إشارات احتيال. وكيل سياسة ائتمانية يُشغّل قواعد التقييم الفعلية. كل وكيل عمل في عزلة مع نظام تقييم خاص به. عرفنا أداء كل واحد بدقة قبل أن نربطها.' },
        { title: 'إبقاء البشر حيث يستحقون مقاعدهم', body: 'الحالات الحدّية والاستثناءات وأي قرار فوق عتبة دولار محددة بقيت للمراجعين البشريين — لكن بعدما أنجز الوكلاء عمل التجميع. توقّف المراجعون عن ملاحقة المستندات وبدأوا فعلاً في التقييم الائتماني.' },
        { title: 'الإطلاق في الظل قبل الإنتاج', body: 'لمدة ستة أسابيع شغّلنا النظام بالتوازي مع سير العمل البشري على كل طلب، دون أي تأثير على العميل. تتبّعنا معدلات التطابق والحالات الحدّية والإيجابيات الكاذبة. عندما أصبحت الفروق ثابتة بشكل ممل فقط، حوّلنا للإنتاج للطلبات منخفضة المخاطر أولاً، ثم وسّعنا.' }
      ]
    },
    outcome: {
      heading: 'كانت الأرقام كبيرة، لكنّ النتيجة الاستراتيجية أكبر.',
      body: 'خلال عشرة أسابيع من الإطلاق، انخفض متوسط وقت معالجة القرض من ٨.٧ إلى ٢.٣ أيام عمل. تراجعت تكلفة التوليد بنسبة ٦١٪. أُعيد تكليف فريق الائتمان من ملاحقة المستندات إلى تحليلات المحفظة — العمل الذي كان يُفترض بهم القيام به. تحسّنت اتساقية الموافقة، المُقاسة كتباين بين المراجعين على ملفات متطابقة، بمقدار رتبة كاملة.',
      metrics: [
        { value: '٧٣٪', label: 'تخفيض في وقت معالجة القرض' },
        { value: '٢.٤ مليون $', label: 'وفورات تشغيلية سنوية' },
        { value: '٦١٪', label: 'تخفيض في تكلفة التوليد' },
        { value: '١٤ أسبوعاً', label: 'من البدء إلى الإنتاج' }
      ]
    },
    reflection: {
      heading: 'ما سنُخبر به مُقرضاً آخر يبدأ هذا العمل اليوم.',
      body: 'قاوم إغراء البدء بنموذج الائتمان. معظم اختناقات التقييم الائتماني هي مشاكل سير عمل مُتنكّرة كمشاكل نمذجة. ارسم القرارات الفعلية قبل أن تلمس الرياضيات. ابنِ أنظمة تقييم لكل وكيل قبل ربطهم. شغّل في الوضع الظلّي مدة أطول مما تظن. وأبقِ البشر حيث رافعة الحكم أعلى — ليسوا عنق الزجاجة؛ بل العمل المحيط بهم.'
    },
    related: ['uk-retail-cloud-migration', 'gcc-proptech-launch']
  }
};

export const ukRetailCloudMigration: { en: CaseStudy; ar: CaseStudy } = {
  en: {
    slug: 'uk-retail-cloud-migration',
    meta: { industry: 'Retail', region: 'United Kingdom', discipline: 'Cloud & Infrastructure', duration: '90 days' },
    hero: {
      eyebrow: 'Case Study · United Kingdom',
      title: 'A UK retailer migrated 14',
      titleEm: 'legacy systems in 90 days.',
      sub: 'A British multi-channel retailer with a fragile colocation footprint and a 41 percent annual increase in cloud cost decided enough was enough. We compressed an estimated eighteen-month migration into ninety days, with zero downtime and a substantially lower cloud bill at the end.'
    },
    challenge: {
      heading: 'The cloud was the symptom. The architecture was the disease.',
      body: 'The retailer had spent four years on a half-finished cloud journey. The customer-facing storefront was on AWS; back-office finance, supply chain, and warehouse management were still on a legacy colo facility coming up for contract renewal. Recent attempts to migrate workloads had stalled because every system had grown its own bespoke integrations with everything else. Cloud spend was rising, on-prem reliability was falling, and the IT team was spending more time managing the gap between the two estates than running either of them well. With the colo contract expiring in six months and a board mandate to consolidate, they needed a partner who could move quickly, decisively, and without the eighteen-month transformation theater.'
    },
    approach: {
      heading: 'We compressed the migration by treating it as a single architectural change, not fourteen separate ones.',
      phases: [
        { title: 'Inventoried the estate honestly', body: 'In the first two weeks we built a single source of truth for every workload, dependency, integration, and data flow. Half the supposedly critical interconnections had been switched off years ago and nobody had noticed. Half of what they thought was simple turned out to have hidden coupling.' },
        { title: 'Designed the target as one architecture, not fourteen', body: 'A landing zone, a network topology, an identity model, a data platform — designed once, applied uniformly. Most failed migrations fail because each workload gets its own bespoke target. We refused that.' },
        { title: 'Migrated in waves, with a working rollback per wave', body: 'Three waves over ten weeks. Each wave moved a coherent set of workloads — never a single isolated system — with cutover tested in a staging environment first. Every wave had a documented rollback path that we actually rehearsed.' },
        { title: 'Decommissioned aggressively', body: 'After cutover, we shut down legacy systems within five business days. Not parked. Not archived. Powered off, with sign-off. Most stalled migrations stall because the old system stays alive too long.' }
      ]
    },
    outcome: {
      heading: 'The colocation contract was not renewed. The cloud bill went down.',
      body: 'All fourteen workloads were running in production on AWS within ninety days. The annualized cloud bill — including the workloads we migrated in — landed 41 percent lower than the prior combined cloud-plus-colo spend, driven by right-sizing, savings plans, and architectural changes that simply were not possible on the legacy infrastructure. Mean time to deployment for the back-office systems went from monthly to multiple times daily.',
      metrics: [
        { value: '14', label: 'Legacy systems migrated' },
        { value: '90', label: 'Days kickoff to cutover' },
        { value: '41%', label: 'Reduction in annualized cloud spend' },
        { value: '0', label: 'Hours of customer-facing downtime' }
      ]
    },
    reflection: {
      heading: 'What separates a 90-day migration from an 18-month one.',
      body: 'Three things. First, a single architecture across the whole estate — not a different target for each workload. Second, a relentless decommissioning discipline — old systems get shut down, not parked. Third, an honest inventory in week one — most migration plans are built on assumptions that fall apart on contact with reality, and the longer you wait to find out, the worse it gets.'
    },
    related: ['fintech-loan-automation', 'gcc-proptech-launch']
  },
  ar: {
    slug: 'uk-retail-cloud-migration',
    meta: { industry: 'التجزئة', region: 'المملكة المتحدة', discipline: 'السحابة والبنية التحتية', duration: '٩٠ يوماً' },
    hero: {
      eyebrow: 'قصة نجاح · المملكة المتحدة',
      title: 'شركة تجزئة بريطانية رحّلت ١٤',
      titleEm: 'نظاماً قديماً في ٩٠ يوماً.',
      sub: 'شركة تجزئة بريطانية متعددة القنوات ببصمة استضافة هشّة وزيادة سنوية بنسبة ٤١٪ في تكلفة السحابة قرّرت أن الكافي كافٍ. ضغطنا ترحيلاً مُقدّراً بثمانية عشر شهراً إلى تسعين يوماً، دون توقّف، وبفاتورة سحابية أقل بشكل ملموس في النهاية.'
    },
    challenge: {
      heading: 'كانت السحابة هي العَرَض. المعمارية كانت المرض.',
      body: 'أمضت الشركة أربع سنوات في رحلة سحابية نصف منتهية. كانت واجهة العميل على AWS؛ بينما المكاتب الخلفية للمالية وسلسلة الإمداد وإدارة المستودعات لا تزال في مركز استضافة قديم مع تجديد عقد قريب. توقّفت محاولات الترحيل الأخيرة لأن كل نظام طوّر تكاملات خاصة مع كل شيء آخر. الإنفاق السحابي يرتفع، موثوقية المحلي تنخفض، وفريق تقنية المعلومات يُمضي وقتاً في إدارة الفجوة بين البيئتين أكثر من تشغيل أيٍّ منهما جيداً. مع انتهاء عقد الاستضافة بعد ستة أشهر وتفويض من المجلس بالتوحيد، احتاجوا شريكاً يتحرّك بسرعة وحسم، دون مسرحية تحوّل لثمانية عشر شهراً.'
    },
    approach: {
      heading: 'ضغطنا الترحيل بمعاملته تغييراً معمارياً واحداً، لا أربعة عشر منفصلة.',
      phases: [
        { title: 'جرد المحفظة بصراحة', body: 'في الأسبوعين الأوّلين بنينا مصدر حقيقة واحداً لكل حمل وتبعية وتكامل وتدفق بيانات. نصف الاتصالات الحرجة المزعومة كانت مُطفأة قبل سنوات ولم يلاحظ أحد. ونصف ما ظنّوه بسيطاً تبيّن أن لديه ترابطاً خفياً.' },
        { title: 'تصميم الهدف كمعمارية واحدة، لا أربعة عشر', body: 'منطقة هبوط، طوبولوجيا شبكة، نموذج هوية، منصة بيانات — مُصمّمة مرة واحدة ومُطبَّقة بشكل موحَّد. معظم الترحيلات الفاشلة تفشل لأن كل حمل يحصل على هدف خاص. رفضنا ذلك.' },
        { title: 'الترحيل بموجات، مع تراجع عامل لكل موجة', body: 'ثلاث موجات على مدى عشرة أسابيع. حرّكت كل موجة مجموعة متماسكة من الأحمال — لا نظاماً منعزلاً واحداً — مع اختبار التحويل في بيئة تجريب أوّلاً. كل موجة كان لها مسار تراجع موثَّق تمرّنّا عليه فعلاً.' },
        { title: 'إيقاف التشغيل بصرامة', body: 'بعد التحويل، أطفأنا الأنظمة القديمة خلال خمسة أيام عمل. لم نتركها متوقفة. لم نأرشفها. مُغلَقة، بتوقيع. معظم الترحيلات المتعثّرة تتعثّر لأن النظام القديم يبقى حياً طويلاً.' }
      ]
    },
    outcome: {
      heading: 'لم يُجدَّد عقد الاستضافة. وانخفضت الفاتورة السحابية.',
      body: 'كانت كل الأحمال الأربعة عشر تعمل في الإنتاج على AWS خلال تسعين يوماً. الفاتورة السحابية السنوية — بما في ذلك الأحمال التي رحّلناها — جاءت أقل بنسبة ٤١٪ من الإنفاق المُجمَّع السابق سحابة-زائد-استضافة، مدفوعة بالتحجيم السليم وخطط الادّخار وتغييرات معمارية لم تكن ممكنة ببساطة على البنية القديمة. متوسط وقت النشر لأنظمة المكاتب الخلفية انتقل من شهري إلى عدة مرات يومياً.',
      metrics: [
        { value: '١٤', label: 'نظاماً قديماً تم ترحيله' },
        { value: '٩٠', label: 'يوماً من البدء إلى التحويل' },
        { value: '٤١٪', label: 'تخفيض في الإنفاق السحابي السنوي' },
        { value: '٠', label: 'ساعات توقّف يراها العميل' }
      ]
    },
    reflection: {
      heading: 'ما يفصل ترحيلاً في تسعين يوماً عن آخر في ثمانية عشر شهراً.',
      body: 'ثلاثة أشياء. أوّلاً، معمارية واحدة عبر المحفظة كاملة — لا هدف مختلف لكل حمل. ثانياً، انضباط إيقاف صارم — الأنظمة القديمة تُطفأ، لا تُترك متوقفة. ثالثاً، جرد صادق في الأسبوع الأوّل — معظم خطط الترحيل مبنيّة على افتراضات تنهار عند ملامسة الواقع، وكلّما تأخّرت في الاكتشاف، ساءت الأمور.'
    },
    related: ['fintech-loan-automation', 'gcc-proptech-launch']
  }
};

export const gccProptechLaunch: { en: CaseStudy; ar: CaseStudy } = {
  en: {
    slug: 'gcc-proptech-launch',
    meta: { industry: 'PropTech', region: 'Saudi Arabia', discipline: 'Product Engineering', duration: '6 months' },
    hero: {
      eyebrow: 'Case Study · Saudi Arabia',
      title: 'A Vision 2030-aligned',
      titleEm: 'PropTech reached 180K users in six months.',
      sub: 'A Riyadh-based founder set out to build the residential leasing platform Saudi Arabia did not have. The market was urgent, the regulation was new, and the founding team wanted to launch in six months without taking shortcuts that would haunt them later. We were the technology partner.'
    },
    challenge: {
      heading: 'A Vision 2030 timeline, a regulated market, a six-month deadline, and zero technical compromise.',
      body: 'Saudi Arabia\'s housing program under Vision 2030 had created a fast-moving market for digital residential services — but the existing solutions were built for older property workflows and did not handle the new regulatory regime, Arabic-first user expectations, or the cultural nuances of how Saudi households actually search for and lease homes. Our client had a sharp commercial thesis, capital, and a brand-new partnership with a major real-estate developer that wanted product live by the end of the fiscal year. They needed a platform that was beautiful, fast, fully Arabic, RTL-native, regulated, and ready to scale to the entire Kingdom — and they needed it in six months.'
    },
    approach: {
      heading: 'We treated the launch as a regulated product release, not a startup MVP.',
      phases: [
        { title: 'Discovery in Riyadh, with users, not in a slide deck', body: 'Two weeks on the ground with prospective tenants, landlords, brokers, and the regulator. We came back with a prioritized feature list that diverged from the founder\'s original spec on three significant points — and they were right to listen.' },
        { title: 'Design system built RTL-first', body: 'Every component, every interaction, every animation designed for Arabic right-to-left from the start, with English as a second-class citizen. The result was a product that felt native to Saudi users — not a Western product wearing Arabic translation.' },
        { title: 'Architecture for regulatory and scale', body: 'Data residency in-Kingdom from day one. Identity verification through Absher and Nafath. Lease contracts that satisfied both Ejar and our client\'s legal counsel. KYC, AML, and PDPL compliance baked into the platform, not bolted on.' },
        { title: 'Phased launch driven by demand, not by sprints', body: 'A waitlist-driven soft launch in week sixteen. A neighborhood-by-neighborhood expansion that let us learn from each cohort. The full Kingdom rollout completed in week twenty-two — two weeks ahead of the deadline.' }
      ]
    },
    outcome: {
      heading: 'A platform that locals actually use, at a scale that matters.',
      body: 'The product reached 180,000 registered users in six months from launch. Conversion from search to lease enquiry ran at 47 percent above industry benchmarks the team had set. The platform achieved full Ejar integration, was certified by NCA, and is now the default product for the developer partner\'s twelve-thousand-unit residential portfolio. Most importantly: every architectural decision we made in month one held up under load — no rewrites, no emergency re-platforming, no regret.',
      metrics: [
        { value: '180K', label: 'Registered users at six months' },
        { value: '47%', label: 'Above-benchmark conversion' },
        { value: '6mo', label: 'Idea to live deployment' },
        { value: '99.95%', label: 'Uptime in first 90 days post-launch' }
      ]
    },
    reflection: {
      heading: 'Building for the GCC is not building for the West with translation.',
      body: 'The companies that win in the Gulf are not the ones that translate Western products into Arabic. They are the ones that design from the local user experience outward, that respect the regulator as a real stakeholder, and that build for the cultural patterns of how local people actually transact. Vision 2030 is not a marketing slogan — it is a real, well-funded national program with timelines that move fast and reward partners who can keep up.'
    },
    related: ['fintech-loan-automation', 'uk-retail-cloud-migration']
  },
  ar: {
    slug: 'gcc-proptech-launch',
    meta: { industry: 'العقارات الرقمية', region: 'المملكة العربية السعودية', discipline: 'هندسة المنتجات', duration: '٦ أشهر' },
    hero: {
      eyebrow: 'قصة نجاح · المملكة العربية السعودية',
      title: 'منصة عقارية تقنية متوافقة مع رؤية ٢٠٣٠',
      titleEm: 'وصلت إلى ١٨٠ ألف مستخدم في ستة أشهر.',
      sub: 'مؤسس مقيم في الرياض شرع في بناء منصة التأجير السكني التي لم تكن المملكة تمتلكها. كان السوق عاجلاً، والتنظيم جديداً، والفريق المؤسس أراد الإطلاق في ستة أشهر دون اختصارات ستُلاحقه لاحقاً. كنّا الشريك التقني.'
    },
    challenge: {
      heading: 'مهلة رؤية ٢٠٣٠، سوق منظَّم، موعد نهائي ستة أشهر، وصفر تنازل تقني.',
      body: 'برنامج الإسكان السعودي ضمن رؤية ٢٠٣٠ خلق سوقاً سريع الحركة للخدمات السكنية الرقمية — لكنّ الحلول القائمة كانت مبنيّة لسير عمل عقاري قديم ولم تتعامل مع النظام التنظيمي الجديد، أو توقّعات المستخدم العربي أوّلاً، أو الفروق الثقافية في طريقة بحث الأسر السعودية فعلاً عن المساكن واستئجارها. كان عميلنا يمتلك أطروحة تجارية حادّة، ورأس مال، وشراكة جديدة تماماً مع مُطوّر عقاري كبير يُريد إطلاق المنتج بحلول نهاية السنة المالية. احتاجوا منصة جميلة وسريعة وعربية بالكامل وأصلية في RTL ومُنظَّمة وجاهزة للتوسّع في المملكة كاملة — في ستة أشهر.'
    },
    approach: {
      heading: 'تعاملنا مع الإطلاق كإصدار منتج منظَّم، لا كمشروع MVP لشركة ناشئة.',
      phases: [
        { title: 'الاستكشاف في الرياض، مع المستخدمين، لا في عرض شرائح', body: 'أسبوعان على الأرض مع المستأجرين المحتملين والمالكين والوسطاء والمنظِّم. عُدنا بقائمة ميزات مُرتَّبة الأولويات تخالف مواصفة المؤسس الأصلية في ثلاث نقاط مهمة — وأحسنوا بالاستماع.' },
        { title: 'نظام تصميم مبنيّ من اليمين إلى اليسار أوّلاً', body: 'كل مكوّن، كل تفاعل، كل حركة مُصمَّمة للعربية من اليمين إلى اليسار من البداية، مع الإنجليزية كمواطن من الدرجة الثانية. النتيجة منتج شعر المستخدمون السعوديون أنه أصلي — لا منتج غربي يرتدي ترجمة عربية.' },
        { title: 'معمارية للتنظيم والتوسّع', body: 'إقامة بيانات داخل المملكة من اليوم الأول. تحقّق هوية عبر أبشر ونفاذ. عقود إيجار تُرضي إيجار والمستشارين القانونيين للعميل. KYC وAML وامتثال PDPL مدمج في المنصة، لا مُلصَق.' },
        { title: 'إطلاق مرحلي مدفوع بالطلب، لا بالسبرنتات', body: 'إطلاق هادئ مدفوع بقائمة انتظار في الأسبوع السادس عشر. توسّع حيّاً تلو حيّ سمح لنا بالتعلّم من كل دفعة. اكتمل الانتشار في المملكة كاملة بحلول الأسبوع الثاني والعشرين — أسبوعين قبل الموعد.' }
      ]
    },
    outcome: {
      heading: 'منصة يستخدمها المحليون فعلاً، بمقياس يُحدث فرقاً.',
      body: 'وصل المنتج إلى ١٨٠ ألف مستخدم مُسجَّل في ستة أشهر من الإطلاق. التحويل من البحث إلى استفسار التأجير جرى بمعدل ٤٧٪ فوق المعايير الصناعية التي وضعها الفريق. حقّقت المنصة تكاملاً كاملاً مع إيجار، وحصلت على شهادة NCA، وأصبحت الآن المنتج الافتراضي لمحفظة المُطوّر الشريك السكنية البالغة اثني عشر ألف وحدة. والأهم: كل قرار معماري اتخذناه في الشهر الأوّل صمد تحت الحمل — لا إعادة كتابة، لا إعادة بناء طارئة، لا ندم.',
      metrics: [
        { value: '١٨٠ ألف', label: 'مستخدم مُسجَّل في ستة أشهر' },
        { value: '٤٧٪', label: 'فوق معايير التحويل' },
        { value: '٦ أشهر', label: 'من الفكرة إلى النشر الفعلي' },
        { value: '٩٩.٩٥٪', label: 'وقت تشغيل في أوّل ٩٠ يوماً' }
      ]
    },
    reflection: {
      heading: 'البناء للخليج ليس البناء للغرب مع الترجمة.',
      body: 'الشركات التي تفوز في الخليج ليست تلك التي تُترجم منتجاتها الغربية إلى العربية. بل تلك التي تُصمّم من تجربة المستخدم المحلية إلى الخارج، وتحترم المنظِّم كصاحب مصلحة حقيقي، وتبني وفق الأنماط الثقافية لكيفية تعامل الناس المحليين فعلاً. رؤية ٢٠٣٠ ليست شعاراً تسويقياً — بل برنامج وطني حقيقي بتمويل قوي ومواعيد تتحرّك بسرعة وتُكافئ الشركاء القادرين على المواكبة.'
    },
    related: ['fintech-loan-automation', 'uk-retail-cloud-migration']
  }
};

export const caseStudies = {
  'fintech-loan-automation': fintechLoanAutomation,
  'uk-retail-cloud-migration': ukRetailCloudMigration,
  'gcc-proptech-launch': gccProptechLaunch
} as const;

export type CaseStudySlug = keyof typeof caseStudies;
export const caseStudySlugs = Object.keys(caseStudies) as CaseStudySlug[];

export function getCaseStudy(slug: CaseStudySlug, locale: 'en' | 'ar'): CaseStudy {
  return caseStudies[slug][locale];
}
