export type ServiceContent = {
  slug: string;
  hero: { eyebrow: string; title: string; titleEm: string; titleEnd: string; sub: string };
  intro: { heading: string; body: string };
  pillars: { num: string; title: string; body: string }[];
  offerings: { name: string; description: string }[];
  outcomes: { metric: string; label: string }[];
  process: { phase: string; title: string; body: string }[];
  techStack: string[];
  industries: string[];
  faqs: { q: string; a: string }[];
  cta: { heading: string; sub: string };
};

export const aiData: { en: ServiceContent; ar: ServiceContent } = {
  en: {
    slug: 'ai-data-innovation',
    hero: {
      eyebrow: 'AI & Data Innovation',
      title: 'Turn your data into',
      titleEm: 'decisions that win deals.',
      titleEnd: '',
      sub: 'Most companies have more data than they can use, less intelligence than they need, and AI ambition that lives in slide decks. We change that — by deploying production-grade AI agents, ML models, and decisioning systems that drive measurable revenue, margin, and operational outcomes inside ninety days.'
    },
    intro: {
      heading: 'AI is not a feature. It is the operating system underneath your next decade.',
      body: 'The companies pulling ahead right now are not the ones with the biggest AI budgets. They are the ones who have stopped treating AI as a science experiment and started treating it as core infrastructure — embedded in how they sell, serve, build, and decide. We help you become one of them. Not with another proof of concept that dies in a sandbox, but with deployed systems that run in production, learn from your data, and produce numbers your CFO can defend in a board meeting.'
    },
    pillars: [
      {
        num: '01',
        title: 'Agents that do the work, not demos that talk about it',
        body: 'We build autonomous agents that handle real workflows end to end — research, outreach, support, underwriting, claims, document processing — with human-in-the-loop oversight where it matters and full automation where it does not. These are not chatbots dressed up as agents. They have memory, they have tools, they have guardrails, and they ship work.'
      },
      {
        num: '02',
        title: 'Machine learning that survives contact with production',
        body: 'Predictive models for demand, churn, fraud, pricing, risk — built with the boring discipline of feature stores, drift monitoring, A/B testing, and shadow deployments. The model is the easy part. Keeping it accurate at month nine when your data has shifted is the part most teams miss. We do not.'
      },
      {
        num: '03',
        title: 'Generative AI strategy that does not embarrass you',
        body: 'Where to use foundation models, where to fine-tune, where to use retrieval, and where to leave the technology alone. We help you choose, with hard numbers on cost, latency, accuracy, and risk — and then we build it so it actually works on your data, not on a benchmark.'
      },
      {
        num: '04',
        title: 'Data engineering that earns the AI conversation',
        body: 'No serious AI work happens on top of unreliable data. We build the pipelines, lakehouses, and feature stores that make every downstream AI initiative cheaper, faster, and more accurate. Boring? Maybe. Critical? Always.'
      },
      {
        num: '05',
        title: 'MLOps so your models do not silently rot',
        body: 'Deployment, monitoring, retraining, governance — the unglamorous work that separates pilot projects from production systems. We set up the rails so your data and ML teams can ship with confidence and so your compliance team can sleep at night.'
      }
    ],
    offerings: [
      { name: 'Agentic AI Systems', description: 'Multi-agent orchestrations for sales, support, ops, and research workflows. Built on the latest model APIs with tool use, memory, and human review.' },
      { name: 'Predictive ML Models', description: 'Demand forecasting, churn prediction, fraud detection, dynamic pricing, lead scoring — production models with monitored accuracy.' },
      { name: 'GenAI Applications', description: 'RAG over your knowledge base, document intelligence, copilot interfaces, content generation pipelines — wired to your actual systems.' },
      { name: 'Computer Vision', description: 'Inspection, quality control, OCR, document understanding, security and surveillance — deployed on edge or cloud.' },
      { name: 'Data Platform Engineering', description: 'Lakehouse architectures on Databricks, Snowflake, BigQuery — pipelines, transformations, governance, lineage.' },
      { name: 'MLOps & AI Governance', description: 'CI/CD for models, drift monitoring, evaluation harnesses, prompt management, model risk frameworks aligned to regulatory expectations.' },
      { name: 'AI Readiness Assessment', description: 'A two-week deep dive into your data estate, use cases, and team — with a prioritized roadmap and clear dollar estimates.' },
      { name: 'Custom Model Development', description: 'Fine-tuning, distillation, and from-scratch training where the economics justify it — with proper evaluation, not vibes.' }
    ],
    outcomes: [
      { metric: '73%', label: 'Reduction in loan processing time at a US fintech' },
      { metric: '$2.4M', label: 'Annual operational savings from one AI decisioning engine' },
      { metric: '4.2×', label: 'Increase in qualified pipeline from agentic outbound' },
      { metric: '11 weeks', label: 'Average time from kickoff to production deployment' }
    ],
    process: [
      { phase: 'Discover', title: 'Find the leverage', body: 'We do not start with the model. We start with the decision the model is supposed to inform — and the dollar value of getting it right or wrong. If we cannot draw a line from the AI to the P&L in week one, we do not build it.' },
      { phase: 'Architect', title: 'Design for production from day zero', body: 'Data flow, model architecture, evaluation harness, deployment topology, governance — all decided up front, with you in the room. No big reveals later.' },
      { phase: 'Build', title: 'Ship fast, ship correctly', body: 'Two-week sprints. Working systems, not slideware. We deploy to a shadow environment within four weeks and run side by side with your existing process so you can see the deltas yourself.' },
      { phase: 'Measure', title: 'Numbers, not narratives', body: 'We track the metrics we promised in week one. Monthly business reviews, not quarterly excuses. If the model is not earning its keep, we say so.' },
      { phase: 'Scale', title: 'From one win to a portfolio', body: 'Once one use case is generating measurable value, we help you build the internal capability to ship the next ten — with us, with your team, or with both.' }
    ],
    techStack: ['Anthropic Claude', 'OpenAI', 'Llama', 'LangChain', 'Pinecone', 'Weaviate', 'Databricks', 'Snowflake', 'BigQuery', 'AWS Bedrock', 'Azure OpenAI', 'Vertex AI', 'PyTorch', 'TensorFlow', 'MLflow', 'Weights & Biases', 'Airflow', 'dbt', 'Kafka', 'Ray'],
    industries: ['Financial Services', 'Healthcare', 'Retail & E-commerce', 'Real Estate', 'Energy', 'Government', 'Logistics', 'SaaS'],
    faqs: [
      { q: 'How fast can you ship a real AI system into production?', a: 'For a focused use case with clean data, eight to twelve weeks from kickoff to live deployment is realistic. The variable is your data, not our speed. We do an honest assessment in week one.' },
      { q: 'Do we need to be on a specific cloud?', a: 'No. We build cloud-native on AWS, Azure, and GCP, and we are pragmatic about hybrid where regulation or latency demand it. We will not push you off your current cloud just because we prefer another.' },
      { q: 'What about data privacy and IP?', a: 'Your data and your model weights are yours. We sign aggressive NDAs, work in your environments where required, and architect for data residency in the UK and Gulf where the regulation demands it.' },
      { q: 'Can you work alongside our internal data science team?', a: 'That is our preferred model. We bring senior engineering muscle and production discipline; your team brings domain knowledge. Everything we build is documented, transferable, and yours to extend.' },
      { q: 'What if the AI does not work?', a: 'Then we say so. Some problems are not AI problems. We will not build a model that is going to disappoint you just because the budget exists. Discovery is designed to kill bad ideas early.' }
    ],
    cta: {
      heading: 'Stop running AI experiments. Start running AI systems.',
      sub: 'Book a thirty-minute call. Tell us where you are. We will tell you, honestly, whether AI is the answer and what it would actually take to get there.'
    }
  },
  ar: {
    slug: 'ai-data-innovation',
    hero: {
      eyebrow: 'الذكاء الاصطناعي والبيانات',
      title: 'حوّل بياناتك إلى',
      titleEm: 'قرارات تكسب الصفقات.',
      titleEnd: '',
      sub: 'معظم الشركات تمتلك بيانات أكثر مما تستخدم، وذكاءً أقل مما تحتاج، وطموحات للذكاء الاصطناعي تعيش في عروض شرائح. نحن نُغيّر هذه المعادلة — بتصميم وكلاء ذكاء اصطناعي ونماذج تعلّم آلي وأنظمة قرار جاهزة للإنتاج، تُحقق نتائج قابلة للقياس على الإيراد والهامش والعمليات خلال تسعين يوماً.'
    },
    intro: {
      heading: 'الذكاء الاصطناعي ليس ميزة. بل نظام التشغيل لعقدك القادم.',
      body: 'الشركات التي تتقدم اليوم ليست تلك التي تمتلك أكبر ميزانيات للذكاء الاصطناعي. بل تلك التي توقفت عن التعامل معه كتجربة علمية، وبدأت تعامله كبنية تحتية أساسية — مدمجة في طريقة بيعها وخدمتها وبنائها واتخاذها للقرار. نحن نُساعدك لتصبح واحدة منها. ليس بنموذج أوّلي آخر يموت في بيئة تجريبية، بل بأنظمة منشورة تعمل في الإنتاج، تتعلم من بياناتك، وتُنتج أرقاماً يستطيع مديرك المالي الدفاع عنها أمام مجلس الإدارة.'
    },
    pillars: [
      { num: '01', title: 'وكلاء يُنجزون العمل، لا عروض تتحدث عنه', body: 'نُصمم وكلاء مستقلين يُديرون مهام حقيقية من البداية إلى النهاية — البحث، التواصل، الدعم، التقييم الائتماني، معالجة المطالبات، فهم المستندات — مع إشراف بشري حيث يلزم وأتمتة كاملة حيث لا يلزم. ليست روبوتات محادثة بثوب وكلاء. لديها ذاكرة، ولديها أدوات، ولديها ضوابط، وتُنجز العمل.' },
      { num: '02', title: 'تعلّم آلي يصمد عند الإنتاج', body: 'نماذج تنبؤية للطلب والاستبقاء والاحتيال والتسعير والمخاطر — مبنية بانضباط هندسي يشمل مخازن الميزات ومراقبة الانحراف واختبارات A/B والنشر الظلّي. النموذج هو الجزء السهل. الإبقاء عليه دقيقاً في الشهر التاسع عندما تتغير بياناتك هو الجزء الذي تُغفله معظم الفرق. نحن لا نُغفله.' },
      { num: '03', title: 'استراتيجية ذكاء توليدي لا تُحرجك', body: 'متى تستخدم النماذج الأساسية، ومتى تُعدّلها، ومتى تستخدم الاسترجاع، ومتى تترك التقنية جانباً. نُساعدك على الاختيار بأرقام واضحة عن التكلفة والكمون والدقة والمخاطرة — ثم نبنيها لتعمل فعلاً على بياناتك، لا على معايير اختبار.' },
      { num: '04', title: 'هندسة بيانات تستحق الحديث عن الذكاء الاصطناعي', body: 'لا يوجد عمل جدّي للذكاء الاصطناعي فوق بيانات غير موثوقة. نبني خطوط الأنابيب وبحيرات-المنازل ومخازن الميزات التي تجعل كل مبادرة ذكاء اصطناعي لاحقة أرخص وأسرع وأدق. مملّ؟ ربما. حيوي؟ دائماً.' },
      { num: '05', title: 'MLOps حتى لا تتعفّن نماذجك بصمت', body: 'النشر، المراقبة، إعادة التدريب، الحوكمة — العمل غير البرّاق الذي يفصل المشاريع التجريبية عن أنظمة الإنتاج. نُجهّز السكك ليُسلّم فريق البيانات لديك بثقة، ولينام فريق الالتزام مرتاحاً.' }
    ],
    offerings: [
      { name: 'أنظمة وكلاء الذكاء الاصطناعي', description: 'تنسيقات متعددة الوكلاء لمهام البيع والدعم والعمليات والبحث. مبنية على أحدث واجهات النماذج، مع استخدام الأدوات والذاكرة والمراجعة البشرية.' },
      { name: 'نماذج تعلّم آلي تنبؤية', description: 'التنبؤ بالطلب، التنبؤ بالاستبقاء، كشف الاحتيال، التسعير الديناميكي، تقييم العملاء المحتملين — نماذج إنتاج بدقة مُراقَبة.' },
      { name: 'تطبيقات الذكاء التوليدي', description: 'استرجاع معزّز فوق قاعدة معرفتك، ذكاء المستندات، واجهات مساعدة، خطوط إنتاج المحتوى — متصلة بأنظمتك الفعلية.' },
      { name: 'الرؤية الحاسوبية', description: 'الفحص، ضبط الجودة، التعرف الضوئي، فهم المستندات، الأمن والمراقبة — منشورة على الحافة أو السحابة.' },
      { name: 'هندسة منصات البيانات', description: 'بنى Lakehouse على Databricks وSnowflake وBigQuery — خطوط أنابيب، تحويلات، حوكمة، تتبع نسب البيانات.' },
      { name: 'MLOps وحوكمة الذكاء الاصطناعي', description: 'CI/CD للنماذج، مراقبة الانحراف، أنظمة التقييم، إدارة المُحفّزات، أُطر مخاطر النماذج المتوافقة مع التوقعات التنظيمية.' },
      { name: 'تقييم جاهزية الذكاء الاصطناعي', description: 'تحليل عميق لمدة أسبوعين لأصول البيانات وحالات الاستخدام والفريق — مع خارطة طريق مرتّبة الأولويات وتقديرات مالية واضحة.' },
      { name: 'تطوير نماذج مخصصة', description: 'الضبط الدقيق والتقطير والتدريب من الصفر حيث تُبرّر الجدوى الاقتصادية ذلك — مع تقييم جدّي، لا انطباعات.' }
    ],
    outcomes: [
      { metric: '٧٣٪', label: 'تقليل وقت معالجة القروض في شركة تقنية مالية أمريكية' },
      { metric: '٢.٤ مليون $', label: 'وفورات تشغيلية سنوية من محرّك قرار واحد بالذكاء الاصطناعي' },
      { metric: '٤.٢×', label: 'زيادة في خط الأنابيب المؤهَّل من التواصل الصادر بالوكلاء' },
      { metric: '١١ أسبوعاً', label: 'متوسط الوقت من بدء المشروع إلى النشر الإنتاجي' }
    ],
    process: [
      { phase: 'الاستكشاف', title: 'اعثر على الرافعة', body: 'لا نبدأ بالنموذج. نبدأ بالقرار الذي يُفترض أن يُسانده النموذج — وقيمته المالية في حالة الإصابة أو الإخفاق. إذا لم نتمكن من رسم خط من الذكاء الاصطناعي إلى قائمة الأرباح في الأسبوع الأول، فلن نبنيه.' },
      { phase: 'التصميم', title: 'صمّم للإنتاج من اليوم الصفر', body: 'تدفّق البيانات، معمارية النموذج، أنظمة التقييم، طوبولوجيا النشر، الحوكمة — كلها تُحسم مسبقاً وأنت في الغرفة. لا مفاجآت لاحقاً.' },
      { phase: 'البناء', title: 'سلّم بسرعة، وسلّم بصواب', body: 'سبرنتات أسبوعين. أنظمة عاملة، لا شرائح. ننشر في بيئة ظلّية خلال أربعة أسابيع، ونُشغّلها بالتوازي مع عمليتك الحالية لترى الفرق بنفسك.' },
      { phase: 'القياس', title: 'أرقام، لا روايات', body: 'نتتبّع المقاييس التي وعدنا بها في الأسبوع الأول. مراجعات أعمال شهرية، لا أعذار فصلية. إذا لم يُحقّق النموذج عائده، فسنقولها صراحةً.' },
      { phase: 'التوسّع', title: 'من فوز واحد إلى محفظة', body: 'حالما تُحقّق حالة استخدام واحدة قيمة قابلة للقياس، نُساعدك على بناء القدرة الداخلية لتسليم العشر التالية — معنا، أو مع فريقك، أو معاً.' }
    ],
    techStack: ['Anthropic Claude', 'OpenAI', 'Llama', 'LangChain', 'Pinecone', 'Weaviate', 'Databricks', 'Snowflake', 'BigQuery', 'AWS Bedrock', 'Azure OpenAI', 'Vertex AI', 'PyTorch', 'TensorFlow', 'MLflow', 'Weights & Biases', 'Airflow', 'dbt', 'Kafka', 'Ray'],
    industries: ['الخدمات المالية', 'الرعاية الصحية', 'التجزئة والتجارة الإلكترونية', 'العقارات', 'الطاقة', 'الحكومة', 'اللوجستيات', 'البرمجيات كخدمة'],
    faqs: [
      { q: 'كم تستغرقون لإطلاق نظام ذكاء اصطناعي حقيقي للإنتاج؟', a: 'لحالة استخدام مُركَّزة ببيانات نظيفة، من ثمانية إلى اثني عشر أسبوعاً من الانطلاق إلى النشر الفعلي أمر واقعي. المتغير هو بياناتك، لا سرعتنا. نُجري تقييماً صادقاً في الأسبوع الأول.' },
      { q: 'هل يجب أن نكون على سحابة محددة؟', a: 'لا. نبني بشكل سحابي على AWS وAzure وGCP، ونتعامل بمرونة مع البنى الهجينة حيث تتطلّب التنظيمات أو الكمون ذلك. لن ندفعك لمغادرة سحابتك الحالية لمجرد تفضيلنا غيرها.' },
      { q: 'ماذا عن خصوصية البيانات والملكية الفكرية؟', a: 'بياناتك وأوزان نماذجك ملكك. نُوقّع اتفاقيات سرية صارمة، نعمل في بيئاتك حيث يلزم، ونُصمّم لإقامة البيانات في المملكة المتحدة والخليج حيث يفرض التنظيم ذلك.' },
      { q: 'هل يمكنكم العمل مع فريق البيانات الداخلي لدينا؟', a: 'هذا نموذجنا المفضّل. نُحضر العضلات الهندسية الكبيرة وانضباط الإنتاج؛ يُحضر فريقك المعرفة العميقة بالمجال. كل ما نبنيه موثّق وقابل للنقل وملك لكم.' },
      { q: 'ماذا لو لم ينجح الذكاء الاصطناعي؟', a: 'فسنقول ذلك. بعض المشكلات ليست مشكلات ذكاء اصطناعي. لن نبني نموذجاً سيُخيّب أملك لمجرد توفّر الميزانية. الاستكشاف مُصمَّم لقتل الأفكار السيئة مبكراً.' }
    ],
    cta: {
      heading: 'توقّف عن تجارب الذكاء الاصطناعي. ابدأ بأنظمة الذكاء الاصطناعي.',
      sub: 'احجز اجتماعاً لمدة ثلاثين دقيقة. أخبرنا أين أنت. سنُخبرك بصراحة ما إذا كان الذكاء الاصطناعي هو الإجابة، وما الذي يتطلّبه فعلياً للوصول.'
    }
  }
};
