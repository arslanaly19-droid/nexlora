import type { ServiceContent } from './ai-data';

export const cybersecurity: { en: ServiceContent; ar: ServiceContent } = {
  en: {
    slug: 'cybersecurity',
    hero: {
      eyebrow: 'Cybersecurity',
      title: 'Security that protects',
      titleEm: 'the business, not the policy.',
      titleEnd: '',
      sub: 'Threat-led, identity-first, and pragmatic. We build security programs that reduce real risk, satisfy real auditors, and let your engineering teams move at full speed. No theater, no shelfware, no scoring rubrics that make you look good and your customers exposed.'
    },
    intro: {
      heading: 'Security teams that say no are easy to find. Security teams that figure out how to say yes are not.',
      body: 'Most security programs are built to pass audits, not to stop attackers. Most security teams are measured on tickets closed and compliance scores hit, not on dwell time, blast radius, or business outcomes. We do it differently. Our security work is led by people who have run blue teams, red teams, and incident bridges at companies you have heard of — and who know the difference between a control that reduces risk and a control that reduces liability. Both matter. They are not the same.'
    },
    pillars: [
      { num: '01', title: 'Threat-led, not framework-led', body: 'We start with the actual threats your business faces — given your industry, your data, your geography, and the adversaries that target your peers — not with a generic NIST mapping. Frameworks are how we report. Threats are how we decide.' },
      { num: '02', title: 'Identity is the new perimeter, so we treat it like one', body: 'Modern attacks do not breach the firewall — they log in. Our work centers on identity governance, conditional access, secrets, machine identity, and the workflows that make least-privilege something engineers can actually live with.' },
      { num: '03', title: 'Compliance as a byproduct, not the product', body: 'SOC 2, ISO 27001, PCI-DSS, HIPAA, NCA-ECC, SAMA, GDPR — we deliver them as outputs of a real security program, not as the entire program. Audits become routine, not annual emergencies.' },
      { num: '04', title: 'Detection and response that does not depend on heroes', body: 'Engineered detections aligned to MITRE ATT&CK, automated triage, runbook-driven response. So your one excellent analyst does not become the single point of failure for the entire company.' },
      { num: '05', title: 'Security that the developer experience does not hate', body: 'Paved roads, secure-by-default templates, automated checks, friendly tooling. If we make the secure path the easy path, engineers do the right thing without being policed.' }
    ],
    offerings: [
      { name: 'Cybersecurity Strategy & Assessment', description: 'A senior-led review of your current posture, threat landscape, and roadmap. Delivers a written, board-ready strategy with prioritized investments.' },
      { name: 'Identity & Access Management', description: 'Modernization of IAM, PAM, and IGA — workforce, customer, and machine identity. Single sign-on, MFA, conditional access, just-in-time access, secrets management.' },
      { name: 'Cloud Security', description: 'CSPM, CIEM, container and Kubernetes security, runtime protection. Built into CI/CD so security findings are fixed before merge, not after audit.' },
      { name: 'Application Security', description: 'SDLC integration, SAST/DAST/SCA pipelines, secure code reviews, threat modeling, dependency hygiene. Security as a feature of the engineering platform.' },
      { name: 'Detection & Response Engineering', description: 'SIEM, SOAR, EDR, XDR — engineered, tuned, and automated. Threat hunts, purple-team exercises, incident response retainers.' },
      { name: 'Governance, Risk & Compliance', description: 'Framework selection, control mapping, evidence automation, vendor risk, board reporting. We translate security into business language and back.' },
      { name: 'Penetration Testing & Red Team', description: 'Application, infrastructure, and adversary-emulation engagements. Findings tied to remediation guidance and re-tested after fix. We do not ship a PDF and walk away.' },
      { name: 'Incident Response & Forensics', description: 'Retained or on-demand. Senior responders who have run actual incidents, not just simulations. Containment, eradication, recovery, and the hard conversation with the board.' }
    ],
    outcomes: [
      { metric: '14 days', label: 'Average time from kickoff to a working board-level risk view' },
      { metric: '92%', label: 'Reduction in critical findings open older than 30 days' },
      { metric: 'SOC 2 Type II', label: 'Achieved on a 9-month timeline for a Series-B SaaS' },
      { metric: '24/7', label: 'Senior incident response retainer, with named lead engineers' }
    ],
    process: [
      { phase: 'Assess', title: 'Honest baseline', body: 'Threat-led posture review against your actual adversaries. Architecture review, control review, identity review, deploy and incident history. The output is a single risk picture your board can read.' },
      { phase: 'Prioritize', title: 'Risk-weighted, not framework-weighted', body: 'A roadmap ordered by reduction in real risk per dollar, not by which framework controls happen to be open. We ship the things that move the needle first.' },
      { phase: 'Build', title: 'Security as engineering', body: 'Modern controls, automated, integrated into the developer platform. Identity, secrets, detection, response — all version-controlled, all tested.' },
      { phase: 'Operate', title: 'Run the program, not the audit', body: 'Monthly metrics, quarterly threat reviews, continuous control validation, automated evidence. Audits become a checkpoint, not a season.' },
      { phase: 'Respond', title: 'Be ready before you need to be', body: 'Tabletops, purple teams, runbooks tested with your team. The first incident should not be the first time everyone meets each other.' }
    ],
    techStack: ['Wiz', 'CrowdStrike', 'SentinelOne', 'Microsoft Defender XDR', 'Okta', 'Entra ID', 'HashiCorp Vault', 'AWS Security Hub', 'Splunk', 'Sentinel', 'Panther', 'Snyk', 'Semgrep', 'Burp Suite', 'OWASP ZAP', 'Trivy', 'Falco', 'Cilium'],
    industries: ['Financial Services', 'Healthcare', 'Government', 'Critical National Infrastructure', 'SaaS', 'Retail', 'Energy', 'Telecommunications'],
    faqs: [
      { q: 'Can you help us achieve a specific certification?', a: 'Yes. SOC 2, ISO 27001, PCI-DSS, HIPAA, NCA ECC and SAMA in the Gulf, Cyber Essentials Plus and ISO 27001 in the UK. We deliver the certification, but we build the security program first — the cert is the receipt.' },
      { q: 'What does an incident response retainer cover?', a: 'Named senior responders, 24/7 contact, a defined SLA for engagement, pre-built playbooks specific to your environment, quarterly tabletop exercises, and an annual purple-team. You do not pay incident rates if you call us.' },
      { q: 'Are you penetration testers or strategists?', a: 'Both. Our pen-test practice is run by people who have been on the offensive side of intrusions for fifteen-plus years. Our strategy practice is run by people who have run real CISO offices. They work together — the testing informs the strategy and vice versa.' },
      { q: 'Will you work alongside our existing security team?', a: 'Always our preferred model. We bring the senior muscle and the program discipline; your team brings the institutional knowledge. We make ourselves redundant on purpose.' },
      { q: 'How do you handle data residency and confidentiality?', a: 'Aggressively. We work in your environment where required, sign strict NDAs, and architect for UK and Gulf data residency by default. We have done classified-adjacent work and we know how to keep our mouths shut.' }
    ],
    cta: {
      heading: 'Stop confusing compliance with security.',
      sub: 'Tell us your biggest unresolved risk. Thirty minutes with a senior practitioner. We will tell you whether it is the right thing to be worried about.'
    }
  },
  ar: {
    slug: 'cybersecurity',
    hero: {
      eyebrow: 'الأمن السيبراني',
      title: 'أمان يحمي',
      titleEm: 'العمل، لا السياسة.',
      titleEnd: '',
      sub: 'مدفوع بالتهديد، يبدأ بالهوية، وعملي. نبني برامج أمان تُقلّل المخاطر الفعلية وتُرضي المُدقّقين الفعليين، وتُتيح لفِرَقك الهندسية التحرّك بسرعة كاملة. لا مسرح، لا برامج على الرفّ، لا أنظمة تقييم تجعلك تبدو جيداً وعملاءك مكشوفين.'
    },
    intro: {
      heading: 'فِرَق الأمان التي تقول "لا" سهل العثور عليها. فِرَق الأمان التي تجد طريقة لقول "نعم" ليست كذلك.',
      body: 'معظم برامج الأمان مبنيّة لاجتياز التدقيقات، لا لإيقاف المهاجمين. معظم فرق الأمان تُقاس بعدد التذاكر المُغلقة ودرجات الامتثال المُحقَّقة، لا بزمن الكمون والتأثير ونتائج العمل. نحن نفعلها بشكل مختلف. عملنا الأمني يقوده أشخاص أداروا فِرَقاً زرقاء وحمراء وجسور حوادث في شركات سمعتم عنها — ويعرفون الفرق بين ضابط يُقلّل المخاطر وضابط يُقلّل المسؤولية. كلاهما مهم. وليسا الشيء ذاته.'
    },
    pillars: [
      { num: '01', title: 'مدفوع بالتهديد، لا بالإطار', body: 'نبدأ بالتهديدات الفعلية التي يواجهها عملك — وفق صناعتك وبياناتك وجغرافيتك والخصوم الذين يستهدفون أقرانك — لا بربط NIST عام. الأُطر طريقتنا في التقرير. التهديدات طريقتنا في القرار.' },
      { num: '02', title: 'الهوية هي المحيط الجديد، فنُعاملها كذلك', body: 'الهجمات الحديثة لا تخترق جدار الحماية — بل تُسجّل الدخول. عملنا يتمحور حول حوكمة الهوية، الوصول المشروط، الأسرار، هوية الآلات، وسير العمل الذي يجعل الحدّ الأدنى من الامتيازات شيئاً يستطيع المهندسون العيش معه فعلاً.' },
      { num: '03', title: 'الامتثال نتاج جانبي، لا المنتج', body: 'SOC 2 وISO 27001 وPCI-DSS وHIPAA وNCA-ECC وSAMA وGDPR — نُسلّمها كمُخرجات لبرنامج أمان حقيقي، لا كالبرنامج بأكمله. تُصبح التدقيقات روتيناً، لا طوارئ سنوية.' },
      { num: '04', title: 'كشف واستجابة لا تعتمدان على أبطال', body: 'كشوف هندسية متوافقة مع MITRE ATT&CK، فرز آلي، استجابة مدفوعة بأدلة التشغيل. حتى لا يُصبح محلّلك الممتاز الواحد نقطة الفشل الوحيدة للشركة كلها.' },
      { num: '05', title: 'أمان لا تكرهه تجربة المطوّر', body: 'طرق مُعبّدة، قوالب آمنة افتراضياً، فحوصات آلية، أدوات صديقة. إذا جعلنا المسار الآمن هو المسار السهل، فسيفعل المهندسون الصواب دون شرطة.' }
    ],
    offerings: [
      { name: 'استراتيجية الأمن السيبراني والتقييم', description: 'مراجعة بقيادة كبير لوضعك الحالي وبيئة التهديد والخارطة. تُسلّم استراتيجية مكتوبة جاهزة للمجلس باستثمارات مُرتّبة.' },
      { name: 'إدارة الهوية والوصول', description: 'تحديث IAM وPAM وIGA — هوية الموظفين والعملاء والآلات. تسجيل دخول موحّد، مصادقة متعددة، وصول مشروط، وصول حسب الحاجة، إدارة أسرار.' },
      { name: 'أمان السحابة', description: 'CSPM وCIEM وأمان الحاويات وKubernetes وحماية وقت التشغيل. مبنية في CI/CD ليُعالَج الكشف الأمني قبل الدمج، لا بعد التدقيق.' },
      { name: 'أمان التطبيقات', description: 'دمج مع SDLC، خطوط أنابيب SAST/DAST/SCA، مراجعات كود آمنة، نمذجة التهديد، نظافة التبعيات. الأمان ميزة في منصة الهندسة.' },
      { name: 'هندسة الكشف والاستجابة', description: 'SIEM وSOAR وEDR وXDR — مُهندَسة، مُضبَطة، آلية. صيد التهديدات، تمارين الفريق البنفسجي، عقود الاستجابة للحوادث.' },
      { name: 'الحوكمة والمخاطر والامتثال', description: 'اختيار الإطار، ربط الضوابط، أتمتة الأدلة، مخاطر الموردين، تقارير المجلس. نُترجم الأمان إلى لغة العمل والعكس.' },
      { name: 'اختبار الاختراق والفريق الأحمر', description: 'مشاريع التطبيقات والبنية التحتية ومحاكاة الخصم. النتائج مرتبطة بإرشادات المعالجة ومعادة الاختبار بعد الإصلاح. لا نُسلّم PDF ونمشي.' },
      { name: 'الاستجابة للحوادث والتحليل الجنائي', description: 'محتجَز أو عند الطلب. مُستجيبون كبار أداروا حوادث فعلية، لا مجرد محاكاة. الاحتواء، الاستئصال، التعافي، والمحادثة الصعبة مع المجلس.' }
    ],
    outcomes: [
      { metric: '١٤ يوماً', label: 'متوسط الوقت من بدء المشروع إلى رؤية مخاطر حية لمستوى المجلس' },
      { metric: '٩٢٪', label: 'تخفيض في النتائج الحرجة المفتوحة لأكثر من 30 يوماً' },
      { metric: 'SOC 2 Type II', label: 'مُحقَّقة في تسعة أشهر لشركة SaaS بسلسلة B' },
      { metric: '٢٤/٧', label: 'عقد استجابة كبير للحوادث، بمهندسين قياديين مُسمَّيْن' }
    ],
    process: [
      { phase: 'التقييم', title: 'خط أساس صادق', body: 'مراجعة وضع مدفوعة بالتهديد ضد خصومك الفعليين. مراجعة معمارية، مراجعة ضوابط، مراجعة هوية، تاريخ نشر وحوادث. المُخرَج صورة مخاطر واحدة يستطيع مجلسك قراءتها.' },
      { phase: 'الترتيب', title: 'موزون بالمخاطر، لا بالإطار', body: 'خارطة طريق مُرتَّبة وفق تخفيض المخاطر الفعلية لكل دولار، لا وفق ضوابط الإطار المفتوحة. نُسلّم الأشياء التي تُحرّك الإبرة أولاً.' },
      { phase: 'البناء', title: 'الأمان كهندسة', body: 'ضوابط حديثة، آلية، مُدمجة في منصة المطوّر. الهوية، الأسرار، الكشف، الاستجابة — كلها تحت تحكّم الإصدار، كلها مُختبرة.' },
      { phase: 'التشغيل', title: 'أدِر البرنامج، لا التدقيق', body: 'مقاييس شهرية، مراجعات تهديد فصلية، تحقّق مستمر من الضوابط، أدلّة آلية. تُصبح التدقيقات نقطة فحص، لا موسماً.' },
      { phase: 'الاستجابة', title: 'كن جاهزاً قبل أن تحتاج', body: 'تمارين طاولة، فِرَق بنفسجية، أدلّة تشغيل مُختبرة مع فريقك. أوّل حادث لا ينبغي أن يكون أوّل مرة يلتقي فيها الجميع.' }
    ],
    techStack: ['Wiz', 'CrowdStrike', 'SentinelOne', 'Microsoft Defender XDR', 'Okta', 'Entra ID', 'HashiCorp Vault', 'AWS Security Hub', 'Splunk', 'Sentinel', 'Panther', 'Snyk', 'Semgrep', 'Burp Suite', 'OWASP ZAP', 'Trivy', 'Falco', 'Cilium'],
    industries: ['الخدمات المالية', 'الرعاية الصحية', 'الحكومة', 'البنية التحتية الوطنية الحرجة', 'البرمجيات كخدمة', 'التجزئة', 'الطاقة', 'الاتصالات'],
    faqs: [
      { q: 'هل يمكنكم مساعدتنا في تحقيق شهادة محددة؟', a: 'نعم. SOC 2 وISO 27001 وPCI-DSS وHIPAA، NCA ECC وSAMA في الخليج، Cyber Essentials Plus وISO 27001 في بريطانيا. نُسلّم الشهادة، لكنّنا نبني برنامج الأمان أوّلاً — الشهادة هي الإيصال.' },
      { q: 'ماذا يُغطّي عقد الاستجابة للحوادث؟', a: 'مُستجيبون كبار مُسمَّوْن، تواصل 24/7، اتفاقية مستوى خدمة محدّدة للاشتباك، أدلّة عمل مبنية مُسبقاً خاصة ببيئتك، تمارين طاولة فصلية، وفريق بنفسجي سنوي. لا تدفع أسعار حادث إذا اتصلت بنا.' },
      { q: 'هل أنتم مختبرو اختراق أم استراتيجيون؟', a: 'كلاهما. ممارسة اختبار الاختراق يقودها أشخاص كانوا على الجانب الهجومي للاختراقات لخمسة عشر عاماً وأكثر. ممارسة الاستراتيجية يقودها أشخاص أداروا مكاتب CISO حقيقية. يعملون معاً — الاختبار يُرشد الاستراتيجية والعكس.' },
      { q: 'هل ستعملون مع فريق الأمان الحالي لدينا؟', a: 'نموذجنا المفضّل دائماً. نُحضر العضلات الكبيرة وانضباط البرنامج؛ يُحضر فريقك المعرفة المؤسسية. نُجعل أنفسنا غير ضروريين عمداً.' },
      { q: 'كيف تتعاملون مع إقامة البيانات والسرّية؟', a: 'بصرامة. نعمل في بيئتك حيث يلزم، ونُوقّع اتفاقيات سرّية صارمة، ونُصمّم لإقامة البيانات في بريطانيا والخليج افتراضياً. قمنا بأعمال قريبة من المُصنَّفة، ونعرف كيف نُغلق أفواهنا.' }
    ],
    cta: {
      heading: 'توقّف عن الخلط بين الامتثال والأمان.',
      sub: 'حدّثنا عن أكبر مخاطرة لم تُحلّ. ثلاثون دقيقة مع مُمارس كبير. سنُخبرك ما إذا كانت الشيء الصحيح للقلق منه.'
    }
  }
};
