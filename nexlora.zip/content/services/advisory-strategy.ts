import type { ServiceContent } from './ai-data';

export const advisoryStrategy: { en: ServiceContent; ar: ServiceContent } = {
  en: {
    slug: 'advisory-strategy',
    hero: {
      eyebrow: 'Advisory & Strategy',
      title: 'The thinking that comes',
      titleEm: 'before the building.',
      titleEnd: '',
      sub: 'Senior strategists who have run technology inside the companies you are trying to become. We help boards, founders, and CIOs make the calls that compound — what to build, what to buy, what to kill, and what your real competitive moat is going to be three years from now.'
    },
    intro: {
      heading: 'Most consulting decks are written by people who have never carried a product, run a P&L, or fired anyone. Ours are not.',
      body: 'You do not need another fifty-slide presentation. You need a senior operator across the table who has actually shipped, scaled, sold, and shut things down — and who can tell you, in twenty pages or less, the three or four decisions that will determine whether your technology investment compounds or quietly bleeds. That is the only kind of advisory we do. Sharp, written by partners, accountable to outcomes.'
    },
    pillars: [
      { num: '01', title: 'Discovery workshops that find the real question', body: 'A two- to four-day intensive with your leadership team. We come out with the actual problem — which is rarely the one you thought you were buying advice on — and a written prioritization that the room agrees on.' },
      { num: '02', title: 'Digital transformation roadmaps that survive contact with reality', body: 'Three-year roadmaps anchored to business outcomes, not technology trends. With phased budgets, capability builds, and a measurement framework that lets you know in quarter one whether you are on track.' },
      { num: '03', title: 'Technology feasibility, written down', body: 'Before you commit eight or nine figures to a build, a buy, or a partnership, we give you the honest assessment — what works, what is hype, what the unit economics actually look like, where the talent is going to come from, and what the real risks are.' },
      { num: '04', title: 'Innovation advisory grounded in your business, not someone else\'s', body: 'Where AI, data, and emerging technology will move the needle in your specific industry — not in a McKinsey report. We help you separate the bets worth taking from the bets that look smart in a board pack.' },
      { num: '05', title: 'CIO and CTO coaching, on demand', body: 'For tech leaders making decisions they have not made before. Confidential, senior, and aligned — we have been the person on the other side of the table.' }
    ],
    offerings: [
      { name: 'Strategy & Discovery Workshops', description: 'Two- to five-day intensives with executive teams. Come out with a written, prioritized strategy and the data behind it. No homework, no follow-up consulting unless you want it.' },
      { name: 'Digital Transformation Roadmaps', description: 'Three-year plans for moving an enterprise from current to future state. Costed, sequenced, with capability builds and measurement frameworks.' },
      { name: 'Technology Due Diligence', description: 'For investors and acquirers — a senior-led technical and team review of a target. Code, architecture, security, talent, technical debt, and the real risks. In days, not weeks.' },
      { name: 'AI & Data Strategy', description: 'Where to invest, where to wait, and where to stop. Use-case prioritization, ROI modeling, capability roadmaps, governance frameworks.' },
      { name: 'Cloud & Infrastructure Strategy', description: 'Vendor selection, multi-cloud vs. mono-cloud, build vs. buy, total cost of ownership modeling, exit strategies.' },
      { name: 'Cybersecurity Strategy', description: 'Risk-based prioritization, control framework selection, board-level reporting, regulatory positioning. We translate from CISO speak to business speak.' },
      { name: 'Build vs. Buy Analysis', description: 'For platform and product decisions — when does buying win, when does building, and how do you architect the hybrid that actually works.' },
      { name: 'Executive Coaching for Technology Leaders', description: 'Confidential one-to-one engagement for CIOs, CTOs, and VPs of engineering navigating new ground. Monthly, on call when it counts.' }
    ],
    outcomes: [
      { metric: '4–6 weeks', label: 'From engagement to a written strategy your board can act on' },
      { metric: '$120M', label: 'Technology spend redirected for one Tier-1 client in twelve months' },
      { metric: '21%', label: 'Average reduction in IT operating cost in the year following our roadmap' },
      { metric: '0', label: 'Engagements where we recommended you hire us for the build. Independent advice, always.' }
    ],
    process: [
      { phase: 'Frame', title: 'Define the actual question', body: 'A short kickoff with the leadership team. We pressure-test the brief and reframe it where needed — the question you came to us with is rarely the one you should be answering.' },
      { phase: 'Discover', title: 'Understand the system', body: 'Interviews with your team, customers, partners. Data review. Competitor and market work. We come back with the picture, not just the parts you wanted to show us.' },
      { phase: 'Decide', title: 'Sharp recommendations, defended', body: 'A written deliverable — typically twenty to forty pages — with the recommendation, the alternatives we considered, and the data behind both. Reviewed live with your team.' },
      { phase: 'Plan', title: 'A roadmap your team can run', body: 'Phased, costed, with the capability builds and measurement framework laid out. Not a slide deck — a working document your CFO and your VP of engineering can both use.' },
      { phase: 'Stand by', title: 'Available without selling', body: 'Three to six months of advisor access after delivery — questions, course corrections, decisions that pop up. No hidden upsell. We close the engagement when you are ready.' }
    ],
    techStack: ['Frameworks: TOGAF, ArchiMate, BCG growth matrices', 'Modeling: Excel, Causal, Notion, Miro', 'Diligence playbooks: technical, organizational, commercial', 'Benchmarking: Gartner, Forrester, internal peer data'],
    industries: ['Financial Services', 'Public Sector', 'Healthcare', 'Energy', 'Retail', 'PE & VC', 'SaaS', 'Industrial'],
    faqs: [
      { q: 'How is this different from McKinsey, BCG, or Bain?', a: 'Three things. First, partners do the work — not analysts two years out of MBA school. Second, every senior on the engagement has actually run technology operations, not just consulted on them. Third, we do not staff massive teams to justify fees. A typical Nexlora advisory engagement is two to four senior operators, end to end.' },
      { q: 'Will you push us to hire you for implementation?', a: 'No. Our advisory practice is independent of our build practice. If the right answer is to use a different partner, we will say so — and we have. The integrity of the advisory work is the entire business.' },
      { q: 'How long are typical engagements?', a: 'Most are four to eight weeks. Some are two-day workshops. A few become long-term advisory relationships. We scope to the question, not to a default duration.' },
      { q: 'What does it cost?', a: 'Workshops start at twenty thousand dollars. Strategy engagements typically run between $80K and $400K depending on scope. We give fixed fees, not day-rate ladders.' },
      { q: 'Do you sign NDAs?', a: 'Always, before the first conversation. Aggressive ones. We work in confidence as a default, not as a courtesy.' }
    ],
    cta: {
      heading: 'Make the call you have been postponing.',
      sub: 'A first conversation is free, confidential, and senior. Tell us the question. We will tell you, honestly, whether we are the right people to answer it.'
    }
  },
  ar: {
    slug: 'advisory-strategy',
    hero: {
      eyebrow: 'الاستشارات والاستراتيجية',
      title: 'التفكير الذي يأتي',
      titleEm: 'قبل البناء.',
      titleEnd: '',
      sub: 'استراتيجيون كبار قادوا التقنية داخل الشركات التي تسعى لتُصبحها. نُساعد مجالس الإدارة والمؤسسين والمديرين التقنيين على اتخاذ القرارات التي تتراكم — ماذا تبني، ماذا تشتري، ماذا تُلغي، وما خندقك التنافسي الفعلي بعد ثلاث سنوات.'
    },
    intro: {
      heading: 'معظم عروض الاستشارات يكتبها أشخاص لم يحملوا منتجاً قطّ، ولم يُديروا قائمة أرباح، ولم يُسرّحوا أحداً. عروضنا ليست كذلك.',
      body: 'لست بحاجة إلى عرض شرائح من خمسين شريحة. أنت بحاجة إلى مُشغّل كبير على الجانب الآخر من الطاولة، أطلق ووسّع وباع وأغلق فعلاً — يستطيع أن يُخبرك في عشرين صفحة أو أقل بثلاثة أو أربعة قرارات ستُحدّد ما إذا كان استثمارك التقني سيتراكم أم سينزف بصمت. هذا النوع الوحيد من الاستشارات الذي نُقدّمه. حادّة، يكتبها الشركاء، مُحاسَبة على النتائج.'
    },
    pillars: [
      { num: '01', title: 'ورش استكشاف تجد السؤال الحقيقي', body: 'ورشة مكثّفة من يومين إلى أربعة مع فريق قيادتك. نخرج بالمشكلة الفعلية — التي نادراً ما تكون التي ظننتَ أنك تشتري الاستشارة بشأنها — وأولويات مكتوبة تتفق عليها الغرفة.' },
      { num: '02', title: 'خرائط طريق للتحوّل الرقمي تصمد عند الواقع', body: 'خرائط طريق لثلاث سنوات مرتبطة بنتائج العمل، لا بترندات التقنية. بميزانيات مرحلية، وبناء قدرات، وإطار قياس يُتيح لك معرفة ما إذا كنت على المسار في الربع الأول.' },
      { num: '03', title: 'جدوى تقنية، مكتوبة', body: 'قبل أن تلتزم بثمانية أو تسعة أصفار في بناء أو شراء أو شراكة، نُعطيك التقييم الصادق — ما يعمل، ما هو ضجيج، الاقتصاديات الفعلية، من أين ستأتي المواهب، وما المخاطر الحقيقية.' },
      { num: '04', title: 'استشارة ابتكار مرتبطة بعملك أنت، لا بعمل غيرك', body: 'أين سيُحرّك الذكاء الاصطناعي والبيانات والتقنيات الناشئة الإبرة في صناعتك تحديداً — لا في تقرير ماكنزي. نُساعدك على الفصل بين الرهانات التي تستحق والرهانات التي تبدو ذكية في عرض المجلس.' },
      { num: '05', title: 'كوتشينغ للمديرين التقنيين عند الطلب', body: 'لقادة التقنية الذين يتخذون قرارات لم يتخذوها من قبل. سرّي، كبير، ومتوافق — كنّا الشخص على الجانب الآخر من الطاولة.' }
    ],
    offerings: [
      { name: 'ورش الاستراتيجية والاستكشاف', description: 'ورشات مكثّفة من يومين إلى خمسة مع الفرق التنفيذية. اخرج باستراتيجية مكتوبة ومرتّبة الأولويات والبيانات وراءها. لا واجبات، لا استشارات لاحقة إلا إذا أردت.' },
      { name: 'خرائط طريق التحوّل الرقمي', description: 'خطط لثلاث سنوات لنقل المؤسسة من الحالة الراهنة إلى الحالة المستقبلية. مُسعَّرة، مُسلسلة، ببناء قدرات وأُطر قياس.' },
      { name: 'العناية التقنية الواجبة', description: 'للمستثمرين والمستحوذين — مراجعة تقنية وفِرَقية بقيادة كبار الخبراء لشركة هدف. الكود، المعمارية، الأمان، المواهب، الديون التقنية، والمخاطر الحقيقية. في أيام، لا أسابيع.' },
      { name: 'استراتيجية الذكاء الاصطناعي والبيانات', description: 'أين تستثمر، أين تنتظر، وأين تتوقف. ترتيب حالات الاستخدام، نمذجة العائد، خرائط القدرات، أُطر الحوكمة.' },
      { name: 'استراتيجية السحابة والبنية التحتية', description: 'اختيار البائع، متعدد السحب مقابل سحابة واحدة، البناء مقابل الشراء، نمذجة التكلفة الإجمالية للملكية، استراتيجيات الخروج.' },
      { name: 'استراتيجية الأمن السيبراني', description: 'ترتيب الأولويات على أساس المخاطر، اختيار إطار الضوابط، التقارير لمستوى المجلس، التموضع التنظيمي. نُترجم من لغة CISO إلى لغة العمل.' },
      { name: 'تحليل البناء مقابل الشراء', description: 'لقرارات المنصات والمنتجات — متى يفوز الشراء، ومتى يفوز البناء، وكيف تُصمّم الهجين الذي يعمل فعلاً.' },
      { name: 'كوتشينغ تنفيذي لقادة التقنية', description: 'علاقة سرّية فردية للمديرين التقنيين ونوابهم الذين يتعاملون مع أرضية جديدة. شهرياً، ومُتاحون عند الحاجة.' }
    ],
    outcomes: [
      { metric: '٤–٦ أسابيع', label: 'من بدء المشروع إلى استراتيجية مكتوبة يستطيع مجلسك التحرّك بناءً عليها' },
      { metric: '١٢٠ مليون $', label: 'إنفاق تقني أُعيد توجيهه لعميل من الفئة الأولى خلال اثني عشر شهراً' },
      { metric: '٢١٪', label: 'متوسط التخفيض في تكلفة تشغيل تقنية المعلومات في السنة التالية لخارطتنا' },
      { metric: '٠', label: 'مشاريع أوصينا فيها بتعييننا للبناء. استشارة مستقلة دائماً.' }
    ],
    process: [
      { phase: 'التأطير', title: 'حدّد السؤال الفعلي', body: 'انطلاقة قصيرة مع فريق القيادة. نختبر الموجز ونُعيد صياغته حيث يلزم — السؤال الذي جئتَ به نادراً ما يكون السؤال الذي ينبغي الإجابة عنه.' },
      { phase: 'الاستكشاف', title: 'افهم النظام', body: 'مقابلات مع فريقك وعملائك وشركائك. مراجعة بيانات. عمل على المنافسين والسوق. نعود بالصورة، لا فقط بالأجزاء التي أردتَ أن تُرينا إيّاها.' },
      { phase: 'القرار', title: 'توصيات حادّة، مُدافَع عنها', body: 'تسليم مكتوب — عادةً من عشرين إلى أربعين صفحة — يحوي التوصية والبدائل المُعتبَرة والبيانات وراء كل منها. مُراجَع حيّاً مع فريقك.' },
      { phase: 'التخطيط', title: 'خارطة طريق يستطيع فريقك تنفيذها', body: 'مرحلية، مُسعَّرة، ببناء القدرات وإطار القياس. ليست عرض شرائح — وثيقة عمل يستطيع مديرك المالي ونائب رئيس الهندسة استخدامها.' },
      { phase: 'الاستعداد', title: 'متاحون دون بيع', body: 'ثلاثة إلى ستة أشهر من الوصول الاستشاري بعد التسليم — أسئلة، تصحيحات مسار، قرارات تظهر. لا بيع خفي. نُغلق المشروع عندما تكون جاهزاً.' }
    ],
    techStack: ['أُطر: TOGAF، ArchiMate، مصفوفات BCG للنمو', 'نمذجة: Excel، Causal، Notion، Miro', 'أدلة العناية الواجبة: تقنية، تنظيمية، تجارية', 'القياس المرجعي: Gartner، Forrester، بيانات أقران داخلية'],
    industries: ['الخدمات المالية', 'القطاع العام', 'الرعاية الصحية', 'الطاقة', 'التجزئة', 'الأسهم الخاصة ورأس المال المخاطر', 'البرمجيات كخدمة', 'الصناعة'],
    faqs: [
      { q: 'كيف يختلف هذا عن ماكنزي وBCG وبين؟', a: 'ثلاثة أمور. أوّلاً، الشركاء يقومون بالعمل — لا محلّلون خرجوا من MBA قبل سنتين. ثانياً، كل خبير كبير في المشروع أدار عمليات تقنية فعلاً، لا فقط استشار فيها. ثالثاً، لا نُوظّف فِرَقاً ضخمة لتبرير الأتعاب. مشروع نكسلورا الاستشاري النموذجي يضم من اثنين إلى أربعة مُشغّلين كبار من البداية إلى النهاية.' },
      { q: 'هل ستدفعوننا لتعيينكم للتنفيذ؟', a: 'لا. ممارستنا الاستشارية مستقلة عن ممارسة البناء. إذا كانت الإجابة الصحيحة استخدام شريك آخر، فسنقول ذلك — وقد فعلناها. سلامة العمل الاستشاري هي العمل بأكمله.' },
      { q: 'ما المدّة النموذجية للمشاريع؟', a: 'معظمها من أربعة إلى ثمانية أسابيع. بعضها ورشات ليومين. قليل منها يصبح علاقات استشارية طويلة. نحدّد النطاق وفق السؤال، لا وفق مدّة افتراضية.' },
      { q: 'كم تُكلّف؟', a: 'الورشات تبدأ من عشرين ألف دولار. مشاريع الاستراتيجية تتراوح عادةً بين 80 ألف و400 ألف دولار حسب النطاق. نُعطي رسوماً ثابتة، لا سُلَّم سعر يومي.' },
      { q: 'هل تُوقّعون اتفاقيات سرّية؟', a: 'دائماً، قبل المحادثة الأولى. صارمة. نعمل بسرّية بشكل افتراضي، لا كمُجاملة.' }
    ],
    cta: {
      heading: 'اتخذ القرار الذي تُؤجّله.',
      sub: 'المحادثة الأولى مجانية، سرّية، ومع كبير. أخبرنا بالسؤال. سنُخبرك بصراحة ما إذا كنّا الأشخاص المناسبين للإجابة عنه.'
    }
  }
};
