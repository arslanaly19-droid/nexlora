import { aiData, type ServiceContent } from './ai-data';
import { productEngineering } from './product-engineering';
import { cloudInfrastructure } from './cloud-infrastructure';
import { advisoryStrategy } from './advisory-strategy';
import { cybersecurity } from './cybersecurity';

export type { ServiceContent };

export const services = {
  'ai-data-innovation': aiData,
  'product-engineering': productEngineering,
  'cloud-infrastructure': cloudInfrastructure,
  'advisory-strategy': advisoryStrategy,
  cybersecurity
} as const;

export type ServiceSlug = keyof typeof services;

export const serviceSlugs = Object.keys(services) as ServiceSlug[];

export function getService(slug: ServiceSlug, locale: 'en' | 'ar'): ServiceContent {
  return services[slug][locale];
}

// Compact directory of services for nav, home grid, footer, related-link rendering.
// Pulls one-line summaries from each service module's intro.body (first sentence).
export const servicesIndex: { slug: ServiceSlug; titles: { en: string; ar: string }; summaries: { en: string; ar: string } }[] = serviceSlugs.map((slug) => {
  const en = services[slug].en;
  const ar = services[slug].ar;
  const firstSentence = (s: string) => {
    const idx = s.indexOf('.');
    return idx > 40 ? s.slice(0, idx + 1) : s.slice(0, 180);
  };
  return {
    slug,
    titles: { en: en.hero.eyebrow.replace(/^Capability\s*·\s*/, ''), ar: ar.hero.eyebrow.replace(/^القدرة\s*·\s*/, '') },
    summaries: { en: firstSentence(en.intro.body), ar: firstSentence(ar.intro.body) }
  };
});
