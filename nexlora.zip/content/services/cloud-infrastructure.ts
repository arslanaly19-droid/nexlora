import type { ServiceContent } from './ai-data';

export const cloudInfrastructure: { en: ServiceContent; ar: ServiceContent } = {
  en: {
    slug: 'cloud-infrastructure',
    hero: {
      eyebrow: 'Cloud & Infrastructure',
      title: 'Infrastructure that never',
      titleEm: 'becomes the bottleneck.',
      titleEnd: '',
      sub: 'Cloud strategy. Migration. Security. FinOps. We build the foundation that lets your business move fast without things breaking — or costing you a fortune. Modern, well-architected, observable, and quiet enough that you forget it is there.'
    },
    intro: {
      heading: 'The cloud bill is not the problem. The bill is the symptom. The problem is that nobody architected for the actual usage pattern.',
      body: 'Cloud went from a competitive advantage to a hidden tax. Companies are spending more than they did on data centers and getting worse reliability, slower deploys, and a security posture nobody can explain. We help you fix that — by treating cloud infrastructure like a product with users, costs, and an SLA, not a sunk cost you tolerate. Migrations that actually finish. Architectures that scale linearly with revenue. Security that does not block the business. Cost reductions in the first quarter that compound.'
    },
    pillars: [
      { num: '01', title: 'Migration that actually finishes', body: 'Phased, reversible, and measured. Not the eighteen-month death march you have heard about. We move workloads in waves with clear cutover criteria and a working rollback for every step. No big-bang weekends.' },
      { num: '02', title: 'Architecture designed for the bill, not just the load', body: 'We design with the cost model in mind from day one — right-sized compute, smart storage tiering, egress minimization, savings plans where they earn out. A 30 to 50 percent cost reduction in the first year is normal, not exceptional.' },
      { num: '03', title: 'Security that the business can live with', body: 'Zero-trust networking, identity-first access, encrypted everything, automated compliance evidence — but designed so engineers can still move fast. Security that blocks delivery is not security; it is theater.' },
      { num: '04', title: 'Platform engineering for your developers', body: 'Internal developer platforms that give your engineering teams paved roads — golden paths for new services, automated environments, observability built in. We turn your infrastructure into a product your developers actually like using.' },
      { num: '05', title: 'FinOps that is not just a dashboard', body: 'Cost allocation by team, product, and customer. Monthly business reviews where engineering leadership sees the trade-offs. We build the discipline, not just the tooling.' }
    ],
    offerings: [
      { name: 'Cloud Migration', description: 'AWS, Azure, GCP — we have shipped them all. From legacy on-prem and colo to modern landing zones, with phased waves and zero-downtime cutovers.' },
      { name: 'Cloud Architecture', description: 'Greenfield landing zones, multi-account or multi-subscription strategies, network topology, identity, observability, disaster recovery — designed properly, documented thoroughly.' },
      { name: 'DevSecOps & CI/CD', description: 'Modern pipelines on GitHub Actions, GitLab CI, Azure DevOps. Trunk-based development, automated security scanning, deployment frequency you can show off.' },
      { name: 'Kubernetes & Containers', description: 'EKS, AKS, GKE — production-grade clusters with proper governance. Service mesh, ingress, secrets management, autoscaling that actually responds to load.' },
      { name: 'Cloud Security & Compliance', description: 'CSPM, CIEM, runtime protection. SOC 2, ISO 27001, HIPAA, PCI-DSS, GDPR — controls mapped, evidence automated, audits painless.' },
      { name: 'FinOps & Cost Optimization', description: 'Spend visibility, allocation, savings plans, reserved instances, idle resource cleanup. Typical first-quarter savings range from 25 to 45 percent.' },
      { name: 'Site Reliability Engineering', description: 'Error budgets, SLOs, runbooks, incident response, on-call rotations that humans can sustain. Not theatrical reliability — actual reliability.' },
      { name: 'Disaster Recovery & Business Continuity', description: 'RTO and RPO targets matched to business value, tested quarterly, documented in plain English. The first time you fail over should not be in production.' }
    ],
    outcomes: [
      { metric: '90', label: 'Days to migrate 14 legacy systems for a UK retailer' },
      { metric: '41%', label: 'Reduction in annualized cloud bill, no architecture compromise' },
      { metric: '99.99%', label: 'Uptime delivered for a Tier-1 GCC banking workload' },
      { metric: '12×', label: 'Increase in deploy frequency after platform-engineering work' }
    ],
    process: [
      { phase: 'Assess', title: 'Where you are, in numbers', body: 'A full inventory: workloads, dependencies, costs, security posture, deploy frequency, incidents. We turn the chaos into a single document everyone can argue with.' },
      { phase: 'Design', title: 'The target architecture, written down', body: 'Landing zone, network, identity, security, observability, governance — designed against your actual constraints, not a reference architecture from a vendor blog.' },
      { phase: 'Migrate', title: 'In waves, never all at once', body: 'Workloads grouped by risk and dependency. Each wave has a cutover plan, a rollback plan, and a success metric. Boring, methodical, finishes on time.' },
      { phase: 'Operate', title: 'Hand off without leaving holes', body: 'Runbooks, on-call rotations, observability dashboards, cost reviews — your team owns the platform, with us in the room until they are ready.' },
      { phase: 'Optimize', title: 'The work that pays the build back', body: 'Right-sizing, savings plans, architectural improvements, FinOps discipline. The cost reductions that pay for the engagement many times over.' }
    ],
    techStack: ['AWS', 'Azure', 'Google Cloud', 'Terraform', 'Pulumi', 'Kubernetes', 'Docker', 'Helm', 'Istio', 'GitHub Actions', 'GitLab CI', 'Argo CD', 'Datadog', 'Grafana', 'Prometheus', 'Splunk', 'Wiz', 'Snyk', 'HashiCorp Vault', 'Cloudflare'],
    industries: ['Financial Services', 'Retail', 'Healthcare', 'Government', 'Energy', 'SaaS', 'Logistics', 'Media'],
    faqs: [
      { q: 'How long does a cloud migration actually take?', a: 'For a mid-sized estate of 50 to 200 workloads, six to twelve months is normal. Anyone promising you faster is either lying or skipping work that you will pay for later. We move quickly — and we do not skip the work.' },
      { q: 'Are you tied to a specific cloud vendor?', a: 'No. We are deeply experienced on AWS, Azure, and GCP. We will recommend the cloud that fits your constraints — regulatory, talent, partnership, and cost — not the one we get spiffs from. We get no spiffs.' },
      { q: 'Can you work with our existing platform team?', a: 'That is our preferred model. We bring senior architects and operators to augment your team, transfer knowledge, and leave you stronger than when we arrived. The goal is to make ourselves unnecessary.' },
      { q: 'How do you handle data residency in the Gulf or UK?', a: 'We architect for it. AWS Middle East regions, Azure UAE North, GCP Saudi Arabia, and the equivalent UK regions are first-class citizens in our designs. GDPR-compliant by construction.' },
      { q: 'What if we need to stay on-prem for some workloads?', a: 'Hybrid is a real architecture, not a transitional state. We design for it where it makes sense — manufacturing, defense, healthcare, regulatory — and we connect it cleanly to the cloud workloads.' }
    ],
    cta: {
      heading: 'Stop renting expensive complexity. Start owning a real platform.',
      sub: 'A thirty-minute call. We will look at your current cloud bill, your incident history, and your deploy frequency, and we will tell you, honestly, where the leverage is.'
    }
  },
  ar: {
    slug: 'cloud-infrastructure',
    hero: {
      eyebrow: 'السحابة والبنية التحتية',
      title: 'بنية تحتية لا تتحوّل أبداً',
      titleEm: 'إلى عنق الزجاجة.',
      titleEnd: '',
      sub: 'استراتيجية سحابية. ترحيل. أمان. FinOps. نبني الأساس الذي يُتيح لأعمالك التحرّك بسرعة دون أن تنكسر الأشياء — أو تُكلّفك ثروة. حديثة، حسنة التصميم، قابلة للمراقبة، وهادئة بما يكفي لتنسى وجودها.'
    },
    intro: {
      heading: 'الفاتورة السحابية ليست المشكلة. الفاتورة هي العَرَض. المشكلة أن لا أحد صمّم لنمط الاستخدام الفعلي.',
      body: 'تحوّلت السحابة من ميزة تنافسية إلى ضريبة خفيّة. الشركات تُنفق أكثر مما كانت تُنفقه على مراكز البيانات، وتحصل على موثوقية أسوأ، ونشر أبطأ، ووضع أمني لا يستطيع أحد شرحه. نحن نُساعدك على إصلاح ذلك — بمعاملة البنية التحتية السحابية كمنتج له مستخدمون وتكاليف واتفاقية مستوى خدمة، لا كتكلفة غارقة تتحمّلها. ترحيل ينتهي فعلاً. معماريات تتوسّع خطّياً مع الإيراد. أمان لا يُعيق العمل. تخفيضات تكاليف في الربع الأول تتراكم.'
    },
    pillars: [
      { num: '01', title: 'ترحيل ينتهي فعلاً', body: 'مرحليّ، قابل للتراجع، ومُقاس. ليس مسيرة الموت لثمانية عشر شهراً التي سمعت عنها. نُحرّك الأحمال في موجات بمعايير تحويل واضحة وخطة تراجع عاملة لكل خطوة. لا عطلات نهاية أسبوع للانفجار الكبير.' },
      { num: '02', title: 'معمارية مُصمَّمة للفاتورة، لا فقط للحمل', body: 'نُصمّم بنموذج التكلفة في الذهن من اليوم الأول — حوسبة بحجم مناسب، تخزين متدرّج، تقليل الخروج، خطط ادّخار حيث تستحق. تخفيض من 30 إلى 50 بالمائة في السنة الأولى أمر طبيعي، لا استثنائي.' },
      { num: '03', title: 'أمان يستطيع العمل التعايش معه', body: 'شبكات بدون ثقة، وصول يبدأ بالهوية، تشفير لكل شيء، أدلّة امتثال آلية — مُصمَّمة بحيث يبقى المهندسون قادرين على التحرّك بسرعة. الأمان الذي يُعيق التسليم ليس أماناً؛ بل مسرحية.' },
      { num: '04', title: 'هندسة منصات لمطوريك', body: 'منصات تطوير داخلية تُعطي فرقك الهندسية طرقاً مُعبّدة — مسارات ذهبية للخدمات الجديدة، بيئات آلية، مراقبة مدمجة. نُحوّل بنيتك التحتية إلى منتج يُحبّ مطوّروك استخدامه.' },
      { num: '05', title: 'FinOps ليس مجرد لوحة قياس', body: 'تخصيص التكاليف حسب الفريق والمنتج والعميل. مراجعات أعمال شهرية ترى فيها قيادة الهندسة المفاضلات. نبني الانضباط، لا الأدوات فقط.' }
    ],
    offerings: [
      { name: 'الترحيل السحابي', description: 'AWS وAzure وGCP — سلّمناها جميعاً. من البيئات القديمة المحلية والمستضافة إلى مناطق هبوط حديثة، بموجات مرحلية وتحويلات دون توقّف.' },
      { name: 'المعمارية السحابية', description: 'مناطق هبوط حديثة، استراتيجيات متعددة الحسابات أو الاشتراكات، طوبولوجيا الشبكة، الهوية، المراقبة، التعافي من الكوارث — مُصمَّمة بإتقان وموثَّقة بدقة.' },
      { name: 'DevSecOps وCI/CD', description: 'خطوط أنابيب حديثة على GitHub Actions وGitLab CI وAzure DevOps. تطوير مبني على الفرع الرئيسي، فحص أمني آلي، تكرار نشر يستحق العرض.' },
      { name: 'Kubernetes والحاويات', description: 'EKS وAKS وGKE — مجموعات بمستوى إنتاج مع حوكمة سليمة. شبكة خدمات، دخول، إدارة أسرار، توسعة آلية تستجيب فعلاً للحمل.' },
      { name: 'الأمان السحابي والامتثال', description: 'CSPM وCIEM وحماية وقت التشغيل. SOC 2 وISO 27001 وHIPAA وPCI-DSS وGDPR — ضوابط مُحكمة، أدلة آلية، تدقيقات بلا ألم.' },
      { name: 'FinOps وتحسين التكاليف', description: 'رؤية الإنفاق، التخصيص، خطط الادّخار، الحجوزات، تنظيف الموارد الخاملة. الوفورات النموذجية في الربع الأول تتراوح من 25 إلى 45 بالمائة.' },
      { name: 'هندسة موثوقية المواقع', description: 'ميزانيات أخطاء، أهداف SLO، أدلة تشغيل، استجابة للحوادث، مناوبات يحتمل البشر. ليست موثوقية مسرحية — موثوقية فعلية.' },
      { name: 'التعافي من الكوارث واستمرارية الأعمال', description: 'أهداف RTO وRPO مُطابقة لقيمة العمل، مُختبرة فصلياً، موثَّقة بلغة واضحة. أوّل مرة تُنفّذ فيها التحويل لا ينبغي أن تكون في الإنتاج.' }
    ],
    outcomes: [
      { metric: '٩٠', label: 'يوماً لترحيل ١٤ نظاماً قديماً لشركة تجزئة بريطانية' },
      { metric: '٤١٪', label: 'تخفيض في الفاتورة السحابية السنوية، دون تنازل معماري' },
      { metric: '٩٩.٩٩٪', label: 'وقت تشغيل لحمل مصرفي خليجي من الفئة الأولى' },
      { metric: '١٢×', label: 'زيادة في تكرار النشر بعد العمل في هندسة المنصات' }
    ],
    process: [
      { phase: 'التقييم', title: 'أين أنت، بالأرقام', body: 'جرد كامل: الأحمال، التبعيات، التكاليف، الوضع الأمني، تكرار النشر، الحوادث. نُحوّل الفوضى إلى وثيقة واحدة يستطيع الجميع الجدال حولها.' },
      { phase: 'التصميم', title: 'المعمارية المستهدفة، مكتوبة', body: 'منطقة الهبوط، الشبكة، الهوية، الأمان، المراقبة، الحوكمة — مُصمَّمة وفق قيودك الفعلية، لا معمارية مرجعية من مدونة بائع.' },
      { phase: 'الترحيل', title: 'بموجات، لا دفعة واحدة', body: 'أحمال مُجمَّعة حسب المخاطر والتبعية. لكل موجة خطة تحويل، خطة تراجع، ومقياس نجاح. مملّ، منهجي، ينتهي في موعده.' },
      { phase: 'التشغيل', title: 'سلّم دون ترك ثغرات', body: 'أدلة تشغيل، مناوبات، لوحات مراقبة، مراجعات تكاليف — فريقك يملك المنصة، ونحن في الغرفة حتى يصبحوا جاهزين.' },
      { phase: 'التحسين', title: 'العمل الذي يردّ ثمن البناء', body: 'تحجيم سليم، خطط ادّخار، تحسينات معمارية، انضباط FinOps. تخفيضات التكاليف التي تدفع ثمن المشروع أضعافاً مضاعفة.' }
    ],
    techStack: ['AWS', 'Azure', 'Google Cloud', 'Terraform', 'Pulumi', 'Kubernetes', 'Docker', 'Helm', 'Istio', 'GitHub Actions', 'GitLab CI', 'Argo CD', 'Datadog', 'Grafana', 'Prometheus', 'Splunk', 'Wiz', 'Snyk', 'HashiCorp Vault', 'Cloudflare'],
    industries: ['الخدمات المالية', 'التجزئة', 'الرعاية الصحية', 'الحكومة', 'الطاقة', 'البرمجيات كخدمة', 'اللوجستيات', 'الإعلام'],
    faqs: [
      { q: 'كم يستغرق الترحيل السحابي فعلاً؟', a: 'لمحفظة متوسطة من 50 إلى 200 حمل، ستة إلى اثني عشر شهراً أمر طبيعي. أي شخص يَعِدك بأسرع من ذلك يكذب أو يتجاوز عملاً ستدفع ثمنه لاحقاً. نتحرّك بسرعة — ولا نتجاوز العمل.' },
      { q: 'هل أنتم مرتبطون بمزوّد سحابي محدد؟', a: 'لا. لدينا خبرة عميقة في AWS وAzure وGCP. سنُوصي بالسحابة التي تُناسب قيودك — التنظيمية، والمواهب، والشراكات، والتكلفة — لا تلك التي نأخذ منها عمولات. لا نأخذ عمولات.' },
      { q: 'هل يمكنكم العمل مع فريق المنصات الحالي لدينا؟', a: 'هذا نموذجنا المفضّل. نُحضر كبار المعماريين والمشغّلين لتعزيز فريقك، ونقل المعرفة، وترككم أقوى مما كنتم. الهدف أن نُصبح غير ضروريين.' },
      { q: 'كيف تتعاملون مع إقامة البيانات في الخليج أو بريطانيا؟', a: 'نُصمّم لها. مناطق AWS الشرق الأوسط، Azure الإمارات الشمال، GCP السعودية، والمناطق البريطانية المُكافئة هي مواطنون من الدرجة الأولى في تصاميمنا. متوافقة مع GDPR بالبناء.' },
      { q: 'ماذا لو احتجنا البقاء محلياً لبعض الأحمال؟', a: 'الهجين معمارية حقيقية، لا حالة انتقالية. نُصمّم له حيث يُجدي — التصنيع، الدفاع، الرعاية الصحية، التنظيم — ونصله بنظافة بالأحمال السحابية.' }
    ],
    cta: {
      heading: 'توقّف عن استئجار التعقيد المُكلف. ابدأ بامتلاك منصة حقيقية.',
      sub: 'اجتماع لمدة ثلاثين دقيقة. سننظر في فاتورتك السحابية الحالية وسجل حوادثك وتكرار نشرك، وسنُخبرك بصراحة أين الرافعة.'
    }
  }
};
