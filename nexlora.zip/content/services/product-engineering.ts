import type { ServiceContent } from './ai-data';

export const productEngineering: { en: ServiceContent; ar: ServiceContent } = {
  en: {
    slug: 'product-engineering',
    hero: {
      eyebrow: 'Digital Product Engineering',
      title: 'Products your customers',
      titleEm: 'actually want to use.',
      titleEnd: '',
      sub: 'Design that removes friction. Architecture that scales. AI baked in from day one. We build the digital products that become how your business is bought, used, and remembered — not the kind that ship on time and fade quietly into the backlog.'
    },
    intro: {
      heading: 'A product is the contract between what you sell and what your customer experiences. Most contracts are broken.',
      body: 'You can have the best engineering team in the world and still ship a product nobody wants. You can have a beautiful design and still lose to a competitor who shipped something uglier but faster. Building a product that actually moves the business requires three disciplines under one roof — strategy, design, and engineering — held to the same standard, accountable to the same metric, and refusing to ship anything that does not earn its place. That is what we do.'
    },
    pillars: [
      { num: '01', title: 'Discovery before delivery — every time', body: 'We do not build what you asked for. We build what you needed to ask for. Two-week discovery sprints with your customers, your data, and your team — followed by a written prioritization that names what we will build, what we will not, and why.' },
      { num: '02', title: 'Design that respects the user and the business', body: 'No vanity portfolios. No pixel-pushing for awards. Our designers partner with engineering and product to make decisions that are beautiful, fast to build, and measurably reduce friction in the customer journey. Conversion lifts are not accidents — they are the design system.' },
      { num: '03', title: 'Engineering that does not lock you in', body: 'Modern stacks where they earn their keep. Boring, proven choices everywhere else. We write code your future team can read, in architectures your future CTO will not regret. Every codebase ships with documentation, tests, and a runbook on day one.' },
      { num: '04', title: 'Mobile that does not feel like a website squeezed into an app', body: 'Native iOS and Android, or React Native where it fits — built with offline-first thinking, accessibility from the start, and the kind of polish your users feel without being able to name it.' },
      { num: '05', title: 'AI baked in, not bolted on', body: 'Every product we build is architected for AI from day one — even if you are not using it yet. Vector stores, model abstractions, evaluation hooks, prompt management — so when you do flip the switch, you are not rebuilding the foundation.' }
    ],
    offerings: [
      { name: 'Product Discovery & Strategy', description: 'Two- to four-week sprints to validate the problem, the audience, and the build. We end with a written, prioritized roadmap and a fixed-price MVP proposal.' },
      { name: 'UX & UI Design', description: 'End-to-end design from research to high-fidelity systems. Component libraries, design tokens, accessibility-audited from the start.' },
      { name: 'Web Application Engineering', description: 'Next.js, Remix, Nuxt, SvelteKit — modern frameworks chosen for the job, not the trend. Edge-rendered where it matters, server-rendered where it does not.' },
      { name: 'Mobile Application Engineering', description: 'Native Swift and Kotlin or React Native, with offline-first architectures, push pipelines, and CI that ships to TestFlight and Play Console without drama.' },
      { name: 'Application Modernization', description: 'Re-platforming legacy monoliths into clean services without the eighteen-month rewrite. Strangler-fig patterns, feature flags, zero-downtime cutover.' },
      { name: 'API & Platform Engineering', description: 'GraphQL and REST APIs, internal developer platforms, design systems, microservice meshes — the unglamorous infrastructure that lets product teams move fast.' },
      { name: 'Design Systems', description: 'Token-driven, multi-brand, multi-locale. Built in Figma and code together so design and engineering never drift apart.' },
      { name: 'Quality Engineering', description: 'Automated testing pyramids, contract testing, visual regression, performance budgets — quality is a design choice, not a phase.' }
    ],
    outcomes: [
      { metric: '180K', label: 'Users at launch for a Saudi PropTech platform' },
      { metric: '6mo', label: 'Idea to live deployment for a regulated GCC product' },
      { metric: '47%', label: 'Conversion lift after a redesigned onboarding flow' },
      { metric: '99.95%', label: 'Uptime SLA we hold ourselves to and hit' }
    ],
    process: [
      { phase: 'Discover', title: 'Earn the right to build', body: 'Customer interviews, competitive teardowns, data review, and a hard-nosed business case. If the numbers do not support the build, we say so.' },
      { phase: 'Design', title: 'Prototype before code', body: 'Clickable prototypes tested with real users in week three. We learn what to build before we spend the money to build it.' },
      { phase: 'Architect', title: 'Decide the boring stuff up front', body: 'Stack, infrastructure, security model, observability, deployment, rollback. Written down. Signed off. Visible to both sides.' },
      { phase: 'Build', title: 'Working software every two weeks', body: 'Demo at the end of every sprint. Real software you can click on, not slides about software we plan to ship.' },
      { phase: 'Launch', title: 'Production day is a non-event', body: 'Phased rollouts, feature flags, dark launches, runbooks tested before the day. Boring is the goal.' },
      { phase: 'Grow', title: 'Measure, iterate, compound', body: 'Live metrics dashboards from day one. Product reviews tied to business KPIs. We do not disappear after go-live.' }
    ],
    techStack: ['Next.js', 'React', 'Vue', 'Svelte', 'Node.js', 'TypeScript', 'Python', 'Go', 'Swift', 'Kotlin', 'React Native', 'Flutter', 'GraphQL', 'tRPC', 'Postgres', 'MongoDB', 'Redis', 'Prisma', 'Tailwind CSS', 'Figma', 'Storybook', 'Playwright', 'Cypress'],
    industries: ['Fintech', 'Healthtech', 'PropTech', 'EdTech', 'E-commerce', 'B2B SaaS', 'Marketplaces', 'Government Digital Services'],
    faqs: [
      { q: 'How fast can you ship an MVP?', a: 'For a focused MVP with clear scope, twelve to sixteen weeks is realistic. For products where regulation, integrations, or AI complexity are involved, allow more. We give you an honest estimate after discovery, not before.' },
      { q: 'Will we own the code?', a: 'Yes. Always. Source code, design files, infrastructure-as-code, documentation, and the keys to the kingdom transfer to you on a fixed schedule. We do not hold your business hostage.' },
      { q: 'What about ongoing support?', a: 'Optional, on terms that suit you. Some clients keep us on retainer for new features and reliability; some take the platform fully in-house and pay us for an annual review. Either is fine.' },
      { q: 'Can we work with your designers but our engineers?', a: 'Yes — and the reverse. We unbundle. Some clients want our entire product team; some want one capability augmenting their existing crew. We work either way.' },
      { q: 'How do you handle accessibility?', a: 'WCAG 2.2 AA from day one — design tokens, semantic HTML, keyboard navigation, screen-reader testing on every release. It is not a phase. It is a precondition.' }
    ],
    cta: {
      heading: 'Stop shipping products. Start shipping outcomes.',
      sub: 'Tell us about the product you are building, modernizing, or rescuing. Thirty minutes. No pitch deck. Honest answer about whether we can help.'
    }
  },
  ar: {
    slug: 'product-engineering',
    hero: {
      eyebrow: 'هندسة المنتجات الرقمية',
      title: 'منتجات يرغب عملاؤك',
      titleEm: 'فعلاً في استخدامها.',
      titleEnd: '',
      sub: 'تصميم يُلغي الاحتكاك. معمارية تتوسّع. ذكاء اصطناعي مدمج من اليوم الأول. نبني المنتجات الرقمية التي تتحوّل إلى الطريقة التي تُشترى بها أعمالك وتُستخدم وتُذكر — لا تلك التي تُسلَّم في موعدها وتختفي بهدوء في قائمة الأعمال المتراكمة.'
    },
    intro: {
      heading: 'المنتج هو العقد بين ما تبيعه وما يختبره عميلك. معظم العقود مكسورة.',
      body: 'يُمكن أن يكون لديك أفضل فريق هندسي في العالم، ومع ذلك تُطلق منتجاً لا يُريده أحد. يُمكن أن يكون لديك تصميم جميل، ومع ذلك تخسر أمام منافس أطلق شيئاً أقل جمالاً ولكن أسرع. بناء منتج يُحرّك العمل فعلاً يتطلّب ثلاثة تخصصات تحت سقف واحد — الاستراتيجية والتصميم والهندسة — مُحاسَبة على المعايير ذاتها، ومسؤولة عن المقياس ذاته، وترفض إطلاق أي شيء لا يستحق مكانه. هذا ما نفعله.'
    },
    pillars: [
      { num: '01', title: 'استكشاف قبل التسليم — في كل مرة', body: 'لا نبني ما طلبته. نبني ما كان يجب أن تطلبه. سبرنتات استكشاف لأسبوعين مع عملائك وبياناتك وفريقك — تليها أولويات مكتوبة تُسمّي ما سنبنيه، وما لن نبنيه، ولماذا.' },
      { num: '02', title: 'تصميم يحترم المستخدم والعمل', body: 'لا محافظ تصميم للمظهر. لا تحريك بكسل من أجل الجوائز. مُصمّمونا يعملون مع الهندسة والمنتج لاتخاذ قرارات جميلة وسريعة البناء وتُقلّل الاحتكاك بشكل قابل للقياس. ارتفاع التحويل ليس صدفة — بل نظام التصميم.' },
      { num: '03', title: 'هندسة لا تحبسك', body: 'بُنى حديثة حيث تستحق. خيارات مجرَّبة ومملّة في كل ما عدا ذلك. نكتب كوداً يقرؤه فريقك المستقبلي، في معماريات لا يندم عليها مديرك التقني المستقبلي. كل قاعدة كود تُسلَّم مع توثيق واختبارات ودليل تشغيل من اليوم الأول.' },
      { num: '04', title: 'موبايل لا يبدو كموقع مضغوط في تطبيق', body: 'iOS وAndroid أصليّان، أو React Native حيث يُناسب — مبنية بتفكير يُقدّم العمل دون اتصال أولاً، وإمكانية الوصول من البداية، والصقل الذي يشعر به مستخدموك دون أن يستطيعوا تسميته.' },
      { num: '05', title: 'ذكاء اصطناعي مدمج، لا مُلصَق', body: 'كل منتج نبنيه مُصمَّم للذكاء الاصطناعي من اليوم الأول — حتى لو لم تستخدمه بعد. مخازن متجهات، طبقات تجريد للنماذج، خطافات تقييم، إدارة محفّزات — حتى عندما تُفعّله، لن تُعيد بناء الأساس.' }
    ],
    offerings: [
      { name: 'استكشاف المنتج والاستراتيجية', description: 'سبرنتات من أسبوعين إلى أربعة للتحقق من المشكلة والجمهور والبناء. نختم بخارطة طريق مكتوبة ومرتّبة وعرض MVP بسعر ثابت.' },
      { name: 'تصميم تجربة وواجهة المستخدم', description: 'تصميم شامل من البحث إلى الأنظمة عالية الدقة. مكتبات مكوّنات، رموز تصميم، تدقيق إمكانية الوصول من البداية.' },
      { name: 'هندسة تطبيقات الويب', description: 'Next.js وRemix وNuxt وSvelteKit — أُطر حديثة مُختارة للعمل، لا للموضة. مُقدَّمة من الحافة حيث يهم، ومن الخادم حيث لا يهم.' },
      { name: 'هندسة تطبيقات الموبايل', description: 'Swift وKotlin أصليان أو React Native، مع معماريات تعمل دون اتصال، وخطوط دفع، وCI يُسلّم إلى TestFlight وPlay Console دون درامية.' },
      { name: 'تحديث التطبيقات', description: 'إعادة بناء الأنظمة القديمة الموحَّدة إلى خدمات نظيفة دون إعادة كتابة لثمانية عشر شهراً. أنماط Strangler Fig، أعلام الميزات، تحويل دون توقّف.' },
      { name: 'هندسة الواجهات والمنصات', description: 'واجهات GraphQL وREST، منصات تطوير داخلية، أنظمة تصميم، شبكات الخدمات الصغرى — البنية التحتية غير البرّاقة التي تُتيح لفرق المنتج التحرّك بسرعة.' },
      { name: 'أنظمة التصميم', description: 'مدفوعة بالرموز، متعددة العلامات التجارية، متعددة اللغات. مبنية في Figma والكود معاً حتى لا ينحرف التصميم والهندسة.' },
      { name: 'هندسة الجودة', description: 'أهرامات اختبار آلية، اختبار العقود، الانحدار البصري، ميزانيات الأداء — الجودة خيار تصميم، لا مرحلة.' }
    ],
    outcomes: [
      { metric: '١٨٠ ألف', label: 'مستخدم عند الإطلاق لمنصة عقارات تقنية سعودية' },
      { metric: '٦ أشهر', label: 'من الفكرة إلى النشر الفعلي لمنتج خليجي خاضع للتنظيم' },
      { metric: '٤٧٪', label: 'ارتفاع في التحويل بعد إعادة تصميم تدفّق التهيئة' },
      { metric: '٩٩.٩٥٪', label: 'اتفاقية مستوى خدمة نُلزم أنفسنا بها ونحقّقها' }
    ],
    process: [
      { phase: 'الاستكشاف', title: 'استحقّ الحق في البناء', body: 'مقابلات العملاء، تحليل المنافسة، مراجعة البيانات، وحالة عمل صارمة. إذا لم تدعم الأرقام البناء، فسنقول ذلك.' },
      { phase: 'التصميم', title: 'النموذج الأوّلي قبل الكود', body: 'نماذج أوّلية قابلة للنقر تُختبر مع مستخدمين حقيقيين في الأسبوع الثالث. نتعلّم ما نبنيه قبل أن ننفق المال على بنائه.' },
      { phase: 'التصميم المعماري', title: 'احسم المملّ مسبقاً', body: 'البنية، البنية التحتية، نموذج الأمان، المراقبة، النشر، التراجع. مكتوبة. موقَّعة. مرئية للطرفين.' },
      { phase: 'البناء', title: 'برمجيات عاملة كل أسبوعين', body: 'عرض في نهاية كل سبرنت. برمجيات حقيقية يمكنك النقر عليها، لا شرائح عن برمجيات نخطّط لتسليمها.' },
      { phase: 'الإطلاق', title: 'يوم الإنتاج حدث غير مهم', body: 'إطلاقات مرحلية، أعلام ميزات، إطلاقات ظلّية، أدلة تشغيل مُختبرة قبل اليوم. الهدف أن يكون مملّاً.' },
      { phase: 'النمو', title: 'قِس، طوِّر، ضاعف', body: 'لوحات قياس حيّة من اليوم الأول. مراجعات منتج مرتبطة بمؤشرات الأداء. لا نختفي بعد الإطلاق.' }
    ],
    techStack: ['Next.js', 'React', 'Vue', 'Svelte', 'Node.js', 'TypeScript', 'Python', 'Go', 'Swift', 'Kotlin', 'React Native', 'Flutter', 'GraphQL', 'tRPC', 'Postgres', 'MongoDB', 'Redis', 'Prisma', 'Tailwind CSS', 'Figma', 'Storybook', 'Playwright', 'Cypress'],
    industries: ['التقنية المالية', 'الصحة الرقمية', 'العقارات الرقمية', 'التعليم الرقمي', 'التجارة الإلكترونية', 'البرمجيات كخدمة', 'منصات السوق', 'الخدمات الحكومية الرقمية'],
    faqs: [
      { q: 'ما السرعة التي يمكنكم بها إطلاق MVP؟', a: 'لـ MVP مُركَّز بنطاق واضح، اثنا عشر إلى ستة عشر أسبوعاً أمر واقعي. للمنتجات التي تشمل تنظيمات أو تكاملات أو تعقيد ذكاء اصطناعي، خصّص وقتاً أكثر. نُعطيك تقديراً صادقاً بعد الاستكشاف، لا قبله.' },
      { q: 'هل سنملك الكود؟', a: 'نعم. دائماً. الكود المصدري، ملفات التصميم، البنية التحتية ككود، التوثيق، ومفاتيح المملكة تنتقل إليك وفق جدول ثابت. لا نحتجز أعمالك رهينة.' },
      { q: 'وماذا عن الدعم المستمر؟', a: 'اختياري بشروط تُناسبك. بعض العملاء يحتفظون بنا في عقد لميزات جديدة وموثوقية؛ والبعض يأخذ المنصة بالكامل داخلياً ويدفع لنا مقابل مراجعة سنوية. كلاهما مقبول.' },
      { q: 'هل يمكننا العمل مع مصممينكم لكن مع مهندسينا؟', a: 'نعم — والعكس. نُفكّك خدماتنا. بعض العملاء يُريدون فريق منتجنا كاملاً؛ والبعض يُريد قدرة واحدة تُعزّز فريقهم القائم. نعمل بكلتا الطريقتين.' },
      { q: 'كيف تتعاملون مع إمكانية الوصول؟', a: 'WCAG 2.2 AA من اليوم الأول — رموز تصميم، HTML دلالي، تنقّل بلوحة المفاتيح، اختبار قارئ شاشة في كل إصدار. ليست مرحلة. بل شرط مسبق.' }
    ],
    cta: {
      heading: 'توقّف عن إطلاق منتجات. ابدأ بإطلاق نتائج.',
      sub: 'حدّثنا عن المنتج الذي تبنيه أو تُحدّثه أو تُنقذه. ثلاثون دقيقة. دون عرض ترويجي. إجابة صادقة عن قدرتنا على المساعدة.'
    }
  }
};
