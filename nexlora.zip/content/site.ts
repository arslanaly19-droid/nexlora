// Bilingual content for Home, About, Careers, Blog landing, Contact intro, Privacy, Terms
// All long-form static text lives here for clean separation from page renderers.

export type SiteContent = {
  home: {
    problem: { heading: string; headingEm: string; sub: string; cards: { num: string; title: string; body: string }[] };
    capabilities: { tag: string; heading: string; headingEm: string; sub: string };
    cases: { tag: string; heading: string; headingEm: string; sub: string };
    testimonials: { tag: string; heading: string; headingEm: string; items: { quote: string; name: string; role: string }[] };
    why: { tag: string; heading: string; headingEm: string; cards: { num: string; title: string; body: string }[] };
    process: { tag: string; heading: string; headingEm: string; steps: { num: string; title: string; body: string }[] };
    markets: { tag: string; heading: string; headingEm: string; sub: string; items: { flag: string; region: string; body: string }[] };
    cta: { heading: string; headingEm: string; sub: string };
  };
  about: {
    hero: { eyebrow: string; title: string; titleEm: string; sub: string };
    story: { heading: string; body: string };
    principles: { num: string; title: string; body: string }[];
    leadership: { name: string; role: string; bio: string }[];
    locations: { heading: string; body: string };
  };
  careers: {
    hero: { eyebrow: string; title: string; titleEm: string; sub: string };
    why: { heading: string; body: string; points: { title: string; body: string }[] };
    openings: { heading: string; body: string; roles: { title: string; location: string; type: string }[] };
    process: { heading: string; steps: { title: string; body: string }[] };
  };
  blog: {
    hero: { eyebrow: string; title: string; titleEm: string; sub: string };
    posts: { title: string; excerpt: string; category: string; date: string; readTime: string }[];
  };
  contact: {
    hero: { eyebrow: string; title: string; titleEm: string; sub: string };
    aside: { heading: string; body: string; channels: { label: string; value: string; href: string }[] };
  };
  privacy: { title: string; lastUpdated: string; sections: { heading: string; body: string }[] };
  terms: { title: string; lastUpdated: string; sections: { heading: string; body: string }[] };
};

export const site: { en: SiteContent; ar: SiteContent } = {
  en: {
    home: {
      problem: {
        heading: 'Three reasons most',
        headingEm: 'AI projects fail',
        sub: 'before they ship.',
        cards: [
          { num: '01', title: 'No tie to the P&L', body: 'Pilots that cannot draw a straight line to revenue, cost, or risk get killed at the next budget cycle. We refuse to start a build that has not earned its place on the income statement.' },
          { num: '02', title: 'Built for demos, not production', body: 'Most AI work falls over the second it touches real data, real users, and real load. Production is a discipline, not a phase. We start with deployment in mind.' },
          { num: '03', title: 'No skin in the game', body: 'Vendors that sell hours have no incentive to ship outcomes. We sell outcomes, fixed-price where possible, with measurement frameworks that name the metric in week one.' }
        ]
      },
      capabilities: {
        tag: 'Capabilities · 5 disciplines, one team',
        heading: 'Five disciplines.',
        headingEm: 'One team that ships.',
        sub: 'AI, product, cloud, advisory, and security — under one roof, run by senior operators, with the same standard from kickoff to handover.'
      },
      cases: {
        tag: 'Selected work',
        heading: 'Selected',
        headingEm: 'work that shipped.',
        sub: 'Three engagements in three markets. All in production. All measurable. None of them theatre.'
      },
      testimonials: {
        tag: 'Voices',
        heading: 'What partners say',
        headingEm: 'when the project ships.',
        items: [
          { quote: 'They did the work. The whole engagement was unusually quiet — which, for a senior team, is the highest compliment.', name: 'A. Khan', role: 'CTO, US fintech' },
          { quote: 'We had two failed migrations behind us before they arrived. They finished in ninety days.', name: 'M. Whitfield', role: 'IT Director, UK retailer' },
          { quote: 'The first vendor who built for our market, not at our market.', name: 'F. Al-Otaibi', role: 'Founder, Saudi PropTech' }
        ]
      },
      why: {
        tag: 'Why Nexlora',
        heading: 'Senior. Direct.',
        headingEm: 'Accountable.',
        cards: [
          { num: '01', title: 'Senior operators on every engagement', body: 'No analyst farms. No partner sells, junior delivers. The people you meet in week one are the people who own the work in week twelve.' },
          { num: '02', title: 'Outcomes, fixed-price, measured', body: 'Wherever the work is well-defined, we price the outcome and put the metric in writing. Skin in the game is a precondition, not a perk.' },
          { num: '03', title: 'Independent advice, always', body: 'Our advisory practice will tell you to use a different builder if that is the right answer. We have. The integrity of the advice is the entire business.' },
          { num: '04', title: 'Built for three regions, fluent in all of them', body: 'US contract conventions, UK regulatory expectations, Gulf cultural and procurement norms — we are native in all three. Cross-border work does not surprise us.' }
        ]
      },
      process: {
        tag: 'Process',
        heading: 'How the engagement',
        headingEm: 'actually runs.',
        steps: [
          { num: '01', title: 'Discovery', body: 'A two-week paid sprint that ends with a written, prioritized roadmap and a fixed-price proposal. If we cannot draw a line to the P&L, we say so.' },
          { num: '02', title: 'Design and architecture', body: 'Four to six weeks where the technology, the team, and the timeline get committed to writing — with you in the room for every decision.' },
          { num: '03', title: 'Delivery', body: 'Two-week sprints. Working software at the end of each. No surprises at the demo. We keep going until it is in production.' },
          { num: '04', title: 'Handover and standby', body: 'Documentation, runbooks, training, and a six-month standby period. We do not ghost after go-live.' }
        ]
      },
      markets: {
        tag: 'Markets',
        heading: 'Three regions.',
        headingEm: 'Native in each.',
        sub: 'We are not a US firm with a Gulf desk, or a London firm with a Riyadh email signature. We are senior on the ground in every market we serve.',
        items: [
          { flag: '🇺🇸', region: 'United States', body: 'East Coast operations from Reston. Mid-market and enterprise clients across financial services, healthtech, and SaaS. SOC 2, HIPAA, and US procurement norms in our DNA.' },
          { flag: '🇬🇧', region: 'United Kingdom', body: 'London-based delivery for UK and EU clients. UK GDPR, public-sector frameworks, and a strong financial-services bench. We work in pounds, on UK contracts, with UK references.' },
          { flag: '🇸🇦', region: 'GCC', body: 'Riyadh presence with active engagements across KSA, UAE, and Qatar. Vision 2030 alignment is not a buzzword for us — it is on our project list. NCA ECC and SAMA fluent.' }
        ]
      },
      cta: {
        heading: 'Stop running technology like an expense.',
        headingEm: 'Start running it like a weapon.',
        sub: 'A first conversation is thirty minutes, free, confidential, and always with a senior partner. Tell us what you are trying to do.'
      }
    },
    about: {
      hero: { eyebrow: 'About', title: 'Senior operators who got tired of', titleEm: 'watching technology fail badly.', sub: 'Nexlora exists because too many ambitious companies were buying expensive technology consulting and getting back nothing they could ship. We started a firm where partners do the work, the team is senior, and outcomes are non-negotiable.' },
      story: {
        heading: 'The firm we wished we could hire.',
        body: 'The founding partners had spent collectively over fifty years inside CTO offices, consultancies, and engineering organizations on three continents. Across all of it, the same pattern repeated: the technology decisions that mattered most were being made by junior teams under senior brand, with outcomes that disappointed everyone but the partner who sold the deal. We started Nexlora to do the opposite — a firm where the senior people are the engagement, the outcomes are written down, and the standard is the same whether the client is in Reston, London, or Riyadh. Three years in, that has not changed. It will not change.'
      },
      principles: [
        { num: '01', title: 'Outcomes over hours', body: 'We sell results, not seats. Wherever the work can be scoped, we price the outcome and put the metric in the contract. Hourly billing is for legacy work; outcomes are for serious work.' },
        { num: '02', title: 'Senior on every engagement', body: 'No analyst farms. No bait-and-switch staffing. The partners and senior engineers who pitch the work do the work. If we cannot staff it senior, we do not pitch it.' },
        { num: '03', title: 'Independent advice', body: 'Our advisory practice and our build practice are independent. We have recommended other builders. We will again. The integrity of the advice is more valuable than any single engagement.' },
        { num: '04', title: 'Plain language, always', body: 'No jargon for jargon\'s sake. No fake methodologies. Every recommendation we make should be defensible to your board in plain English. If we cannot explain it, we have not understood it.' }
      ],
      leadership: [
        { name: 'Founding Partner — Strategy', role: 'Twenty-plus years across CTO offices and global consulting. Led technology strategy for institutions on the Fortune 500 and the FTSE 100.', bio: '// TODO: replace with real leadership biography on go-live.' },
        { name: 'Founding Partner — Engineering', role: 'Career engineer turned operator. Built and shipped platforms in fintech, healthtech, and the public sector. Holds the line on engineering quality.', bio: '// TODO: replace with real leadership biography on go-live.' },
        { name: 'Founding Partner — Markets', role: 'Cross-border deal experience between the US, UK, and Gulf. Runs the regional partnerships and is responsible for senior client relationships across all three markets.', bio: '// TODO: replace with real leadership biography on go-live.' }
      ],
      locations: {
        heading: 'Three offices, three time zones, one standard.',
        body: 'Our Reston, Virginia office serves North American clients. Our London office serves the UK and EU. Our Riyadh office serves the GCC. Senior partners rotate across all three regularly. Travel for a single engagement is the norm, not the exception.'
      }
    },
    careers: {
      hero: { eyebrow: 'Careers', title: 'Senior people who want to', titleEm: 'do their best work.', sub: 'We do not hire to a headcount target. We hire when we meet someone who would obviously raise the bar. If that is you, we want to talk.' },
      why: {
        heading: 'What this place is, and what it is not.',
        body: 'We are a small firm by design. Every engagement is staffed senior. Compensation is at the top of the market. Politics are not tolerated. Travel happens. Bad meetings do not. If that sounds like an environment you would thrive in, read on.',
        points: [
          { title: 'Senior engagements only', body: 'You will not be staffed onto a team where you are the most junior person in the room. We do not hire for that role.' },
          { title: 'Compensation that respects you', body: 'Top-of-market base, performance-based bonus, profit share for partners. We do not hide the model.' },
          { title: 'Three regions, real travel', body: 'You will work with US, UK, and Gulf clients. Some of that work happens on the ground. We pay for it properly.' },
          { title: 'Rare politics', body: 'Decisions are made by the people doing the work. Promotions are made on outcomes. We have shown people the door for political behavior. We will again.' }
        ]
      },
      openings: {
        heading: 'Current openings',
        body: 'These roles are open until we meet the right person — not until a particular date. If your role is not listed and you would obviously raise the bar, write to us anyway.',
        roles: [
          { title: 'Principal AI Engineer', location: 'Reston / London / Riyadh', type: 'Full-time' },
          { title: 'Senior Cloud Architect', location: 'London / Reston', type: 'Full-time' },
          { title: 'Engagement Director — GCC', location: 'Riyadh', type: 'Full-time' },
          { title: 'Senior Product Designer', location: 'London / Remote', type: 'Full-time' },
          { title: 'Cybersecurity Principal', location: 'Reston / London', type: 'Full-time' }
        ]
      },
      process: {
        heading: 'How hiring works here.',
        steps: [
          { title: 'Conversation with a partner', body: 'No HR screen. The first call is with one of the founding partners. Forty-five minutes. We are evaluating whether you would raise the bar, and you are evaluating whether we are worth your time.' },
          { title: 'Work session', body: 'A paid two-to-three hour session on a real problem from our work. Not a hazing puzzle — a genuine collaboration to see how you think.' },
          { title: 'Reference deep-dive', body: 'We will talk to people you have actually worked with, in depth. We pay attention to the references the candidate did not suggest.' },
          { title: 'Offer, and a fast yes', body: 'We move quickly. If we want you, you will know within ten business days of the first conversation. We expect the same back.' }
        ]
      }
    },
    blog: {
      hero: { eyebrow: 'Field Notes', title: 'What we have learned,', titleEm: 'and what we are still figuring out.', sub: 'Notes from real engagements. No clickbait, no listicles, no SEO bait. Written by senior practitioners between client meetings.' },
      posts: [
        { title: 'Why most enterprise AI pilots never reach production', excerpt: 'Three patterns that kill 80 percent of AI initiatives before they ship — and what the 20 percent who succeed do differently.', category: 'AI & Data', date: 'Forthcoming', readTime: '9 min read' },
        { title: 'A 90-day cloud migration is possible. Here is what it costs you.', excerpt: 'The trade-offs you accept when you compress an eighteen-month migration into ninety days. The ones we accept, and the ones we will not.', category: 'Cloud', date: 'Forthcoming', readTime: '12 min read' },
        { title: 'Designing software for Saudi Arabia is not designing software with translation', excerpt: 'What we learned shipping an Arabic-first, RTL-native PropTech platform in Riyadh — and what most Western firms still get wrong.', category: 'Product', date: 'Forthcoming', readTime: '7 min read' },
        { title: 'The case against day-rate consulting in 2026', excerpt: 'Why hourly billing is structurally misaligned with outcomes — and how outcome-based pricing actually works in practice when you are honest about it.', category: 'Strategy', date: 'Forthcoming', readTime: '6 min read' },
        { title: 'Identity is the new perimeter, and most companies are still defending the wrong one', excerpt: 'How modern attacks bypass the firewall by logging in — and what a serious identity-first security posture looks like in 2026.', category: 'Security', date: 'Forthcoming', readTime: '11 min read' }
      ]
    },
    contact: {
      hero: { eyebrow: 'Contact', title: 'Tell us what you are', titleEm: 'trying to do.', sub: 'A senior partner will respond within one business day. We do not pass enquiries to junior staff. We do not have a sales-development team.' },
      aside: {
        heading: 'Skip the form. Reach us directly.',
        body: 'For sensitive enquiries, mergers and acquisitions diligence, or anything you would rather not type into a web form, the easiest way is email or phone.',
        channels: [
          { label: 'Email', value: 'hello@nexlora.com', href: 'mailto:hello@nexlora.com' },
          { label: 'Phone (US)', value: '+1 (202) 000-0000', href: 'tel:+12020000000' },
          { label: 'LinkedIn', value: 'linkedin.com/company/nexlora', href: 'https://linkedin.com' }
        ]
      }
    },
    privacy: {
      title: 'Privacy Policy',
      lastUpdated: 'Last updated: January 2026',
      sections: [
        { heading: 'Who we are', body: 'Nexlora Ltd is the controller for the personal data described in this policy. Our registered offices are in the United States, United Kingdom, and Saudi Arabia. For any privacy enquiry you can write to privacy@nexlora.com or use the contact form on our website. // REVIEW WITH COUNSEL: confirm the entity name, registered addresses, and any required additional disclosures for each jurisdiction in which Nexlora operates before publishing.' },
        { heading: 'What we collect', body: 'We collect information you give us when you contact us, subscribe to our newsletter, apply for a role, or engage us as a client. This typically includes your name, email address, phone number, employer, and any information you choose to share in a free-text message. When you visit our site we use a privacy-preserving analytics tool (Plausible) that does not set cookies or collect personal data. We do not use third-party advertising trackers.' },
        { heading: 'How we use it', body: 'We use your information to respond to you, to manage our client and candidate relationships, to send you newsletter content if you have subscribed, and to comply with our legal obligations. We do not sell or rent personal data to anyone, ever, for any reason.' },
        { heading: 'Legal basis (UK and EU)', body: 'For UK and EU residents, we rely on consent for marketing communications, legitimate interests for client relationship management, and contractual necessity where applicable. You can withdraw consent at any time. // REVIEW WITH COUNSEL: confirm specific Article 6 bases per processing activity.' },
        { heading: 'California rights (CCPA / CPRA)', body: 'If you are a California resident, you have the right to know what personal information we have collected, to request deletion, to correct inaccurate information, and to opt out of any sharing. Contact privacy@nexlora.com to exercise these rights. // REVIEW WITH COUNSEL: confirm any Shine the Light disclosures and metrics reporting requirements.' },
        { heading: 'GCC residents', body: 'If you are a resident of Saudi Arabia, the United Arab Emirates, or another GCC state, your data is processed in accordance with the relevant local data protection legislation, including the Saudi Personal Data Protection Law (PDPL) and the UAE Federal Data Protection Law where applicable. // REVIEW WITH COUNSEL: confirm cross-border transfer mechanisms in place.' },
        { heading: 'How long we keep it', body: 'Client and candidate records are kept for the duration of the relationship and for a period of up to seven years after, for legitimate business and legal reasons. Newsletter subscribers are kept until unsubscribed. // REVIEW WITH COUNSEL: confirm retention schedules.' },
        { heading: 'How to contact us', body: 'For any privacy question, request, or complaint, write to privacy@nexlora.com. UK and EU residents have the right to complain to a supervisory authority — in the UK, that is the Information Commissioner\'s Office (ico.org.uk).' }
      ]
    },
    terms: {
      title: 'Terms of Service',
      lastUpdated: 'Last updated: January 2026',
      sections: [
        { heading: 'Acceptance', body: 'By using the Nexlora website you agree to these terms. If you do not agree, do not use the site. // REVIEW WITH COUNSEL.' },
        { heading: 'Use of the site', body: 'The site is provided for general informational purposes. Nothing on it constitutes a binding offer to provide services. Engagements are governed by separate written agreements signed by both parties.' },
        { heading: 'Intellectual property', body: 'All content on the site — including text, images, design, and the Nexlora name and logo — is the property of Nexlora Ltd and may not be reproduced without written permission. // REVIEW WITH COUNSEL.' },
        { heading: 'Disclaimers', body: 'The site is provided "as is" without warranty of any kind. Nexlora is not liable for any indirect, incidental, or consequential damages arising from your use of the site. // REVIEW WITH COUNSEL: confirm enforceability across jurisdictions.' },
        { heading: 'Governing law', body: 'These terms are governed by the laws of England and Wales. Any dispute arising shall be subject to the exclusive jurisdiction of the courts of England and Wales. // REVIEW WITH COUNSEL: confirm jurisdiction is correct given the operating entity and client base.' },
        { heading: 'Changes', body: 'We may update these terms from time to time. The "last updated" date at the top will reflect any changes. Continued use of the site constitutes acceptance of the revised terms.' }
      ]
    }
  },
  ar: {
    home: {
      problem: {
        heading: 'ثلاثة أسباب لفشل معظم',
        headingEm: 'مشاريع الذكاء الاصطناعي',
        sub: 'قبل أن تُطلَق.',
        cards: [
          { num: '01', title: 'لا ارتباط بالأرباح والخسائر', body: 'النماذج الأوّلية التي لا تستطيع رسم خط مستقيم إلى الإيراد أو التكلفة أو المخاطرة تموت في دورة الميزانية التالية. نرفض بدء بناء لم يستحق مكانه على قائمة الدخل.' },
          { num: '02', title: 'مبنية للعروض، لا للإنتاج', body: 'معظم أعمال الذكاء الاصطناعي تنهار لحظة ملامستها لبيانات حقيقية ومستخدمين حقيقيين وحمل حقيقي. الإنتاج انضباط، لا مرحلة. نبدأ بالنشر في الذهن.' },
          { num: '03', title: 'لا حصة في اللعبة', body: 'البائعون الذين يبيعون ساعات لا حافز لديهم لتسليم نتائج. نحن نبيع نتائج، بسعر ثابت حيث أمكن، مع أُطر قياس تُسمّي المقياس في الأسبوع الأول.' }
        ]
      },
      capabilities: {
        tag: 'قدراتنا · ٥ تخصصات، فريق واحد',
        heading: 'خمسة تخصصات.',
        headingEm: 'فريق واحد يُسلّم.',
        sub: 'الذكاء الاصطناعي والمنتج والسحابة والاستشارة والأمان — تحت سقف واحد، يقوده مُشغّلون كبار، بنفس المعيار من البدء إلى التسليم.'
      },
      cases: {
        tag: 'أعمال مختارة',
        heading: 'أعمال مختارة',
        headingEm: 'تم تسليمها.',
        sub: 'ثلاثة مشاريع في ثلاثة أسواق. كلها في الإنتاج. كلها قابلة للقياس. لا واحد منها مسرحية.'
      },
      testimonials: {
        tag: 'أصوات',
        heading: 'ماذا يقول الشركاء',
        headingEm: 'عند تسليم المشروع.',
        items: [
          { quote: 'أنجزوا العمل. كان المشروع كله هادئاً بشكل غير معتاد — وهو، لفريق كبير، أعلى مدح.', name: 'أ. خان', role: 'CTO، شركة تقنية مالية أمريكية' },
          { quote: 'كان لدينا ترحيلان فاشلان قبل وصولهم. أنهَوا العمل في تسعين يوماً.', name: 'م. ويتفيلد', role: 'مدير تقنية المعلومات، شركة تجزئة بريطانية' },
          { quote: 'البائع الأوّل الذي بنى لسوقنا، لا على سوقنا.', name: 'ف. العتيبي', role: 'مؤسس، منصة عقارية سعودية' }
        ]
      },
      why: {
        tag: 'لماذا نكسلورا',
        heading: 'كبير. مباشر.',
        headingEm: 'مُحاسَب.',
        cards: [
          { num: '01', title: 'مُشغّلون كبار في كل مشروع', body: 'لا مزارع محلّلين. لا شريك يبيع وموظف مبتدئ يُسلّم. الأشخاص الذين تلتقيهم في الأسبوع الأوّل هم الذين يملكون العمل في الأسبوع الثاني عشر.' },
          { num: '02', title: 'نتائج، بسعر ثابت، مُقاسة', body: 'حيث يكون العمل محدّداً، نُسعّر النتيجة ونضع المقياس مكتوباً. الحصة في اللعبة شرط مسبق، لا ميزة.' },
          { num: '03', title: 'استشارة مستقلة دائماً', body: 'ممارستنا الاستشارية ستُخبرك باستخدام بانٍ آخر إذا كانت تلك هي الإجابة الصحيحة. وقد فعلنا. سلامة الاستشارة هي العمل بأكمله.' },
          { num: '04', title: 'مبني لثلاث مناطق، طليق فيها كلها', body: 'أعراف العقود الأمريكية، توقعات التنظيم البريطانية، أعراف الثقافة والمشتريات الخليجية — أصليون في الثلاثة. العمل عبر الحدود لا يُفاجئنا.' }
        ]
      },
      process: {
        tag: 'منهجيتنا',
        heading: 'كيف يجري المشروع',
        headingEm: 'فعلاً.',
        steps: [
          { num: '01', title: 'الاستكشاف', body: 'سبرنت مدفوع لأسبوعين ينتهي بخارطة طريق مكتوبة ومرتّبة وعرض بسعر ثابت. إذا لم نتمكن من رسم خط للأرباح والخسائر، فسنقولها.' },
          { num: '02', title: 'التصميم والمعمارية', body: 'من أربعة إلى ستة أسابيع تُلتزم فيها التقنية والفريق والجدول كتابةً — وأنت في الغرفة عند كل قرار.' },
          { num: '03', title: 'التسليم', body: 'سبرنتات أسبوعين. برمجيات عاملة في نهاية كل سبرنت. لا مفاجآت في العرض. نواصل حتى الإنتاج.' },
          { num: '04', title: 'التسليم والاستعداد', body: 'توثيق، أدلة تشغيل، تدريب، وفترة استعداد لستة أشهر. لا نختفي بعد الإطلاق.' }
        ]
      },
      markets: {
        tag: 'أسواقنا',
        heading: 'ثلاث مناطق.',
        headingEm: 'أصليون في كلٍ منها.',
        sub: 'لسنا شركة أمريكية بمكتب خليجي، ولا شركة لندنية بتوقيع بريد رياضي. نحن كبار على الأرض في كل سوق نخدمه.',
        items: [
          { flag: '🇺🇸', region: 'الولايات المتحدة', body: 'عمليات الساحل الشرقي من ريستون. عملاء سوق متوسط ومؤسسات في الخدمات المالية والصحة الرقمية والبرمجيات. SOC 2 وHIPAA وأعراف المشتريات الأمريكية في حمضنا النووي.' },
          { flag: '🇬🇧', region: 'المملكة المتحدة', body: 'تسليم من لندن لعملاء بريطانيا والاتحاد الأوروبي. UK GDPR، أُطر القطاع العام، خبرة قوية في الخدمات المالية. نعمل بالجنيه، بعقود بريطانية، بمراجع بريطانية.' },
          { flag: '🇸🇦', region: 'الخليج', body: 'حضور في الرياض مع مشاريع نشطة في السعودية والإمارات وقطر. التوافق مع رؤية ٢٠٣٠ ليس شعاراً — بل في قائمة مشاريعنا. طلاقة في NCA ECC وSAMA.' }
        ]
      },
      cta: {
        heading: 'توقّف عن إدارة التقنية كمصروف.',
        headingEm: 'ابدأ بإدارتها كسلاح.',
        sub: 'المحادثة الأولى ثلاثون دقيقة، مجانية، سرّية، ودائماً مع شريك كبير. أخبرنا بما تحاول فعله.'
      }
    },
    about: {
      hero: { eyebrow: 'من نحن', title: 'مُشغّلون كبار سئموا', titleEm: 'مشاهدة فشل التقنية بشكل سيئ.', sub: 'وُجدت نكسلورا لأن كثيراً من الشركات الطموحة كانت تشتري استشارات تقنية باهظة وتعود بلا شيء قابل للتسليم. أسّسنا شركة يقوم فيها الشركاء بالعمل، والفريق كبير، والنتائج غير قابلة للتفاوض.' },
      story: {
        heading: 'الشركة التي تمنّينا أن نوظّفها.',
        body: 'الشركاء المؤسّسون أمضوا مجتمعين أكثر من خمسين عاماً داخل مكاتب مديرين تقنيين وشركات استشارية ومنظمات هندسية في ثلاث قارات. عبر كل ذلك، تكرّر النمط نفسه: قرارات التقنية الأهم تُتخذ بفِرَق مبتدئة تحت علامة كبيرة، بنتائج أحبطت الجميع باستثناء الشريك الذي باع الصفقة. أسّسنا نكسلورا للقيام بالعكس — شركة الأشخاص الكبار فيها هم المشروع، النتائج مكتوبة، والمعيار موحَّد سواء كان العميل في ريستون أو لندن أو الرياض. مرّت ثلاث سنوات، ولم يتغيّر هذا. ولن يتغيّر.'
      },
      principles: [
        { num: '01', title: 'النتائج فوق الساعات', body: 'نبيع نتائج، لا مقاعد. حيث يُمكن تحديد العمل، نُسعّر النتيجة ونضع المقياس في العقد. الفوترة بالساعة للعمل القديم؛ النتائج للعمل الجدّي.' },
        { num: '02', title: 'كبير في كل مشروع', body: 'لا مزارع محلّلين. لا تبديل وهمي للموظفين. الشركاء وكبار المهندسين الذين يقدّمون العرض هم من يُنفّذون. إذا لم نستطع التوظيف بمستوى كبير، فلن نتقدّم.' },
        { num: '03', title: 'استشارة مستقلة', body: 'ممارستنا الاستشارية وممارسة البناء مستقلتان. أوصينا ببانين آخرين. وسنفعل مجدداً. سلامة الاستشارة أثمن من أي مشروع منفرد.' },
        { num: '04', title: 'لغة واضحة دائماً', body: 'لا مصطلحات لمجرد المصطلحات. لا منهجيات وهمية. كل توصية نُقدّمها يجب أن تكون قابلة للدفاع أمام مجلسك بالعربية الواضحة. إذا لم نستطع شرحها، لم نفهمها.' }
      ],
      leadership: [
        { name: 'شريك مؤسّس — الاستراتيجية', role: 'أكثر من عشرين عاماً عبر مكاتب CTO والاستشارات العالمية. قاد استراتيجية التقنية لمؤسسات في Fortune 500 وFTSE 100.', bio: '// TODO: استبدال بسيرة قيادية حقيقية عند الإطلاق.' },
        { name: 'شريك مؤسّس — الهندسة', role: 'مهندس مهني تحوّل إلى مُشغّل. بنى وسلّم منصات في التقنية المالية والصحة الرقمية والقطاع العام. يحفظ خط جودة الهندسة.', bio: '// TODO: استبدال بسيرة قيادية حقيقية عند الإطلاق.' },
        { name: 'شريك مؤسّس — الأسواق', role: 'خبرة في الصفقات عبر الحدود بين أمريكا وبريطانيا والخليج. يُدير الشراكات الإقليمية، ومسؤول عن العلاقات مع كبار العملاء عبر الأسواق الثلاثة.', bio: '// TODO: استبدال بسيرة قيادية حقيقية عند الإطلاق.' }
      ],
      locations: {
        heading: 'ثلاثة مكاتب، ثلاث مناطق زمنية، معيار واحد.',
        body: 'مكتبنا في ريستون، فيرجينيا يخدم عملاء أمريكا الشمالية. مكتب لندن يخدم بريطانيا والاتحاد الأوروبي. مكتب الرياض يخدم الخليج. كبار الشركاء يتنقّلون عبر الثلاثة بانتظام. السفر لمشروع واحد هو القاعدة، لا الاستثناء.'
      }
    },
    careers: {
      hero: { eyebrow: 'الوظائف', title: 'أشخاص كبار يريدون', titleEm: 'تقديم أفضل ما لديهم.', sub: 'لا نوظّف وفق هدف عددي. نوظّف عندما نلتقي شخصاً يرفع المعيار بوضوح. إذا كان هذا أنت، نريد التحدث.' },
      why: {
        heading: 'ما هذا المكان، وما ليس.',
        body: 'نحن شركة صغيرة عن قصد. كل مشروع يُكلَّف بفريق كبير. التعويض في قمة السوق. السياسة لا تُتسامح معها. السفر يحدث. الاجتماعات السيئة لا. إذا بدا ذلك بيئة ستزدهر فيها، تابع.',
        points: [
          { title: 'مشاريع كبيرة فقط', body: 'لن تُكلَّف بفريق تكون فيه الأصغر سناً في الغرفة. لا نوظّف لذلك الدور.' },
          { title: 'تعويض يحترمك', body: 'راتب أساسي في قمة السوق، مكافأة على الأداء، حصة أرباح للشركاء. لا نُخفي النموذج.' },
          { title: 'ثلاث مناطق، سفر حقيقي', body: 'ستعمل مع عملاء أمريكا وبريطانيا والخليج. بعض ذلك يحدث على الأرض. ندفع ثمنه بشكل لائق.' },
          { title: 'سياسة نادرة', body: 'القرارات يتخذها من يُنفّذ العمل. الترقيات على النتائج. أرَيْنا أشخاصاً الباب لسلوك سياسي. وسنفعل مجدداً.' }
        ]
      },
      openings: {
        heading: 'الوظائف المفتوحة',
        body: 'هذه الأدوار مفتوحة حتى نلتقي الشخص المناسب — لا حتى تاريخ معيّن. إذا لم يكن دورك مدرجاً وستُحدث فرقاً، اكتب إلينا على أيّ حال.',
        roles: [
          { title: 'مهندس ذكاء اصطناعي رئيسي', location: 'ريستون / لندن / الرياض', type: 'دوام كامل' },
          { title: 'معماري سحابة كبير', location: 'لندن / ريستون', type: 'دوام كامل' },
          { title: 'مدير مشاريع — الخليج', location: 'الرياض', type: 'دوام كامل' },
          { title: 'مصمم منتج كبير', location: 'لندن / عن بُعد', type: 'دوام كامل' },
          { title: 'رئيس أمن سيبراني', location: 'ريستون / لندن', type: 'دوام كامل' }
        ]
      },
      process: {
        heading: 'كيف يعمل التوظيف هنا.',
        steps: [
          { title: 'محادثة مع شريك', body: 'لا فلترة موارد بشرية. المكالمة الأولى مع أحد الشركاء المؤسّسين. خمس وأربعون دقيقة. نُقيّم ما إذا كنت سترفع المعيار، وأنت تُقيّم ما إذا كنّا نستحق وقتك.' },
          { title: 'جلسة عمل', body: 'جلسة مدفوعة لساعتين أو ثلاث على مشكلة حقيقية من عملنا. ليست لغزاً تعجيزياً — تعاون حقيقي لرؤية كيف تُفكّر.' },
          { title: 'مراجعة مراجع عميقة', body: 'سنتحدث مع أشخاص عملت معهم فعلاً، بعمق. ننتبه للمراجع التي لم يقترحها المرشّح.' },
          { title: 'عرض، وموافقة سريعة', body: 'نتحرّك بسرعة. إذا أردناك، ستعرف خلال عشرة أيام عمل من المحادثة الأولى. نتوقّع المثل بالمقابل.' }
        ]
      }
    },
    blog: {
      hero: { eyebrow: 'ملاحظات ميدانية', title: 'ما تعلّمناه،', titleEm: 'وما لا نزال نُحاول فهمه.', sub: 'ملاحظات من مشاريع حقيقية. لا عناوين جذّابة، لا قوائم، لا طُعم لمحركات البحث. كتبها مُمارسون كبار بين اجتماعات العملاء.' },
      posts: [
        { title: 'لماذا لا تصل معظم تجارب الذكاء الاصطناعي المؤسسية إلى الإنتاج', excerpt: 'ثلاثة أنماط تقتل ٨٠٪ من مبادرات الذكاء الاصطناعي قبل التسليم — وما يفعله ٢٠٪ الناجحون باختلاف.', category: 'الذكاء الاصطناعي والبيانات', date: 'قريباً', readTime: 'قراءة ٩ دقائق' },
        { title: 'ترحيل سحابي في ٩٠ يوماً ممكن. هذا ما يُكلّفك.', excerpt: 'المفاضلات التي تقبلها عند ضغط ترحيل ثمانية عشر شهراً إلى تسعين يوماً. التي نقبلها، والتي لن نقبلها.', category: 'السحابة', date: 'قريباً', readTime: 'قراءة ١٢ دقيقة' },
        { title: 'تصميم برمجيات للسعودية ليس تصميماً مع الترجمة', excerpt: 'ما تعلّمناه من إطلاق منصة عقارية بالعربية أوّلاً من اليمين إلى اليسار في الرياض — وما لا تزال معظم الشركات الغربية تُخطئ فيه.', category: 'المنتج', date: 'قريباً', readTime: 'قراءة ٧ دقائق' },
        { title: 'الحجة ضد الاستشارة بالأجر اليومي في ٢٠٢٦', excerpt: 'لماذا الفوترة بالساعة غير متوافقة هيكلياً مع النتائج — وكيف تعمل التسعير على أساس النتائج فعلاً عند الصدق.', category: 'الاستراتيجية', date: 'قريباً', readTime: 'قراءة ٦ دقائق' },
        { title: 'الهوية هي المحيط الجديد، ومعظم الشركات تُدافع عن الخطأ', excerpt: 'كيف تتجاوز الهجمات الحديثة جدار الحماية بتسجيل الدخول — وكيف يبدو وضع أمان جدّي يبدأ بالهوية في ٢٠٢٦.', category: 'الأمن', date: 'قريباً', readTime: 'قراءة ١١ دقيقة' }
      ]
    },
    contact: {
      hero: { eyebrow: 'تواصل معنا', title: 'أخبرنا بما', titleEm: 'تحاول فعله.', sub: 'سيرد شريك كبير خلال يوم عمل واحد. لا نُمرّر الاستفسارات لموظفين مبتدئين. ليس لدينا فريق تطوير مبيعات.' },
      aside: {
        heading: 'تجاوز النموذج. تواصل معنا مباشرة.',
        body: 'للاستفسارات الحساسة أو العناية الواجبة لعمليات الاندماج والاستحواذ أو أي شيء تُفضّل عدم كتابته في نموذج ويب، أسهل طريقة هي البريد أو الهاتف.',
        channels: [
          { label: 'البريد الإلكتروني', value: 'hello@nexlora.com', href: 'mailto:hello@nexlora.com' },
          { label: 'الهاتف (أمريكا)', value: '+1 (202) 000-0000', href: 'tel:+12020000000' },
          { label: 'لينكد إن', value: 'linkedin.com/company/nexlora', href: 'https://linkedin.com' }
        ]
      }
    },
    privacy: {
      title: 'سياسة الخصوصية',
      lastUpdated: 'آخر تحديث: يناير ٢٠٢٦',
      sections: [
        { heading: 'من نحن', body: 'نكسلورا هي المتحكّم في البيانات الشخصية الموصوفة في هذه السياسة. مكاتبنا المسجّلة في الولايات المتحدة والمملكة المتحدة والمملكة العربية السعودية. لأي استفسار عن الخصوصية يمكنك الكتابة إلى privacy@nexlora.com أو استخدام نموذج الاتصال على موقعنا. // REVIEW WITH COUNSEL.' },
        { heading: 'ما الذي نجمعه', body: 'نجمع المعلومات التي تُقدّمها عند التواصل معنا أو الاشتراك في النشرة أو التقدّم لوظيفة أو التعاقد كعميل. عادةً يشمل ذلك اسمك وبريدك ورقم هاتفك وجهة عملك وأي معلومة تختار مشاركتها في رسالة. عند زيارة موقعنا نستخدم أداة تحليلات تحترم الخصوصية (Plausible) لا تضع كوكيز ولا تجمع بيانات شخصية. لا نستخدم متتبعات إعلانية من جهات خارجية.' },
        { heading: 'كيف نستخدمها', body: 'نستخدم معلوماتك للرد عليك وإدارة علاقات العملاء والمرشحين وإرسال محتوى النشرة إذا اشتركت والامتثال لالتزاماتنا القانونية. لا نبيع البيانات الشخصية أو نُؤجّرها لأي أحد، أبداً، لأي سبب.' },
        { heading: 'الأساس القانوني (بريطانيا والاتحاد الأوروبي)', body: 'لمقيمي بريطانيا والاتحاد الأوروبي، نعتمد على الموافقة للاتصالات التسويقية، والمصالح المشروعة لإدارة علاقات العملاء، والضرورة التعاقدية حيث ينطبق. يمكنك سحب الموافقة في أي وقت. // REVIEW WITH COUNSEL.' },
        { heading: 'حقوق كاليفورنيا (CCPA / CPRA)', body: 'إذا كنت مقيماً في كاليفورنيا، فلديك الحق في معرفة المعلومات الشخصية التي جمعناها وطلب حذفها وتصحيح المعلومات غير الدقيقة وإلغاء أي مشاركة. تواصل مع privacy@nexlora.com لممارسة هذه الحقوق. // REVIEW WITH COUNSEL.' },
        { heading: 'مقيمو الخليج', body: 'إذا كنت مقيماً في المملكة العربية السعودية أو الإمارات أو دولة خليجية أخرى، تُعالَج بياناتك وفق التشريعات المحلية لحماية البيانات، بما في ذلك نظام حماية البيانات الشخصية السعودي (PDPL) والقانون الاتحادي الإماراتي حيث ينطبق. // REVIEW WITH COUNSEL.' },
        { heading: 'كم نحتفظ بها', body: 'تُحفَظ سجلات العملاء والمرشحين طوال مدة العلاقة وفترة تصل إلى سبع سنوات بعدها لأسباب عمل وقانون مشروعة. يُحفظ المشتركون في النشرة حتى إلغاء الاشتراك. // REVIEW WITH COUNSEL.' },
        { heading: 'كيف تتواصل معنا', body: 'لأي سؤال أو طلب أو شكوى عن الخصوصية، اكتب إلى privacy@nexlora.com. لمقيمي بريطانيا والاتحاد الأوروبي حق الشكوى لسلطة إشرافية — في بريطانيا، هي مكتب مفوّض المعلومات (ico.org.uk).' }
      ]
    },
    terms: {
      title: 'شروط الاستخدام',
      lastUpdated: 'آخر تحديث: يناير ٢٠٢٦',
      sections: [
        { heading: 'القبول', body: 'باستخدام موقع نكسلورا فأنت توافق على هذه الشروط. إذا لم توافق، فلا تستخدم الموقع. // REVIEW WITH COUNSEL.' },
        { heading: 'استخدام الموقع', body: 'يُقدَّم الموقع لأغراض إعلامية عامة. لا شيء فيه يُشكّل عرضاً ملزماً لتقديم خدمات. تخضع المشاريع لاتفاقيات مكتوبة منفصلة موقّعة من الطرفين.' },
        { heading: 'الملكية الفكرية', body: 'كل المحتوى على الموقع — بما فيه النصوص والصور والتصميم واسم وشعار نكسلورا — ملك لنكسلورا، ولا يجوز استنساخه دون إذن مكتوب. // REVIEW WITH COUNSEL.' },
        { heading: 'إخلاء المسؤولية', body: 'يُقدَّم الموقع "كما هو" دون أي ضمان. نكسلورا غير مسؤولة عن أي أضرار غير مباشرة أو عرضية أو تبعية ناجمة عن استخدامك للموقع. // REVIEW WITH COUNSEL.' },
        { heading: 'القانون الحاكم', body: 'تخضع هذه الشروط لقوانين إنجلترا وويلز. أي نزاع يخضع للاختصاص الحصري لمحاكم إنجلترا وويلز. // REVIEW WITH COUNSEL.' },
        { heading: 'التغييرات', body: 'قد نُحدّث هذه الشروط من حين لآخر. سيعكس تاريخ "آخر تحديث" في الأعلى أي تغييرات. الاستمرار في استخدام الموقع يُشكّل قبولاً للشروط المُعدَّلة.' }
      ]
    }
  }
};
