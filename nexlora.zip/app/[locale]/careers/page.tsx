import type { Metadata } from 'next';
import { setRequestLocale } from 'next-intl/server';
import { site } from '@/content/site';
import type { Locale } from '@/i18n';

export async function generateMetadata({ params }: { params: Promise<{ locale: Locale }> }): Promise<Metadata> {
  const { locale } = await params;
  const c = site[locale].careers;
  return {
    title: locale === 'ar' ? 'الوظائف — نكسلورا' : 'Careers — Nexlora',
    description: c.hero.sub.slice(0, 160)
  };
}

export default async function CareersPage({ params }: { params: Promise<{ locale: Locale }> }) {
  const { locale } = await params;
  setRequestLocale(locale);
  const c = site[locale].careers;

  return (
    <>
      <section className="relative bg-[#060C18] text-white pt-[140px] pb-24 px-6 md:px-[52px] overflow-hidden">
        <div className="hero-grain" />
        <div className="hero-grid" />
        <div className="relative z-10 max-w-[1160px] mx-auto">
          <div className="font-mono text-[12px] tracking-[0.18em] uppercase text-[#E8C97A] mb-6 r v">{c.hero.eyebrow}</div>
          <h1 className="font-display font-black text-[clamp(40px,7vw,80px)] leading-[1.04] tracking-tight mb-8 r v" style={{ transitionDelay: '.1s' }}>
            {c.hero.title} <br />
            <span className="text-[#E8C97A] italic">{c.hero.titleEm}</span>
          </h1>
          <p className="max-w-[760px] text-[18px] leading-[1.7] text-white/65 r v" style={{ transitionDelay: '.2s' }}>
            {c.hero.sub}
          </p>
        </div>
      </section>

      {/* WHY */}
      <section className="section bg-white">
        <div className="wrap">
          <div className="mb-16 max-w-[760px]">
            <div className="tag mb-3 r">{locale === 'ar' ? 'ما نحن، وما لسنا' : 'What this place is'}</div>
            <h2 className="sh r" style={{ transitionDelay: '.1s' }}>{c.why.heading}</h2>
            <p className="mt-6 text-[17px] text-[#64748B] leading-[1.85] r" style={{ transitionDelay: '.15s' }}>{c.why.body}</p>
          </div>
          <div className="grid md:grid-cols-2 gap-6">
            {c.why.points.map((p, i) => (
              <div key={i} className="bg-[#F8FAFD] border border-[#E2E8F0] p-8 rounded-2xl r" style={{ transitionDelay: `${i * 0.06}s` }}>
                <h3 className="font-display text-[20px] font-bold text-[#060C18] mb-3 leading-tight">{p.title}</h3>
                <p className="text-[14px] text-[#64748B] leading-[1.8]">{p.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* OPENINGS */}
      <section className="section bg-[#F8FAFD]">
        <div className="wrap">
          <div className="mb-12 max-w-[760px]">
            <div className="tag mb-3 r">{locale === 'ar' ? 'الوظائف الشاغرة' : 'Open roles'}</div>
            <h2 className="sh r" style={{ transitionDelay: '.1s' }}>{c.openings.heading}</h2>
            <p className="mt-6 text-[17px] text-[#64748B] leading-[1.85] r" style={{ transitionDelay: '.15s' }}>{c.openings.body}</p>
          </div>
          <ul className="divide-y divide-[#E2E8F0] border-y border-[#E2E8F0] bg-white rounded-xl">
            {c.openings.roles.map((role, i) => (
              <li key={i} className="flex flex-wrap items-center justify-between gap-4 px-8 py-6 hover:bg-[#F8FAFD] transition-colors">
                <div>
                  <h3 className="font-display text-[18px] font-bold text-[#060C18] mb-1">{role.title}</h3>
                  <div className="font-mono text-[12px] text-[#94A3B8] tracking-wide">{role.location} · {role.type}</div>
                </div>
                <a href={`mailto:careers@nexlora.com?subject=${encodeURIComponent(role.title)}`} className="btn-bordered text-[#060C18] border-[#060C18] !px-6 !py-3 text-[13px]">
                  {locale === 'ar' ? 'تقدّم' : 'Apply'}
                </a>
              </li>
            ))}
          </ul>
          <p className="mt-10 text-[14px] text-[#64748B] max-w-[640px]">
            {locale === 'ar'
              ? 'لا ترى دورك؟ اكتب إلى '
              : 'Don\'t see your role? Write to '}
            <a href="mailto:careers@nexlora.com" className="text-[#1E3A8A] font-medium underline">careers@nexlora.com</a>
            {locale === 'ar' ? ' وأخبرنا لماذا ستفع المعيار.' : ' and tell us why you would raise the bar.'}
          </p>
        </div>
      </section>

      {/* PROCESS */}
      <section className="section bg-white">
        <div className="wrap">
          <div className="mb-16 max-w-[640px]">
            <div className="tag mb-3 r">{locale === 'ar' ? 'العملية' : 'Process'}</div>
            <h2 className="sh r" style={{ transitionDelay: '.1s' }}>{c.process.heading}</h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {c.process.steps.map((step, i) => (
              <div key={i} className="bg-[#F8FAFD] border border-[#E2E8F0] p-8 rounded-2xl r" style={{ transitionDelay: `${i * 0.06}s` }}>
                <div className="font-mono text-[12px] text-[#C9A84C] tracking-[0.2em] mb-4">0{i + 1}</div>
                <h3 className="font-display text-[18px] font-bold text-[#060C18] mb-3 leading-tight">{step.title}</h3>
                <p className="text-[14px] text-[#64748B] leading-[1.8]">{step.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
