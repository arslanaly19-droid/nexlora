import type { Metadata } from 'next';
import { setRequestLocale } from 'next-intl/server';
import { site } from '@/content/site';
import type { Locale } from '@/i18n';

export async function generateMetadata({ params }: { params: Promise<{ locale: Locale }> }): Promise<Metadata> {
  const { locale } = await params;
  const c = site[locale].blog;
  return {
    title: locale === 'ar' ? 'ملاحظات الميدان — نكسلورا' : 'Field Notes — Nexlora',
    description: c.hero.sub.slice(0, 160)
  };
}

export default async function BlogPage({ params }: { params: Promise<{ locale: Locale }> }) {
  const { locale } = await params;
  setRequestLocale(locale);
  const c = site[locale].blog;

  return (
    <>
      <section className="relative bg-[#060C18] text-white pt-[140px] pb-20 px-6 md:px-[52px] overflow-hidden">
        <div className="hero-grain" />
        <div className="hero-grid" />
        <div className="relative z-10 max-w-[1160px] mx-auto">
          <div className="font-mono text-[12px] tracking-[0.18em] uppercase text-[#E8C97A] mb-6 r v">{c.hero.eyebrow}</div>
          <h1 className="font-display font-black text-[clamp(40px,7vw,80px)] leading-[1.04] tracking-tight mb-8 r v" style={{ transitionDelay: '.1s' }}>
            {c.hero.title} <br />
            <span className="text-[#E8C97A] italic">{c.hero.titleEm}</span>
          </h1>
          <p className="max-w-[680px] text-[18px] leading-[1.7] text-white/65 r v" style={{ transitionDelay: '.2s' }}>
            {c.hero.sub}
          </p>
        </div>
      </section>

      <section className="section bg-white">
        <div className="wrap">
          <div className="grid md:grid-cols-2 gap-6">
            {c.posts.map((post, i) => (
              <article
                key={i}
                className={`group ${i === 0 ? 'md:col-span-2 bg-[#0A1530] text-white' : 'bg-white border border-[#E2E8F0]'} p-10 rounded-2xl cursor-not-allowed r`}
                style={{ transitionDelay: `${i * 0.06}s` }}
                aria-label={locale === 'ar' ? 'قريباً' : 'Forthcoming'}
              >
                <div className={`font-mono text-[11px] uppercase tracking-[0.2em] mb-5 ${i === 0 ? 'text-[#E8C97A]' : 'text-[#C9A84C]'}`}>
                  {post.category} · {post.readTime}
                </div>
                <h2 className={`font-display ${i === 0 ? 'text-[28px] md:text-[36px]' : 'text-[22px]'} font-bold mb-4 leading-tight ${i === 0 ? '' : 'text-[#060C18]'}`}>
                  {post.title}
                </h2>
                <p className={`text-[15px] leading-[1.8] mb-6 ${i === 0 ? 'text-white/70' : 'text-[#64748B]'}`}>{post.excerpt}</p>
                <div className={`text-[12px] font-mono uppercase tracking-[0.18em] ${i === 0 ? 'text-white/50' : 'text-[#94A3B8]'}`}>
                  {post.date}
                </div>
              </article>
            ))}
          </div>
          <div className="mt-16 text-center max-w-[520px] mx-auto">
            <p className="text-[15px] text-[#64748B] leading-[1.8]">
              {locale === 'ar'
                ? 'سننشر هذه القطع قريباً. اشترك في القائمة البريدية لتصلك حين تصدر.'
                : 'These pieces are forthcoming. Subscribe to the mailing list and we will send each one when it ships.'}
            </p>
            <a href="mailto:hello@nexlora.com?subject=Subscribe" className="btn-bordered text-[#060C18] border-[#060C18] mt-8 inline-flex">
              {locale === 'ar' ? 'اشترك في النشرة' : 'Subscribe to Field Notes'}
            </a>
          </div>
        </div>
      </section>
    </>
  );
}
