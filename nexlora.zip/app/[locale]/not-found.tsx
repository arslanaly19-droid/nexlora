import Link from 'next/link';
import { useTranslations } from 'next-intl';

export default function NotFound() {
  const t = useTranslations('NotFound');

  return (
    <section className="bg-[#060C18] text-white min-h-[80vh] flex items-center justify-center px-6">
      <div className="text-center max-w-[520px]">
        <div className="font-mono text-[12px] tracking-[0.18em] uppercase text-[#E8C97A] mb-4">404</div>
        <h1 className="font-display font-black text-[clamp(40px,7vw,80px)] leading-[1.05] tracking-tight mb-6">
          {t('title')}
        </h1>
        <p className="text-[16px] text-white/65 leading-[1.7] mb-10">{t('body')}</p>
        <Link href="/" className="btn-gold">{t('backHome')}</Link>
      </div>
    </section>
  );
}
