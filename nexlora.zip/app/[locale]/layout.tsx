import { NextIntlClientProvider } from 'next-intl';
import { getMessages, setRequestLocale } from 'next-intl/server';
import { notFound } from 'next/navigation';
import { locales, type Locale } from '@/i18n';
import { Nav } from '@/components/nav';
import { Footer } from '@/components/footer';
import { ChatWidget } from '@/components/chat-widget';
import { CookieConsent } from '@/components/cookie-consent';
import { CursorEnhancer } from '@/components/cursor-enhancer';
import { Analytics } from '@/components/analytics';
import { OrganizationSchema } from '@/components/structured-data';
import { RevealObserver } from '@/components/reveal';

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

export default async function LocaleLayout({
  children,
  params
}: {
  children: React.ReactNode;
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  if (!locales.includes(locale as Locale)) notFound();
  setRequestLocale(locale);
  const messages = await getMessages();
  const dir = locale === 'ar' ? 'rtl' : 'ltr';

  return (
    <NextIntlClientProvider locale={locale} messages={messages}>
      <div lang={locale} dir={dir}>
        <a href="#main" className="skip-link">
          {messages.Nav?.skipToContent as string}
        </a>
        <Analytics />
        <OrganizationSchema />
        <CursorEnhancer />
        <RevealObserver />
        <Nav locale={locale} />
        <main id="main">{children}</main>
        <Footer locale={locale} />
        <ChatWidget />
        <CookieConsent />
      </div>
    </NextIntlClientProvider>
  );
}
