import type { Metadata } from 'next';
import { setRequestLocale } from 'next-intl/server';
import { site } from '@/content/site';
import type { Locale } from '@/i18n';

export async function generateMetadata({ params }: { params: Promise<{ locale: Locale }> }): Promise<Metadata> {
  const { locale } = await params;
  return {
    title: locale === 'ar' ? 'سياسة الخصوصية — نكسلورا' : 'Privacy Policy — Nexlora',
    description: locale === 'ar' ? 'كيف نتعامل مع بياناتك في نكسلورا.' : 'How Nexlora handles your data.',
    robots: { index: true, follow: true }
  };
}

export default async function PrivacyPage({ params }: { params: Promise<{ locale: Locale }> }) {
  const { locale } = await params;
  setRequestLocale(locale);
  const c = site[locale].privacy;

  return (
    <>
      <section className="bg-[#060C18] text-white pt-[140px] pb-16 px-6 md:px-[52px]">
        <div className="max-w-[820px] mx-auto">
          <h1 className="font-display font-black text-[44px] md:text-[60px] leading-[1.05] tracking-tight mb-4">{c.title}</h1>
          <p className="font-mono text-[12px] uppercase tracking-[0.18em] text-[#E8C97A]">{c.lastUpdated}</p>
        </div>
      </section>
      <section className="bg-white py-20 px-6 md:px-[52px]">
        <div className="max-w-[820px] mx-auto prose-content">
          {c.sections.map((s, i) => (
            <article key={i} className="mb-12">
              <h2 className="font-display text-[24px] font-bold text-[#060C18] mb-4 leading-tight">{s.heading}</h2>
              <p className="text-[16px] text-[#475569] leading-[1.85]">{s.body}</p>
            </article>
          ))}
        </div>
      </section>
    </>
  );
}
