import type { Metadata } from 'next';
import Link from 'next/link';
import { setRequestLocale, getTranslations } from 'next-intl/server';
import { HeroAurora } from '@/components/hero-aurora';
import { Ticker } from '@/components/ticker';
import { site } from '@/content/site';
import { servicesIndex } from '@/content/services';
import { caseStudies, caseStudySlugs } from '@/content/case-studies';
import type { Locale } from '@/i18n';

export async function generateMetadata({ params }: { params: Promise<{ locale: Locale }> }): Promise<Metadata> {
  const { locale } = await params;
  const t = await getTranslations({ locale, namespace: 'Hero' });
  return {
    title: locale === 'ar' ? 'نكسلورا — شريك التحول التكنولوجي' : 'Nexlora — AI-first technology partner',
    description: t('sub'),
    openGraph: {
      title: locale === 'ar' ? 'نكسلورا — شريك التحول التكنولوجي' : 'Nexlora — AI-first technology partner',
      description: t('sub'),
      type: 'website'
    }
  };
}

export default async function HomePage({ params }: { params: Promise<{ locale: Locale }> }) {
  const { locale } = await params;
  setRequestLocale(locale);
  const tHero = await getTranslations({ locale, namespace: 'Hero' });
  const tCommon = await getTranslations({ locale, namespace: 'Common' });
  const c = site[locale].home;
  const prefix = locale === 'en' ? '' : `/${locale}`;

  // Five capability cards mapped from services content
  const services = servicesIndex.map((s) => ({
    slug: s.slug,
    title: s.titles[locale],
    summary: s.summaries[locale]
  }));

  // Three case-study previews
  const cases = caseStudySlugs.map((slug) => {
    const cs = caseStudies[slug][locale];
    return { slug: cs.slug, eyebrow: cs.hero.eyebrow, title: cs.hero.title, titleEm: cs.hero.titleEm, sub: cs.hero.sub, region: cs.meta.region };
  });

  return (
    <>
      {/* HERO */}
      <section className="relative bg-[#060C18] text-white pt-[140px] pb-32 px-6 md:px-[52px] overflow-hidden min-h-[88vh] flex items-center">
        <HeroAurora />
        <div className="hero-grain" />
        <div className="hero-grid" />
        <div className="relative z-10 max-w-[1160px] mx-auto w-full">
          <div className="font-mono text-[12px] tracking-[0.18em] uppercase text-[#E8C97A] mb-8 r v flex items-center gap-3">
            <span className="inline-block w-8 h-px bg-[#E8C97A]" />
            {tHero('eyebrow')}
          </div>
          <h1 className="font-display font-black text-[clamp(48px,8vw,108px)] leading-[1.02] tracking-tight mb-10 r v" style={{ transitionDelay: '.1s' }}>
            {tHero('title')}
            <br />
            <span className="text-[#E8C97A] italic">{tHero('titleEm')}</span>
            <br />
            {tHero('titleEnd')}
          </h1>
          <p className="max-w-[720px] text-[19px] md:text-[21px] leading-[1.65] text-white/70 mb-12 r v" style={{ transitionDelay: '.2s' }}>
            {tHero('sub')}
          </p>
          <div className="flex flex-wrap gap-4 mb-20 r v" style={{ transitionDelay: '.3s' }}>
            <Link href={`${prefix}/contact`} className="btn-gold">{tCommon('bookDiscoveryCall')}</Link>
            <Link href={`${prefix}#capabilities`} className="btn-bordered">{tCommon('exploreCapabilities')}</Link>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 pt-12 border-t border-white/10 r v" style={{ transitionDelay: '.4s' }}>
            {[
              { v: '50+', l: locale === 'ar' ? 'مهندس أول' : 'Senior engineers' },
              { v: '3', l: locale === 'ar' ? 'مناطق' : 'Regions' },
              { v: '14d', l: locale === 'ar' ? 'متوسط مدة الاكتشاف' : 'Avg. discovery sprint' },
              { v: '100%', l: locale === 'ar' ? 'مشاريع مُنجزة' : 'Projects shipped' }
            ].map((s) => (
              <div key={s.l}>
                <div className="font-display text-[40px] md:text-[52px] font-black text-[#E8C97A] leading-none mb-2">{s.v}</div>
                <div className="text-[12px] text-white/55 uppercase tracking-[0.14em]">{s.l}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* TICKER */}
      <Ticker locale={locale} />

      {/* PROBLEM */}
      <section className="section bg-white">
        <div className="wrap">
          <div className="mb-16 max-w-[760px]">
            <div className="tag mb-4 r">{locale === 'ar' ? 'المشكلة' : 'The problem'}</div>
            <h2 className="sh r" style={{ transitionDelay: '.1s' }}>
              {c.problem.heading} <em>{c.problem.headingEm}</em> {c.problem.sub}
            </h2>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {c.problem.cards.map((card, i) => (
              <article key={card.num} className="border border-[#E2E8F0] bg-white p-10 rounded-2xl r" style={{ transitionDelay: `${0.1 + i * 0.08}s` }}>
                <div className="font-mono text-[12px] text-[#C9A84C] tracking-[0.2em] mb-5">{card.num}</div>
                <h3 className="font-display text-[24px] font-bold text-[#060C18] mb-4 leading-tight">{card.title}</h3>
                <p className="text-[15px] text-[#64748B] leading-[1.8]">{card.body}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* CAPABILITIES */}
      <section id="capabilities" className="section bg-[#F8FAFD]">
        <div className="wrap">
          <div className="mb-16 max-w-[760px]">
            <div className="tag mb-4 r">{c.capabilities.tag}</div>
            <h2 className="sh r" style={{ transitionDelay: '.1s' }}>
              {c.capabilities.heading} <em>{c.capabilities.headingEm}</em>
            </h2>
            <p className="mt-6 text-[17px] text-[#64748B] leading-[1.8] max-w-[680px] r" style={{ transitionDelay: '.15s' }}>
              {c.capabilities.sub}
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((s, i) => (
              <Link
                key={s.slug}
                href={`${prefix}/services/${s.slug}`}
                className="group bg-white border border-[#E2E8F0] p-8 rounded-2xl block hover:border-[#C9A84C] hover:shadow-[0_20px_60px_-20px_rgba(201,168,76,0.25)] transition-all duration-300 r"
                style={{ transitionDelay: `${i * 0.06}s` }}
              >
                <div className="font-mono text-[11px] text-[#C9A84C] tracking-[0.2em] mb-4">0{i + 1}</div>
                <h3 className="font-display text-[24px] font-bold text-[#060C18] mb-3 leading-tight group-hover:text-[#1E3A8A] transition-colors">{s.title}</h3>
                <p className="text-[14px] text-[#64748B] leading-[1.75] mb-6">{s.summary}</p>
                <span className="inline-flex items-center gap-2 text-[13px] font-medium text-[#1E3A8A] group-hover:gap-3 transition-all">
                  {tCommon('readMore')} <span aria-hidden>→</span>
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CASES */}
      <section className="section bg-white">
        <div className="wrap">
          <div className="mb-16 max-w-[760px] flex items-end justify-between flex-wrap gap-6">
            <div>
              <div className="tag mb-4 r">{c.cases.tag}</div>
              <h2 className="sh r" style={{ transitionDelay: '.1s' }}>
                {c.cases.heading} <em>{c.cases.headingEm}</em>
              </h2>
              <p className="mt-6 text-[17px] text-[#64748B] leading-[1.8] max-w-[600px] r" style={{ transitionDelay: '.15s' }}>{c.cases.sub}</p>
            </div>
            <Link href={`${prefix}/case-studies`} className="btn-bordered text-[#060C18] border-[#060C18]">{tCommon('viewAllCases')}</Link>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {cases.map((cs, i) => (
              <Link
                key={cs.slug}
                href={`${prefix}/case-studies/${cs.slug}`}
                className="group bg-[#060C18] text-white p-8 rounded-2xl block hover:bg-[#0A1530] transition-all duration-300 r"
                style={{ transitionDelay: `${i * 0.08}s` }}
              >
                <div className="font-mono text-[11px] text-[#E8C97A] tracking-[0.2em] mb-5">{cs.region}</div>
                <h3 className="font-display text-[22px] font-bold mb-3 leading-tight">
                  {cs.title} <span className="text-[#E8C97A] italic">{cs.titleEm}</span>
                </h3>
                <p className="text-[14px] text-white/65 leading-[1.7] mb-6 line-clamp-4">{cs.sub}</p>
                <span className="inline-flex items-center gap-2 text-[13px] font-medium text-[#E8C97A] group-hover:gap-3 transition-all">
                  {tCommon('readCaseStudy')} <span aria-hidden>→</span>
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="section bg-[#0A1530] text-white">
        <div className="wrap">
          <div className="mb-16 max-w-[760px]">
            <div className="tag !text-[#E8C97A] mb-4 r">{c.testimonials.tag}</div>
            <h2 className="sh light r" style={{ transitionDelay: '.1s' }}>
              {c.testimonials.heading} <em>{c.testimonials.headingEm}</em>
            </h2>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {c.testimonials.items.map((t, i) => (
              <figure key={i} className="bg-white/5 border border-white/10 backdrop-blur p-8 rounded-2xl r" style={{ transitionDelay: `${i * 0.08}s` }}>
                <blockquote className="font-display text-[19px] leading-[1.55] text-white mb-8 italic">&ldquo;{t.quote}&rdquo;</blockquote>
                <figcaption>
                  <div className="font-medium text-[14px] text-white">{t.name}</div>
                  <div className="text-[12px] text-white/55 mt-1">{t.role}</div>
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      {/* WHY */}
      <section className="section bg-white">
        <div className="wrap">
          <div className="mb-16 max-w-[760px]">
            <div className="tag mb-4 r">{c.why.tag}</div>
            <h2 className="sh r" style={{ transitionDelay: '.1s' }}>
              {c.why.heading} <em>{c.why.headingEm}</em>
            </h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {c.why.cards.map((card, i) => (
              <div key={card.num} className="bg-[#F8FAFD] border border-[#E2E8F0] p-8 rounded-2xl r" style={{ transitionDelay: `${i * 0.06}s` }}>
                <div className="font-mono text-[11px] text-[#C9A84C] tracking-[0.2em] mb-5">{card.num}</div>
                <h3 className="font-display text-[19px] font-bold text-[#060C18] mb-3 leading-tight">{card.title}</h3>
                <p className="text-[14px] text-[#64748B] leading-[1.75]">{card.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PROCESS */}
      <section className="section bg-[#F8FAFD]">
        <div className="wrap">
          <div className="mb-16 max-w-[760px]">
            <div className="tag mb-4 r">{c.process.tag}</div>
            <h2 className="sh r" style={{ transitionDelay: '.1s' }}>
              {c.process.heading} <em>{c.process.headingEm}</em>
            </h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {c.process.steps.map((step, i) => (
              <div key={step.num} className="bg-white border border-[#E2E8F0] p-8 rounded-2xl r" style={{ transitionDelay: `${i * 0.08}s` }}>
                <div className="font-mono text-[11px] text-[#C9A84C] tracking-[0.2em] mb-5">{step.num}</div>
                <h3 className="font-display text-[20px] font-bold text-[#060C18] mb-3 leading-tight">{step.title}</h3>
                <p className="text-[14px] text-[#64748B] leading-[1.75]">{step.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* MARKETS */}
      <section className="section bg-white">
        <div className="wrap">
          <div className="mb-16 max-w-[760px]">
            <div className="tag mb-4 r">{c.markets.tag}</div>
            <h2 className="sh r" style={{ transitionDelay: '.1s' }}>
              {c.markets.heading} <em>{c.markets.headingEm}</em>
            </h2>
            <p className="mt-6 text-[17px] text-[#64748B] leading-[1.8] max-w-[680px] r" style={{ transitionDelay: '.15s' }}>{c.markets.sub}</p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {c.markets.items.map((m, i) => (
              <div key={m.region} className="border border-[#E2E8F0] p-10 rounded-2xl r" style={{ transitionDelay: `${i * 0.08}s` }}>
                <div className="text-[44px] mb-5" aria-hidden>{m.flag}</div>
                <h3 className="font-display text-[22px] font-bold text-[#060C18] mb-3 leading-tight">{m.region}</h3>
                <p className="text-[15px] text-[#64748B] leading-[1.75]">{m.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="relative bg-[#060C18] text-white py-32 px-6 md:px-[52px] overflow-hidden">
        <div className="hero-grain" />
        <div className="hero-grid" />
        <div className="relative z-10 max-w-[1160px] mx-auto text-center">
          <h2 className="font-display font-black text-[clamp(36px,6vw,72px)] leading-[1.05] tracking-tight mb-8 r v">
            {c.cta.heading} <span className="text-[#E8C97A] italic">{c.cta.headingEm}</span>
          </h2>
          <p className="max-w-[600px] mx-auto text-[18px] leading-[1.7] text-white/65 mb-12 r v" style={{ transitionDelay: '.1s' }}>{c.cta.sub}</p>
          <div className="flex flex-wrap gap-4 justify-center r v" style={{ transitionDelay: '.2s' }}>
            <Link href={`${prefix}/contact`} className="btn-gold">{tCommon('bookDiscoveryCall')}</Link>
            <a href="mailto:hello@nexlora.com" className="btn-bordered">hello@nexlora.com</a>
          </div>
        </div>
      </section>
    </>
  );
}
