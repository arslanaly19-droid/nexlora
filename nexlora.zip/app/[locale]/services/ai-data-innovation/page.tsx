import type { Metadata } from 'next';
import { setRequestLocale } from 'next-intl/server';
import { ServicePage } from '@/components/service-page';
import { ServiceSchema } from '@/components/structured-data';
import { getService } from '@/content/services';

export async function generateMetadata({ params }: { params: Promise<{ locale: 'en' | 'ar' }> }): Promise<Metadata> {
  const { locale } = await params;
  const c = getService('ai-data-innovation', locale);
  return {
    title: c.hero.eyebrow,
    description: c.hero.sub.slice(0, 160),
    openGraph: { title: c.hero.eyebrow, description: c.hero.sub.slice(0, 160) }
  };
}

export default async function Page({ params }: { params: Promise<{ locale: 'en' | 'ar' }> }) {
  const { locale } = await params;
  setRequestLocale(locale);
  const content = getService('ai-data-innovation', locale);
  const url = `${process.env.NEXT_PUBLIC_SITE_URL || 'https://nexlora.com'}${locale === 'en' ? '' : '/ar'}/services/ai-data-innovation`;
  return (
    <>
      <ServiceSchema name={content.hero.eyebrow} description={content.hero.sub} url={url} />
      <ServicePage content={content} locale={locale} />
    </>
  );
}
