import type { Metadata } from 'next';
import Link from 'next/link';
import { setRequestLocale, getTranslations } from 'next-intl/server';
import { site } from '@/content/site';
import type { Locale } from '@/i18n';

export async function generateMetadata({ params }: { params: Promise<{ locale: Locale }> }): Promise<Metadata> {
  const { locale } = await params;
  const c = site[locale].about;
  return {
    title: locale === 'ar' ? 'عن نكسلورا' : 'About — Nexlora',
    description: c.hero.sub.slice(0, 160),
    openGraph: { title: locale === 'ar' ? 'عن نكسلورا' : 'About — Nexlora', description: c.hero.sub.slice(0, 160) }
  };
}

export default async function AboutPage({ params }: { params: Promise<{ locale: Locale }> }) {
  const { locale } = await params;
  setRequestLocale(locale);
  const c = site[locale].about;
  const tCommon = await getTranslations({ locale, namespace: 'Common' });
  const prefix = locale === 'en' ? '' : `/${locale}`;

  return (
    <>
      {/* HERO */}
      <section className="relative bg-[#060C18] text-white pt-[140px] pb-24 px-6 md:px-[52px] overflow-hidden">
        <div className="hero-grain" />
        <div className="hero-grid" />
        <div className="relative z-10 max-w-[1160px] mx-auto">
          <div className="font-mono text-[12px] tracking-[0.18em] uppercase text-[#E8C97A] mb-6 r v">{c.hero.eyebrow}</div>
          <h1 className="font-display font-black text-[clamp(40px,7vw,84px)] leading-[1.04] tracking-tight mb-8 r v" style={{ transitionDelay: '.1s' }}>
            {c.hero.title} <br />
            <span className="text-[#E8C97A] italic">{c.hero.titleEm}</span>
          </h1>
          <p className="max-w-[760px] text-[18px] md:text-[19px] leading-[1.7] text-white/65 r v" style={{ transitionDelay: '.2s' }}>
            {c.hero.sub}
          </p>
        </div>
      </section>

      {/* STORY */}
      <section className="section bg-white">
        <div className="wrap grid lg:grid-cols-12 gap-12">
          <div className="lg:col-span-5">
            <h2 className="sh r">{c.story.heading}</h2>
          </div>
          <div className="lg:col-span-7">
            <p className="text-[17px] text-[#475569] leading-[1.85] r" style={{ transitionDelay: '.1s' }}>{c.story.body}</p>
          </div>
        </div>
      </section>

      {/* PRINCIPLES */}
      <section className="section bg-[#F8FAFD]">
        <div className="wrap">
          <div className="mb-16 max-w-[640px]">
            <div className="tag mb-3 r">{locale === 'ar' ? 'مبادئنا' : 'Principles'}</div>
            <h2 className="sh r" style={{ transitionDelay: '.1s' }}>{locale === 'ar' ? 'كيف نعمل' : 'How we work'}</h2>
          </div>
          <div className="grid md:grid-cols-2 gap-6">
            {c.principles.map((p, i) => (
              <div key={p.num} className="bg-white border border-[#E2E8F0] p-10 rounded-2xl r" style={{ transitionDelay: `${i * 0.06}s` }}>
                <div className="font-mono text-[12px] text-[#C9A84C] tracking-[0.2em] mb-4">{p.num}</div>
                <h3 className="font-display text-[22px] font-bold text-[#060C18] mb-3 leading-tight">{p.title}</h3>
                <p className="text-[15px] text-[#64748B] leading-[1.8]">{p.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* LEADERSHIP */}
      <section className="section bg-white">
        <div className="wrap">
          <div className="mb-16 max-w-[640px]">
            <div className="tag mb-3 r">{locale === 'ar' ? 'القيادة' : 'Leadership'}</div>
            <h2 className="sh r" style={{ transitionDelay: '.1s' }}>{locale === 'ar' ? 'الشركاء المؤسسون' : 'Founding partners'}</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {c.leadership.map((p, i) => (
              <div key={i} className="border border-[#E2E8F0] p-10 rounded-2xl r" style={{ transitionDelay: `${i * 0.08}s` }}>
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#E8C97A] to-[#C9A84C] mb-6" aria-hidden />
                <h3 className="font-display text-[20px] font-bold text-[#060C18] mb-2 leading-tight">{p.name}</h3>
                <p className="text-[14px] text-[#1E3A8A] mb-4 leading-snug">{p.role}</p>
                <p className="text-[13px] text-[#94A3B8] italic leading-relaxed">{p.bio}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* LOCATIONS */}
      <section className="section bg-[#0A1530] text-white">
        <div className="wrap grid lg:grid-cols-12 gap-12">
          <div className="lg:col-span-5">
            <div className="tag !text-[#E8C97A] mb-3 r">{locale === 'ar' ? 'مواقعنا' : 'Locations'}</div>
            <h2 className="sh light r" style={{ transitionDelay: '.1s' }}>{c.locations.heading}</h2>
          </div>
          <div className="lg:col-span-7">
            <p className="text-[17px] text-white/70 leading-[1.85] r" style={{ transitionDelay: '.1s' }}>{c.locations.body}</p>
            <div className="mt-10 grid grid-cols-3 gap-4">
              {[
                { f: '🇺🇸', n: 'Reston, VA' },
                { f: '🇬🇧', n: 'London' },
                { f: '🇸🇦', n: 'Riyadh' }
              ].map((l) => (
                <div key={l.n} className="border border-white/10 rounded-xl p-6 text-center">
                  <div className="text-3xl mb-3" aria-hidden>{l.f}</div>
                  <div className="text-[14px] text-white/80 font-medium">{l.n}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="section bg-white">
        <div className="wrap text-center max-w-[680px]">
          <h2 className="sh r mb-8">{locale === 'ar' ? 'هل تبني شيئاً جدياً؟' : 'Building something serious?'}</h2>
          <p className="text-[17px] text-[#64748B] leading-[1.8] mb-10 r" style={{ transitionDelay: '.1s' }}>
            {locale === 'ar'
              ? 'محادثة أولى مدتها ٣٠ دقيقة، مجاناً، مع شريك أول. خبرنا بما تحاول إنجازه.'
              : 'A first conversation is thirty minutes, free, and always with a senior partner. Tell us what you are trying to do.'}
          </p>
          <Link href={`${prefix}/contact`} className="btn-gold">{tCommon('bookDiscoveryCall')}</Link>
        </div>
      </section>
    </>
  );
}
