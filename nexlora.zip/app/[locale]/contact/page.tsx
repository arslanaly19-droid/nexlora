import type { Metadata } from 'next';
import { setRequestLocale } from 'next-intl/server';
import { ContactForm } from '@/components/contact-form';
import { site } from '@/content/site';
import type { Locale } from '@/i18n';

export async function generateMetadata({ params }: { params: Promise<{ locale: Locale }> }): Promise<Metadata> {
  const { locale } = await params;
  const c = site[locale].contact;
  return {
    title: locale === 'ar' ? 'تواصل — نكسلورا' : 'Contact — Nexlora',
    description: c.hero.sub.slice(0, 160),
    openGraph: { title: locale === 'ar' ? 'تواصل — نكسلورا' : 'Contact — Nexlora', description: c.hero.sub.slice(0, 160) }
  };
}

export default async function ContactPage({ params }: { params: Promise<{ locale: Locale }> }) {
  const { locale } = await params;
  setRequestLocale(locale);
  const c = site[locale].contact;

  return (
    <>
      {/* HERO */}
      <section className="relative bg-[#060C18] text-white pt-[140px] pb-20 px-6 md:px-[52px] overflow-hidden">
        <div className="hero-grain" />
        <div className="hero-grid" />
        <div className="relative z-10 max-w-[1160px] mx-auto">
          <div className="font-mono text-[12px] tracking-[0.18em] uppercase text-[#E8C97A] mb-6 r v">{c.hero.eyebrow}</div>
          <h1 className="font-display font-black text-[clamp(40px,7vw,80px)] leading-[1.04] tracking-tight mb-8 r v" style={{ transitionDelay: '.1s' }}>
            {c.hero.title} <br />
            <span className="text-[#E8C97A] italic">{c.hero.titleEm}</span>
          </h1>
          <p className="max-w-[680px] text-[18px] leading-[1.7] text-white/65 r v" style={{ transitionDelay: '.2s' }}>
            {c.hero.sub}
          </p>
        </div>
      </section>

      {/* FORM + ASIDE */}
      <section className="section bg-white">
        <div className="wrap grid lg:grid-cols-12 gap-16">
          {/* Form (8 cols) */}
          <div className="lg:col-span-7">
            <ContactForm locale={locale} />
          </div>

          {/* Aside (4 cols) */}
          <aside className="lg:col-span-5">
            <div className="bg-[#F8FAFD] border border-[#E2E8F0] rounded-2xl p-10 sticky top-32">
              <h2 className="font-display text-[24px] font-bold text-[#060C18] mb-3 leading-tight">{c.aside.heading}</h2>
              <p className="text-[14px] text-[#64748B] leading-[1.75] mb-8">{c.aside.body}</p>
              <ul className="space-y-5">
                {c.aside.channels.map((ch) => (
                  <li key={ch.label}>
                    <div className="font-mono text-[11px] uppercase tracking-[0.18em] text-[#94A3B8] mb-1">{ch.label}</div>
                    <a href={ch.href} className="text-[15px] text-[#060C18] font-medium hover:text-[#1E3A8A] transition-colors break-all">
                      {ch.value}
                    </a>
                  </li>
                ))}
              </ul>
              <div className="mt-10 pt-8 border-t border-[#E2E8F0]">
                <div className="font-mono text-[11px] uppercase tracking-[0.18em] text-[#94A3B8] mb-3">{locale === 'ar' ? 'مكاتبنا' : 'Offices'}</div>
                <ul className="space-y-2 text-[14px] text-[#475569]">
                  <li>🇺🇸 {locale === 'ar' ? 'ريستون، فرجينيا' : 'Reston, VA — United States'}</li>
                  <li>🇬🇧 {locale === 'ar' ? 'لندن' : 'London — United Kingdom'}</li>
                  <li>🇸🇦 {locale === 'ar' ? 'الرياض' : 'Riyadh — KSA'}</li>
                </ul>
              </div>
            </div>
          </aside>
        </div>
      </section>
    </>
  );
}
