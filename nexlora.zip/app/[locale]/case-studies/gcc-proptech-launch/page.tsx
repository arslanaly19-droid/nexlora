import type { Metadata } from 'next';
import { setRequestLocale } from 'next-intl/server';
import { CaseStudyPage } from '@/components/case-study-page';
import { getCaseStudy } from '@/content/case-studies';

export async function generateMetadata({ params }: { params: Promise<{ locale: 'en' | 'ar' }> }): Promise<Metadata> {
  const { locale } = await params;
  const c = getCaseStudy('gcc-proptech-launch', locale);
  return {
    title: `${c.hero.title} ${c.hero.titleEm}`,
    description: c.hero.sub.slice(0, 160)
  };
}

export default async function Page({ params }: { params: Promise<{ locale: 'en' | 'ar' }> }) {
  const { locale } = await params;
  setRequestLocale(locale);
  const content = getCaseStudy('gcc-proptech-launch', locale);
  return <CaseStudyPage content={content} locale={locale} />;
}
