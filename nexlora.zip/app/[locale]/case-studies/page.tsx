import type { Metadata } from 'next';
import Link from 'next/link';
import { setRequestLocale, getTranslations } from 'next-intl/server';
import { caseStudies, caseStudySlugs } from '@/content/case-studies';
import { RevealObserver } from '@/components/reveal';

export const metadata: Metadata = {
  title: 'Case Studies',
  description: 'Selected work from Nexlora — AI, cloud, and product engagements that shipped to production.'
};

export default async function Page({ params }: { params: Promise<{ locale: 'en' | 'ar' }> }) {
  const { locale } = await params;
  setRequestLocale(locale);
  const tCommon = await getTranslations('Common');
  const tFooter = await getTranslations('Footer');
  const prefix = locale === 'en' ? '' : `/${locale}`;

  return (
    <>
      <RevealObserver />
      <section className="relative bg-[#060C18] text-white pt-[140px] pb-24 px-6 md:px-[52px] overflow-hidden">
        <div className="hero-grain" />
        <div className="hero-grid" />
        <div className="relative z-10 max-w-[1160px] mx-auto">
          <div className="tag !text-[#E8C97A] mb-6 r v">{tFooter('caseStudies')}</div>
          <h1 className="font-display font-black text-[clamp(40px,7vw,80px)] leading-[1.04] tracking-tight mb-6 r v" style={{ transitionDelay: '.1s' }}>
            {locale === 'ar' ? 'أعمال شُحنت إلى ' : 'Work shipped to '}
            <span className="text-[#E8C97A] italic">{locale === 'ar' ? 'الإنتاج.' : 'production.'}</span>
          </h1>
          <p className="max-w-[680px] text-[18px] text-white/65 leading-[1.7] r v" style={{ transitionDelay: '.2s' }}>
            {locale === 'ar'
              ? 'ثلاثة مشاريع في ثلاثة أسواق. كلها قيد العمل اليوم. كلها بأرقام يمكن قياسها.'
              : 'Three engagements in three markets. All running in production today. All with numbers you can measure.'}
          </p>
        </div>
      </section>

      <section className="section bg-white">
        <div className="wrap grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {caseStudySlugs.map((slug, i) => {
            const c = caseStudies[slug][locale as 'en' | 'ar'];
            return (
              <Link
                key={slug}
                href={`${prefix}/case-studies/${slug}`}
                className="case-card block bg-[#F8FAFD] border border-[#E2E8F0] p-7 rounded-2xl hover:border-[#C9A84C] transition-all hover:-translate-y-1 r"
                style={{ transitionDelay: `${i * 0.08}s` }}
              >
                <div className="font-mono text-[10px] text-[#C9A84C] tracking-widest mb-4">{c.meta.region.toUpperCase()} · {c.meta.industry.toUpperCase()}</div>
                <h2 className="font-display text-[24px] font-bold text-[#060C18] mb-4 leading-tight">{c.hero.title} <span className="italic text-[#2B6FD4]">{c.hero.titleEm}</span></h2>
                <p className="text-[14px] text-[#64748B] leading-[1.7] mb-6">{c.hero.sub.slice(0, 180)}…</p>
                <div className="flex justify-between items-center pt-4 border-t border-[#E2E8F0]">
                  <span className="font-mono text-[11px] text-[#475569]">{c.meta.duration}</span>
                  <span className="font-syne text-[12px] font-bold text-[#C9A84C] tracking-wider">{tCommon('readCaseStudy')} →</span>
                </div>
              </Link>
            );
          })}
        </div>
      </section>
    </>
  );
}
