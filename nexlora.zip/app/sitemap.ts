import type { MetadataRoute } from 'next';
import { serviceSlugs } from '@/content/services';
import { caseStudySlugs } from '@/content/case-studies';
import { locales } from '@/i18n';

const STATIC_PATHS = [
  '',
  '/about',
  '/case-studies',
  '/contact',
  '/careers',
  '/blog',
  '/privacy',
  '/terms'
];

export default function sitemap(): MetadataRoute.Sitemap {
  const base = (process.env.NEXT_PUBLIC_SITE_URL || 'https://nexlora.com').replace(/\/$/, '');
  const now = new Date();
  const entries: MetadataRoute.Sitemap = [];

  for (const locale of locales) {
    const localePrefix = locale === 'en' ? '' : `/${locale}`;

    // Static pages
    for (const p of STATIC_PATHS) {
      entries.push({
        url: `${base}${localePrefix}${p}`,
        lastModified: now,
        changeFrequency: p === '' ? 'weekly' : 'monthly',
        priority: p === '' ? 1.0 : 0.7
      });
    }
    // Service pages
    for (const slug of serviceSlugs) {
      entries.push({
        url: `${base}${localePrefix}/services/${slug}`,
        lastModified: now,
        changeFrequency: 'monthly',
        priority: 0.85
      });
    }
    // Case study detail pages
    for (const slug of caseStudySlugs) {
      entries.push({
        url: `${base}${localePrefix}/case-studies/${slug}`,
        lastModified: now,
        changeFrequency: 'monthly',
        priority: 0.75
      });
    }
  }

  return entries;
}
