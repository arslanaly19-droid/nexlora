import type { Metadata } from 'next';
import { Playfair_Display, Syne, DM_Sans, JetBrains_Mono, Amiri, Tajawal } from 'next/font/google';
import './globals.css';

const playfair = Playfair_Display({
  subsets: ['latin'],
  weight: ['700', '900'],
  style: ['normal', 'italic'],
  variable: '--font-playfair',
  display: 'swap'
});

const syne = Syne({
  subsets: ['latin'],
  weight: ['400', '600', '700', '800'],
  variable: '--font-syne',
  display: 'swap'
});

const dmSans = DM_Sans({
  subsets: ['latin'],
  weight: ['300', '400', '500', '600'],
  variable: '--font-dm-sans',
  display: 'swap'
});

const jetbrains = JetBrains_Mono({
  subsets: ['latin'],
  weight: ['300', '400', '500'],
  variable: '--font-jetbrains',
  display: 'swap'
});

const amiri = Amiri({
  subsets: ['arabic'],
  weight: ['400', '700'],
  style: ['normal', 'italic'],
  variable: '--font-amiri',
  display: 'swap'
});

const tajawal = Tajawal({
  subsets: ['arabic'],
  weight: ['300', '400', '500', '700', '800'],
  variable: '--font-tajawal',
  display: 'swap'
});

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || 'https://nexlora.com'),
  title: {
    default: 'Nexlora — We Build What Moves the Needle',
    template: '%s · Nexlora'
  },
  description:
    'Nexlora is a senior-led, AI-first technology partner for ambitious companies in the US, UK, and Gulf. We embed intelligence into infrastructure, products, and operations.',
  keywords: [
    'AI consultancy',
    'technology partner',
    'digital transformation',
    'cloud migration',
    'product engineering',
    'Vision 2030',
    'GCC technology'
  ],
  authors: [{ name: 'Nexlora' }],
  creator: 'Nexlora',
  publisher: 'Nexlora Ltd',
  robots: { index: true, follow: true },
  openGraph: {
    type: 'website',
    siteName: 'Nexlora',
    title: 'Nexlora — Intelligence Forward',
    description:
      'Senior-led, AI-first technology partner for ambitious companies in the US, UK, and Gulf.',
    images: [{ url: '/og-image.png', width: 1200, height: 630, alt: 'Nexlora' }]
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Nexlora — Intelligence Forward',
    description: 'AI-first technology partner. US · UK · Gulf.',
    images: ['/og-image.png']
  },
  icons: {
    icon: '/favicon.ico',
    apple: '/apple-touch-icon.png'
  }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html
      className={`${playfair.variable} ${syne.variable} ${dmSans.variable} ${jetbrains.variable} ${amiri.variable} ${tajawal.variable}`}
    >
      <body>{children}</body>
    </html>
  );
}
