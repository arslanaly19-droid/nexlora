import Link from 'next/link';

// Root-level 404 — used only for paths outside [locale] namespace.
// In practice next-intl middleware normally redirects to a localized 404,
// but this is required for Next.js to satisfy build constraints.
export default function NotFound() {
  return (
    <html lang="en">
      <body>
        <section style={{ background: '#060C18', color: '#fff', minHeight: '80vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '24px', fontFamily: 'system-ui, -apple-system, sans-serif' }}>
          <div style={{ textAlign: 'center', maxWidth: 520 }}>
            <div style={{ fontFamily: 'monospace', fontSize: 12, letterSpacing: '0.18em', textTransform: 'uppercase', color: '#E8C97A', marginBottom: 16 }}>404</div>
            <h1 style={{ fontSize: 'clamp(40px,7vw,80px)', fontWeight: 900, lineHeight: 1.05, marginBottom: 24 }}>Page not found.</h1>
            <Link href="/" style={{ background: '#E8C97A', color: '#060C18', padding: '14px 28px', borderRadius: 8, textDecoration: 'none', fontWeight: 600 }}>
              Back home
            </Link>
          </div>
        </section>
      </body>
    </html>
  );
}
