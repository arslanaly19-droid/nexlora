import { NextResponse } from 'next/server';
import { z } from 'zod';
import { Resend } from 'resend';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const ContactSchema = z.object({
  name: z.string().trim().min(1).max(120),
  email: z.string().trim().email().max(200),
  company: z.string().trim().max(200).optional().default(''),
  role: z.string().trim().max(120).optional().default(''),
  budget: z.enum(['under-50k', '50k-150k', '150k-500k', '500k-plus', 'not-sure']).optional(),
  message: z.string().trim().min(10).max(8000),
  consent: z.union([z.literal('on'), z.literal('true'), z.literal(true), z.boolean()]).optional(),
  locale: z.enum(['en', 'ar']).optional().default('en'),
  // Honeypot — must be empty
  website: z.string().max(0).optional()
});

function escapeHtml(s: string): string {
  return s
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

function buildEmailBody(data: z.infer<typeof ContactSchema>): { html: string; text: string; subject: string } {
  const subject = `[Nexlora] New enquiry from ${data.name}${data.company ? ' (' + data.company + ')' : ''}`;
  const lines = [
    `Name: ${data.name}`,
    `Email: ${data.email}`,
    `Company: ${data.company || '—'}`,
    `Role: ${data.role || '—'}`,
    `Budget: ${data.budget || 'not stated'}`,
    `Locale: ${data.locale}`,
    '',
    'Message:',
    data.message
  ];
  const text = lines.join('\n');
  const html = `
    <div style="font-family: -apple-system, system-ui, Segoe UI, Roboto, sans-serif; max-width: 640px; margin: 0 auto; color: #060C18;">
      <h2 style="font-size: 18px; margin: 0 0 16px;">New enquiry from nexlora.com</h2>
      <table cellpadding="6" cellspacing="0" style="width: 100%; font-size: 14px; border-collapse: collapse;">
        <tr><td style="background:#F8FAFD;"><strong>Name</strong></td><td>${escapeHtml(data.name)}</td></tr>
        <tr><td style="background:#F8FAFD;"><strong>Email</strong></td><td><a href="mailto:${escapeHtml(data.email)}">${escapeHtml(data.email)}</a></td></tr>
        <tr><td style="background:#F8FAFD;"><strong>Company</strong></td><td>${escapeHtml(data.company || '—')}</td></tr>
        <tr><td style="background:#F8FAFD;"><strong>Role</strong></td><td>${escapeHtml(data.role || '—')}</td></tr>
        <tr><td style="background:#F8FAFD;"><strong>Budget</strong></td><td>${escapeHtml(data.budget || 'not stated')}</td></tr>
        <tr><td style="background:#F8FAFD;"><strong>Locale</strong></td><td>${data.locale}</td></tr>
      </table>
      <h3 style="font-size: 14px; margin: 24px 0 8px;">Message</h3>
      <div style="white-space: pre-wrap; padding: 16px; background: #F8FAFD; border-radius: 8px; font-size: 14px; line-height: 1.7;">${escapeHtml(data.message)}</div>
    </div>
  `;
  return { html, text, subject };
}

export async function POST(req: Request) {
  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 });
  }

  const parsed = ContactSchema.safeParse(raw);
  if (!parsed.success) {
    return NextResponse.json({ error: 'Validation failed', issues: parsed.error.flatten() }, { status: 400 });
  }
  const data = parsed.data;

  // Honeypot triggered (zod allows empty only) — silently OK so bots don't learn
  if ((raw as { website?: string })?.website) {
    return NextResponse.json({ ok: true });
  }

  const { html, text, subject } = buildEmailBody(data);
  const apiKey = process.env.RESEND_API_KEY;
  const from = process.env.RESEND_FROM_EMAIL || 'Nexlora <onboarding@resend.dev>';
  const to = process.env.CONTACT_TO_EMAIL || 'hello@nexlora.com';

  // Fallback: no API key → log + return success (dev mode)
  if (!apiKey) {
    console.log('[contact] No RESEND_API_KEY set — would send email:', { to, from, subject, text });
    return NextResponse.json({ ok: true, mode: 'logged' });
  }

  try {
    const resend = new Resend(apiKey);
    const { error } = await resend.emails.send({
      from,
      to: [to],
      replyTo: data.email,
      subject,
      html,
      text
    });
    if (error) {
      console.error('[contact] Resend error:', error);
      return NextResponse.json({ error: 'Email service error' }, { status: 502 });
    }
    return NextResponse.json({ ok: true, mode: 'sent' });
  } catch (err) {
    console.error('[contact] Send failed:', err);
    return NextResponse.json({ error: 'Could not send' }, { status: 500 });
  }
}
