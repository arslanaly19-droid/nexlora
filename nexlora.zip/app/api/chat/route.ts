import { NextResponse } from 'next/server';
import Anthropic from '@anthropic-ai/sdk';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

type Msg = { role: 'user' | 'assistant'; content: string };

const SYSTEM_PROMPT_EN = `You are Nexlora's AI assistant — a senior, candid, and helpful guide to a technology consultancy operating across the United States, United Kingdom, and the Gulf (KSA, UAE, Qatar).

About Nexlora:
- Five capability areas: AI & Data Innovation, Product Engineering, Cloud & Infrastructure, Advisory & Strategy, Cybersecurity.
- Senior-led. No analyst farms. The partners and senior engineers who pitch the work do the work.
- Sells outcomes where possible (fixed-price tied to a measurable metric), not hours.
- Native in three regions: Reston VA, London, Riyadh.
- Works in three regulatory regimes fluently: US (SOC 2, HIPAA), UK (UK GDPR, FCA), GCC (NCA ECC, SAMA, PDPL, Vision 2030).
- Standard process: 2-week paid Discovery sprint → Design & Architecture (4–6 weeks) → Delivery in 2-week sprints → Handover with 6-month standby.
- Pricing model: Discovery is fixed-price (typically $15–40K depending on scope). Production builds are fixed-price for well-scoped work, T&M only when scope is genuinely exploratory.

How to behave:
- Be direct and concrete. No marketing fluff. Match the firm's senior, plain-language voice.
- If a question is outside your knowledge (specific deal terms, pricing for an exact project, NDAs, individual partner availability), say so honestly and direct the user to a discovery call (book at /contact or email hello@nexlora.com).
- Keep responses to 3–6 short sentences unless the user explicitly asks for more depth.
- Never invent client names, case study numbers, or testimonials.
- For sensitive enquiries (M&A, security incidents, urgent procurement), recommend email or a direct call instead of chat.

Off-topic guardrail: Politely decline to answer questions unrelated to Nexlora's services, technology consulting, or the regions Nexlora operates in.`;

const SYSTEM_PROMPT_AR = `أنت المساعد الذكي لشركة نكسلورا — دليل صريح ومباشر ومتقدّم لشركة استشارات تقنية تعمل في الولايات المتحدة والمملكة المتحدة والخليج (السعودية والإمارات وقطر).

عن نكسلورا:
- خمس قدرات: الذكاء الاصطناعي والبيانات، هندسة المنتجات، السحابة والبنية التحتية، الاستشارات والاستراتيجية، الأمن السيبراني.
- قيادة مهندسين كبار. لا مزارع محللين. الشركاء الذين يقدّمون المشروع هم من ينفّذونه.
- نبيع نتائج حيث أمكن (سعر ثابت مرتبط بمقياس)، لا ساعات.
- ثلاث مناطق محلية: ريستون فيرجينيا، لندن، الرياض.
- نعمل بطلاقة في ثلاث منظومات تنظيمية: الأمريكية (SOC 2، HIPAA)، البريطانية (UK GDPR، FCA)، الخليجية (NCA ECC، SAMA، PDPL، رؤية ٢٠٣٠).
- العملية: اكتشاف مدفوع لأسبوعين ← تصميم وعمارة (٤-٦ أسابيع) ← تسليم بسبرنتات أسبوعين ← تسليم مع استعداد ٦ أشهر.

طريقة الرد:
- مباشر وملموس. بدون لغة تسويقية.
- إذا كان السؤال خارج معرفتك (شروط صفقة، سعر مشروع محدد، اتفاقيات سرية)، اصدق وأرشد المستخدم لحجز جلسة استكشافية على /contact أو hello@nexlora.com.
- ٣-٦ جمل قصيرة عادة، إلا إذا طلب المستخدم العمق.
- لا تخترع أسماء عملاء أو أرقام دراسات حالة.
- للطلبات الحساسة، أرشد للبريد أو مكالمة مباشرة.

قاعدة الموضوع: ارفض بأدب الأسئلة خارج خدمات نكسلورا أو التقنية أو المناطق التي تعمل فيها.`;

// Static keyword fallback — used when ANTHROPIC_API_KEY is not present.
// FIX: replaced previous Cyrillic 'gcс' bug (line 721 of original HTML) with Latin 'gcc'.
function staticReply(message: string, locale: 'en' | 'ar'): string {
  const m = message.toLowerCase();
  const en = {
    services: 'We work in five disciplines: AI & Data Innovation, Product Engineering, Cloud & Infrastructure, Advisory & Strategy, and Cybersecurity. Each is led by senior engineers who actually do the build. Browse the capabilities page or book a 30-minute discovery call to talk specifics.',
    pricing: 'We sell outcomes wherever the work can be scoped — fixed price tied to a measurable metric. Discovery sprints are typically $15–40K. For an honest estimate of your project, book a discovery call.',
    startup: 'Yes, we work with startups — particularly those past Series A who need to ship something serious without burning runway on the wrong build. We have flexible engagement models for venture-backed teams.',
    gcc: 'We have an active Riyadh presence with engagements across KSA, UAE, and Qatar. Vision 2030 alignment is on our project list, not in our marketing copy. Fluent in NCA ECC and SAMA frameworks.',
    contact: 'The fastest path is a 30-minute discovery call. Book at /contact or email hello@nexlora.com — a senior partner will respond within one business day.',
    default: 'Tell me a bit more about what you are trying to do — a service, a market, a problem you are solving — and I can point you to the right next step. Or book a 30-minute discovery call at /contact.'
  };
  const ar = {
    services: 'نعمل في خمس قدرات: الذكاء الاصطناعي والبيانات، هندسة المنتجات، السحابة والبنية التحتية، الاستشارات والاستراتيجية، والأمن السيبراني. كل قدرة يقودها مهندسون كبار. تصفّح صفحة القدرات أو احجز جلسة استكشافية ٣٠ دقيقة.',
    pricing: 'نبيع نتائج حيث أمكن — سعر ثابت مرتبط بمقياس. سبرنتات الاكتشاف عادة ١٥-٤٠ ألف دولار. لتقدير صادق، احجز جلسة استكشافية.',
    startup: 'نعم، نعمل مع الشركات الناشئة — خاصة بعد السلسلة A التي تحتاج بناءً جاداً دون استنزاف التمويل. لدينا نماذج مرنة للفرق الممولة من المخاطر.',
    gcc: 'لنا حضور نشط في الرياض مع مشاريع في السعودية والإمارات وقطر. رؤية ٢٠٣٠ في قائمة مشاريعنا، لا في كلامنا التسويقي. نعمل بطلاقة مع NCA ECC و SAMA.',
    contact: 'أسرع طريق جلسة استكشافية ٣٠ دقيقة. احجز على /contact أو راسل hello@nexlora.com — يرد شريك أول خلال يوم عمل.',
    default: 'أخبرني أكثر عمّا تحاول فعله — خدمة، سوق، مشكلة — وسأرشدك للخطوة التالية. أو احجز جلسة استكشافية على /contact.'
  };
  const dict = locale === 'ar' ? ar : en;
  if (/(service|capabilit|خدم|قدر)/.test(m)) return dict.services;
  if (/(price|cost|fee|budget|سعر|تكلف|ميزان)/.test(m)) return dict.pricing;
  if (/(startup|founder|seed|series|ناشئ|مؤسس)/.test(m)) return dict.startup;
  if (/(gcc|saudi|ksa|uae|qatar|riyadh|gulf|سعود|خليج|ريا|إمار|قطر)/.test(m)) return dict.gcc;
  if (/(contact|talk|reach|email|phone|تواصل|مراسل|اتصال)/.test(m)) return dict.contact;
  return dict.default;
}

export async function POST(req: Request) {
  let body: { messages?: Msg[]; locale?: 'en' | 'ar' } = {};
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Invalid request body' }, { status: 400 });
  }

  const messages = Array.isArray(body.messages) ? body.messages : [];
  const locale: 'en' | 'ar' = body.locale === 'ar' ? 'ar' : 'en';

  const lastUserMessage = [...messages].reverse().find((m) => m.role === 'user')?.content || '';
  if (!lastUserMessage) {
    return NextResponse.json({ error: 'Empty message' }, { status: 400 });
  }

  // Fallback path: no API key → static keyword reply
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return NextResponse.json({
      reply: staticReply(lastUserMessage, locale),
      mode: 'static'
    });
  }

  // Anthropic path
  try {
    const client = new Anthropic({ apiKey });
    const systemPrompt = locale === 'ar' ? SYSTEM_PROMPT_AR : SYSTEM_PROMPT_EN;

    // Trim history to last 10 turns to keep latency reasonable
    const recentMessages = messages.slice(-10).map((m) => ({
      role: m.role,
      content: m.content.slice(0, 4000) // safety cap
    }));

    const response = await client.messages.create({
      model: 'claude-sonnet-4-5-20250929',
      max_tokens: 600,
      system: systemPrompt,
      messages: recentMessages
    });

    const text = response.content
      .filter((c) => c.type === 'text')
      .map((c) => ('text' in c ? c.text : ''))
      .join('\n')
      .trim();

    return NextResponse.json({
      reply: text || staticReply(lastUserMessage, locale),
      mode: 'anthropic'
    });
  } catch (err) {
    console.error('[chat] Anthropic call failed:', err);
    // Graceful degradation
    return NextResponse.json({
      reply: staticReply(lastUserMessage, locale),
      mode: 'static-fallback',
      // never expose API errors to the client
      error: undefined
    });
  }
}
