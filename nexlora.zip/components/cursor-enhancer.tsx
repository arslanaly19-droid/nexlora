'use client';

import { useEffect } from 'react';

export function CursorEnhancer() {
  useEffect(() => {
    if (typeof window === 'undefined') return;

    // Only on devices with fine pointer + hover
    const mq = window.matchMedia('(hover: hover) and (pointer: fine)');
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
    if (!mq.matches || reduced.matches) return;

    document.body.classList.add('has-cursor');

    const cur = document.createElement('div');
    cur.id = 'cur';
    const curO = document.createElement('div');
    curO.id = 'cur-o';
    document.body.appendChild(cur);
    document.body.appendChild(curO);

    let mx = 0, my = 0, ox = 0, oy = 0;
    let raf: number;

    const onMove = (e: MouseEvent) => {
      mx = e.clientX;
      my = e.clientY;
      cur.style.left = mx + 'px';
      cur.style.top = my + 'px';
    };

    const lag = () => {
      ox += (mx - ox) * 0.11;
      oy += (my - oy) * 0.11;
      curO.style.left = ox + 'px';
      curO.style.top = oy + 'px';
      raf = requestAnimationFrame(lag);
    };

    document.addEventListener('mousemove', onMove);
    raf = requestAnimationFrame(lag);

    const enter = () => {
      cur.style.width = '18px';
      cur.style.height = '18px';
      curO.style.width = '52px';
      curO.style.height = '52px';
      curO.style.borderColor = 'rgba(201,168,76,.7)';
    };
    const leave = () => {
      cur.style.width = '8px';
      cur.style.height = '8px';
      curO.style.width = '32px';
      curO.style.height = '32px';
      curO.style.borderColor = 'rgba(201,168,76,.45)';
    };

    const interactive = document.querySelectorAll('a, button, [role="button"], input, textarea, select, [data-cursor="hover"]');
    interactive.forEach((el) => {
      el.addEventListener('mouseenter', enter);
      el.addEventListener('mouseleave', leave);
    });

    return () => {
      document.removeEventListener('mousemove', onMove);
      cancelAnimationFrame(raf);
      interactive.forEach((el) => {
        el.removeEventListener('mouseenter', enter);
        el.removeEventListener('mouseleave', leave);
      });
      cur.remove();
      curO.remove();
      document.body.classList.remove('has-cursor');
    };
  }, []);

  return null;
}
