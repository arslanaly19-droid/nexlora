import Link from 'next/link';
import { useTranslations } from 'next-intl';
import { Logo } from './logo';

export function Footer({ locale }: { locale: string }) {
  const t = useTranslations('Footer');
  const prefix = locale === 'en' ? '' : `/${locale}`;

  return (
    <footer className="bg-[#060C18] text-white py-20 px-6 md:px-[52px] border-t border-white/5">
      <div className="max-w-[1160px] mx-auto">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-12">
          <div className="col-span-2 md:col-span-1">
            <Link href={prefix || '/'} className="inline-flex mb-4" aria-label="Nexlora — Home">
              <Logo size="sm" />
            </Link>
            <p className="text-[14px] text-white/50 leading-[1.7] max-w-[260px] mt-4">
              {t('tagline')}
            </p>
            <div className="flex gap-3 mt-6">
              {[
                { label: 'LinkedIn', char: 'in', href: 'https://linkedin.com' },
                { label: 'X', char: '𝕏', href: 'https://x.com' },
                { label: 'YouTube', char: '▶', href: 'https://youtube.com' }
              ].map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={s.label}
                  className="w-9 h-9 rounded-full border border-white/10 flex items-center justify-center text-white/60 hover:text-[#E8C97A] hover:border-[#C9A84C] transition-colors"
                >
                  {s.char}
                </a>
              ))}
            </div>
          </div>

          <div>
            <h5 className="font-syne text-[11px] font-bold tracking-[0.18em] uppercase text-[#C9A84C] mb-5">
              {t('capabilities')}
            </h5>
            <ul className="space-y-3 list-none">
              <li><Link href={`${prefix}/services/ai-data-innovation`} className="text-[13px] text-white/55 hover:text-white transition-colors">{t('aiData')}</Link></li>
              <li><Link href={`${prefix}/services/product-engineering`} className="text-[13px] text-white/55 hover:text-white transition-colors">{t('productEngineering')}</Link></li>
              <li><Link href={`${prefix}/services/cloud-infrastructure`} className="text-[13px] text-white/55 hover:text-white transition-colors">{t('cloudInfrastructure')}</Link></li>
              <li><Link href={`${prefix}/services/advisory-strategy`} className="text-[13px] text-white/55 hover:text-white transition-colors">{t('advisoryStrategy')}</Link></li>
              <li><Link href={`${prefix}/services/cybersecurity`} className="text-[13px] text-white/55 hover:text-white transition-colors">{t('cybersecurity')}</Link></li>
            </ul>
          </div>

          <div>
            <h5 className="font-syne text-[11px] font-bold tracking-[0.18em] uppercase text-[#C9A84C] mb-5">
              {t('company')}
            </h5>
            <ul className="space-y-3 list-none">
              <li><Link href={`${prefix}/about`} className="text-[13px] text-white/55 hover:text-white transition-colors">{t('about')}</Link></li>
              <li><Link href={`${prefix}/case-studies`} className="text-[13px] text-white/55 hover:text-white transition-colors">{t('caseStudies')}</Link></li>
              <li><Link href={`${prefix}/careers`} className="text-[13px] text-white/55 hover:text-white transition-colors">{t('careers')}</Link></li>
              <li><Link href={`${prefix}/blog`} className="text-[13px] text-white/55 hover:text-white transition-colors">{t('blog')}</Link></li>
            </ul>
          </div>

          <div>
            <h5 className="font-syne text-[11px] font-bold tracking-[0.18em] uppercase text-[#C9A84C] mb-5">
              {t('getInTouch')}
            </h5>
            <ul className="space-y-3 list-none">
              <li><a href="mailto:hello@nexlora.com" className="text-[13px] text-white/55 hover:text-white transition-colors">hello@nexlora.com</a></li>
              <li><a href="tel:+12020000000" className="text-[13px] text-white/55 hover:text-white transition-colors">+1 (202) 000-0000</a></li>
              <li><Link href={`${prefix}/contact`} className="text-[13px] text-white/55 hover:text-white transition-colors">{t('bookACall')}</Link></li>
              <li><Link href={`${prefix}/privacy`} className="text-[13px] text-white/55 hover:text-white transition-colors">{t('privacy')}</Link></li>
              <li><Link href={`${prefix}/terms`} className="text-[13px] text-white/55 hover:text-white transition-colors">{t('terms')}</Link></li>
            </ul>
          </div>
        </div>

        <div className="mt-16 pt-8 border-t border-white/5 flex flex-col md:flex-row md:justify-between gap-4">
          <p className="text-[12px] text-white/35 font-mono">
            {t('copyright', { year: new Date().getFullYear() })}
          </p>
          <div className="flex gap-6 text-[11px] font-syne font-semibold tracking-[0.1em] text-white/45">
            <span>🇺🇸 {t('offices.us')}</span>
            <span>🇬🇧 {t('offices.uk')}</span>
            <span>🇸🇦 {t('offices.ksa')}</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
