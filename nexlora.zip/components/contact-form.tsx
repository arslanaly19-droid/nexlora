'use client';

import { useState, useTransition } from 'react';
import { useTranslations } from 'next-intl';

type FormState = 'idle' | 'sending' | 'success' | 'error';

export function ContactForm({ locale }: { locale: 'en' | 'ar' }) {
  const t = useTranslations('Contact');
  const [state, setState] = useState<FormState>('idle');
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [, startTransition] = useTransition();

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const data = Object.fromEntries(new FormData(form)) as Record<string, string>;

    // Honeypot — bots fill this, humans don't see it
    if (data.website) return;

    setState('sending');
    setErrorMsg('');

    startTransition(async () => {
      try {
        const res = await fetch('/api/contact', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ...data, locale })
        });
        const json = await res.json();
        if (!res.ok) {
          setState('error');
          setErrorMsg(json.error || (locale === 'ar' ? 'تعذّر الإرسال. حاول مرة أخرى.' : 'Could not send. Please try again.'));
          return;
        }
        setState('success');
        form.reset();
      } catch {
        setState('error');
        setErrorMsg(locale === 'ar' ? 'مشكلة في الشبكة.' : 'Network error.');
      }
    });
  }

  if (state === 'success') {
    return (
      <div className="bg-[#F8FAFD] border border-[#E2E8F0] rounded-2xl p-10 text-center">
        <div className="text-5xl mb-5" aria-hidden>✓</div>
        <h3 className="font-display text-[24px] font-bold text-[#060C18] mb-3">{t('successTitle')}</h3>
        <p className="text-[15px] text-[#64748B] leading-[1.8] max-w-[420px] mx-auto">{t('successBody')}</p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6" noValidate>
      {/* Honeypot */}
      <input type="text" name="website" tabIndex={-1} autoComplete="off" aria-hidden className="hidden" />

      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <label htmlFor="name" className="block text-[12px] font-mono uppercase tracking-[0.18em] text-[#64748B] mb-2">{t('nameLabel')}</label>
          <input id="name" name="name" type="text" required className="field" />
        </div>
        <div>
          <label htmlFor="email" className="block text-[12px] font-mono uppercase tracking-[0.18em] text-[#64748B] mb-2">{t('emailLabel')}</label>
          <input id="email" name="email" type="email" required className="field" />
        </div>
      </div>
      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <label htmlFor="company" className="block text-[12px] font-mono uppercase tracking-[0.18em] text-[#64748B] mb-2">{t('companyLabel')}</label>
          <input id="company" name="company" type="text" className="field" />
        </div>
        <div>
          <label htmlFor="role" className="block text-[12px] font-mono uppercase tracking-[0.18em] text-[#64748B] mb-2">{t('roleLabel')}</label>
          <input id="role" name="role" type="text" className="field" />
        </div>
      </div>
      <div>
        <label htmlFor="budget" className="block text-[12px] font-mono uppercase tracking-[0.18em] text-[#64748B] mb-2">{t('budgetLabel')}</label>
        <select id="budget" name="budget" className="field" defaultValue="">
          <option value="" disabled>{t('budgetPlaceholder')}</option>
          <option value="under-50k">{t('budget1')}</option>
          <option value="50k-150k">{t('budget2')}</option>
          <option value="150k-500k">{t('budget3')}</option>
          <option value="500k-plus">{t('budget4')}</option>
          <option value="not-sure">{t('budget5')}</option>
        </select>
      </div>
      <div>
        <label htmlFor="message" className="block text-[12px] font-mono uppercase tracking-[0.18em] text-[#64748B] mb-2">{t('messageLabel')}</label>
        <textarea id="message" name="message" required rows={6} className="field" placeholder={t('messagePlaceholder')} />
      </div>
      <div className="flex items-start gap-3">
        <input id="consent" name="consent" type="checkbox" required className="mt-1" />
        <label htmlFor="consent" className="text-[13px] text-[#64748B] leading-[1.6]">{t('consentLabel')}</label>
      </div>

      {state === 'error' && (
        <div className="bg-red-50 border border-red-200 text-red-800 rounded-lg p-4 text-[14px]" role="alert">
          {errorMsg}
        </div>
      )}

      <button type="submit" disabled={state === 'sending'} className="btn-gold disabled:opacity-60 disabled:cursor-not-allowed">
        {state === 'sending' ? t('sending') : t('submit')}
      </button>
    </form>
  );
}
