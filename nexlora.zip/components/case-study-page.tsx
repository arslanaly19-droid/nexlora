import Link from 'next/link';
import { useTranslations } from 'next-intl';
import type { CaseStudy } from '@/content/case-studies';
import { caseStudies } from '@/content/case-studies';
import { RevealObserver } from './reveal';

export function CaseStudyPage({ content, locale }: { content: CaseStudy; locale: string }) {
  const tCommon = useTranslations('Common');
  const prefix = locale === 'en' ? '' : `/${locale}`;

  const related = content.related.map((slug) => caseStudies[slug as keyof typeof caseStudies][locale as 'en' | 'ar']);

  return (
    <>
      <RevealObserver />

      {/* HERO */}
      <section className="relative bg-[#060C18] text-white pt-[140px] pb-24 px-6 md:px-[52px] overflow-hidden">
        <div className="hero-grain" />
        <div className="hero-grid" />
        <div className="relative z-10 max-w-[1160px] mx-auto">
          <div className="tag !text-[#E8C97A] mb-6 r v">{content.hero.eyebrow}</div>
          <h1 className="font-display font-black text-[clamp(38px,6.5vw,76px)] leading-[1.05] tracking-tight mb-8 r v" style={{ transitionDelay: '.1s' }}>
            {content.hero.title}
            <br />
            <span className="text-[#E8C97A] italic">{content.hero.titleEm}</span>
          </h1>
          <p className="max-w-[760px] text-[18px] leading-[1.7] text-white/65 r v" style={{ transitionDelay: '.2s' }}>{content.hero.sub}</p>

          <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-6 r v" style={{ transitionDelay: '.3s' }}>
            <div>
              <div className="font-mono text-[10px] text-[#C9A84C] tracking-widest mb-1.5">INDUSTRY</div>
              <div className="font-syne text-[14px] font-semibold">{content.meta.industry}</div>
            </div>
            <div>
              <div className="font-mono text-[10px] text-[#C9A84C] tracking-widest mb-1.5">REGION</div>
              <div className="font-syne text-[14px] font-semibold">{content.meta.region}</div>
            </div>
            <div>
              <div className="font-mono text-[10px] text-[#C9A84C] tracking-widest mb-1.5">DISCIPLINE</div>
              <div className="font-syne text-[14px] font-semibold">{content.meta.discipline}</div>
            </div>
            <div>
              <div className="font-mono text-[10px] text-[#C9A84C] tracking-widest mb-1.5">DURATION</div>
              <div className="font-syne text-[14px] font-semibold">{content.meta.duration}</div>
            </div>
          </div>
        </div>
      </section>

      {/* CHALLENGE */}
      <section className="section bg-white">
        <div className="wrap grid lg:grid-cols-12 gap-12">
          <div className="lg:col-span-5">
            <div className="tag mb-3">Challenge</div>
            <h2 className="sh r">{content.challenge.heading}</h2>
          </div>
          <div className="lg:col-span-7">
            <p className="text-[17px] text-[#475569] leading-[1.85] r" style={{ transitionDelay: '.1s' }}>{content.challenge.body}</p>
          </div>
        </div>
      </section>

      {/* APPROACH */}
      <section className="section bg-[#F8FAFD]">
        <div className="wrap">
          <div className="mb-16 max-w-[680px]">
            <div className="tag mb-3">Approach</div>
            <h2 className="sh r">{content.approach.heading}</h2>
          </div>
          <div className="space-y-10">
            {content.approach.phases.map((phase, i) => (
              <div key={i} className="grid md:grid-cols-12 gap-8 items-start r" style={{ transitionDelay: `${i * 0.08}s` }}>
                <div className="md:col-span-2">
                  <div className="font-mono text-[12px] text-[#C9A84C] tracking-widest">{String(i + 1).padStart(2, '0')}</div>
                </div>
                <div className="md:col-span-10">
                  <h3 className="font-display text-[24px] font-bold text-[#060C18] mb-3 leading-tight">{phase.title}</h3>
                  <p className="text-[16px] text-[#475569] leading-[1.8]">{phase.body}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* OUTCOME */}
      <section className="section bg-[#060C18] text-white">
        <div className="wrap">
          <div className="mb-16 max-w-[680px]">
            <div className="tag mb-3">Outcome</div>
            <h2 className="sh light r">{content.outcome.heading}</h2>
          </div>
          <p className="max-w-[860px] text-[17px] text-white/70 leading-[1.85] mb-16 r" style={{ transitionDelay: '.1s' }}>{content.outcome.body}</p>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {content.outcome.metrics.map((m, i) => (
              <div key={i} className="border border-white/10 p-8 rounded-2xl r" style={{ transitionDelay: `${0.15 + i * 0.06}s` }}>
                <div className="font-display text-[44px] md:text-[52px] font-black text-[#E8C97A] leading-none mb-3">{m.value}</div>
                <div className="text-[14px] text-white/55 leading-[1.6]">{m.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* REFLECTION */}
      <section className="section bg-white">
        <div className="wrap max-w-[860px]">
          <div className="tag mb-3">Reflection</div>
          <h2 className="sh r mb-8">{content.reflection.heading}</h2>
          <p className="text-[17px] text-[#475569] leading-[1.85] r" style={{ transitionDelay: '.1s' }}>{content.reflection.body}</p>
        </div>
      </section>

      {/* RELATED */}
      {related.length > 0 && (
        <section className="section bg-[#F8FAFD]">
          <div className="wrap">
            <div className="mb-12 max-w-[680px]">
              <div className="tag mb-3">More work</div>
              <h2 className="sh r">Other engagements that shipped.</h2>
            </div>
            <div className="grid md:grid-cols-2 gap-6">
              {related.map((r, i) => (
                <Link
                  key={r.slug}
                  href={`${prefix}/case-studies/${r.slug}`}
                  className="block bg-white border border-[#E2E8F0] p-8 rounded-2xl hover:border-[#C9A84C] transition-colors r"
                  style={{ transitionDelay: `${i * 0.08}s` }}
                >
                  <div className="font-mono text-[10px] text-[#C9A84C] tracking-widest mb-3">{r.meta.region.toUpperCase()}</div>
                  <h3 className="font-display text-[22px] font-bold text-[#060C18] mb-3 leading-tight">{r.hero.title} {r.hero.titleEm}</h3>
                  <p className="text-[14px] text-[#64748B] leading-[1.7]">{r.hero.sub.slice(0, 160)}…</p>
                  <div className="mt-5 font-syne text-[12px] font-bold tracking-wider text-[#C9A84C]">{tCommon('readCaseStudy')} →</div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* CTA */}
      <section className="section bg-[#060C18] text-white">
        <div className="wrap text-center max-w-[760px] mx-auto">
          <h2 className="font-display font-black text-[clamp(34px,5vw,56px)] leading-[1.06] tracking-tight mb-6 r">
            Tell us where you are. We will tell you, honestly, whether we can help.
          </h2>
          <Link href={`${prefix}/contact`} className="btn-gold mt-6 r" style={{ transitionDelay: '.1s' }}>{tCommon('bookDiscoveryCall')}</Link>
        </div>
      </section>
    </>
  );
}
