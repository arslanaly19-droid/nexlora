'use client';

import { useEffect, useRef } from 'react';

export function HeroAurora() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const heroRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let raf: number;
    let W = 0, H = 0, t = 0, pmx = 0.5, pmy = 0.5;

    const resize = () => {
      W = canvas.width = canvas.offsetWidth;
      H = canvas.height = canvas.offsetHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    const onMouse = (e: MouseEvent) => {
      const r = canvas.getBoundingClientRect();
      pmx = (e.clientX - r.left) / W;
      pmy = (e.clientY - r.top) / H;
    };
    const hero = canvas.parentElement;
    hero?.addEventListener('mousemove', onMouse);

    const orbs = [
      { x: 0.18, y: 0.28, r: 0.55, c: 'rgba(43,111,212,0.22)' },
      { x: 0.78, y: 0.22, r: 0.48, c: 'rgba(201,168,76,0.13)' },
      { x: 0.5, y: 0.75, r: 0.52, c: 'rgba(26,58,107,0.2)' },
      { x: 0.85, y: 0.7, r: 0.4, c: 'rgba(59,130,246,0.11)' },
      { x: 0.1, y: 0.8, r: 0.38, c: 'rgba(201,168,76,0.08)' }
    ];

    const draw = () => {
      ctx.clearRect(0, 0, W, H);
      ctx.fillStyle = '#060C18';
      ctx.fillRect(0, 0, W, H);
      orbs.forEach((o, i) => {
        const px = (o.x + Math.sin(t * 0.28 + i * 1.2) * 0.08 + (pmx - 0.5) * 0.06) * W;
        const py = (o.y + Math.cos(t * 0.22 + i * 0.9) * 0.07 + (pmy - 0.5) * 0.05) * H;
        const g = ctx.createRadialGradient(px, py, 0, px, py, o.r * Math.min(W, H));
        g.addColorStop(0, o.c);
        g.addColorStop(1, 'transparent');
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, W, H);
      });
      t += 0.008;
      if (!reduced) raf = requestAnimationFrame(draw);
    };
    draw();

    return () => {
      window.removeEventListener('resize', resize);
      hero?.removeEventListener('mousemove', onMouse);
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);

  return <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" aria-hidden="true" />;
}
