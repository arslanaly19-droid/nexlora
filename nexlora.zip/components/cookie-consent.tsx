'use client';

import { useEffect, useState } from 'react';
import { useTranslations } from 'next-intl';

export function CookieConsent() {
  const t = useTranslations('Cookies');
  const [show, setShow] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const stored = localStorage.getItem('nexlora-consent');
    if (!stored) setShow(true);
  }, []);

  function decide(value: 'accept' | 'decline') {
    localStorage.setItem('nexlora-consent', value);
    if (value === 'accept') {
      window.dispatchEvent(new CustomEvent('nexlora-consent-granted'));
    }
    setShow(false);
  }

  if (!show) return null;

  return (
    <div className="fixed bottom-4 left-4 right-4 md:left-8 md:right-auto md:max-w-md z-[400] bg-[#0A1525] border border-[rgba(201,168,76,0.2)] rounded-2xl p-5 shadow-[0_16px_48px_rgba(0,0,0,0.4)]" role="dialog" aria-label={t('title')}>
      <h3 className="font-syne text-[13px] font-bold text-[#E8C97A] tracking-wider uppercase mb-2">{t('title')}</h3>
      <p className="text-[13px] text-white/70 leading-relaxed mb-4">{t('body')}</p>
      <div className="flex gap-2">
        <button
          onClick={() => decide('accept')}
          className="flex-1 bg-gradient-to-br from-[#C9A84C] to-[#E8C97A] text-[#060C18] py-2.5 rounded-lg font-syne text-[12px] font-bold tracking-wider"
        >
          {t('accept')}
        </button>
        <button
          onClick={() => decide('decline')}
          className="flex-1 bg-white/5 border border-white/10 text-white/70 py-2.5 rounded-lg font-syne text-[12px] font-bold tracking-wider hover:bg-white/10"
        >
          {t('decline')}
        </button>
      </div>
    </div>
  );
}
