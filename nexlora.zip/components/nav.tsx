'use client';

import { useEffect, useState } from 'react';
import { useTranslations } from 'next-intl';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Logo } from './logo';
import { LocaleSwitcher } from './locale-switcher';

export function Nav({ locale }: { locale: string }) {
  const t = useTranslations('Nav');
  const tCommon = useTranslations('Common');
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const pathname = usePathname();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [pathname]);

  const prefix = locale === 'en' ? '' : `/${locale}`;
  const links = [
    { href: `${prefix}/#capabilities`, label: t('capabilities') },
    { href: `${prefix}/case-studies`, label: t('caseStudies') },
    { href: `${prefix}/about`, label: t('about') },
    { href: `${prefix}/blog`, label: t('blog') },
    { href: `${prefix}/careers`, label: t('careers') }
  ];

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-[200] h-[72px] flex items-center justify-between px-6 md:px-[52px] transition-all duration-300 ${
          scrolled
            ? 'bg-[rgba(6,12,24,0.93)] backdrop-blur-xl border-b border-[rgba(201,168,76,0.1)]'
            : ''
        }`}
        aria-label="Primary"
      >
        <Link href={prefix || '/'} aria-label="Nexlora — Home" className="flex items-center">
          <Logo />
        </Link>

        <ul className="hidden lg:flex items-center gap-7 list-none">
          {links.map((l) => (
            <li key={l.href}>
              <Link
                href={l.href}
                className="font-syne text-[13px] font-semibold text-white/55 hover:text-[#E8C97A] transition-colors tracking-[0.04em]"
              >
                {l.label}
              </Link>
            </li>
          ))}
          <li>
            <LocaleSwitcher currentLocale={locale} />
          </li>
          <li>
            <Link
              href={`${prefix}/contact`}
              className="bg-gradient-to-br from-[#C9A84C] to-[#E8C97A] text-[#060C18] px-[22px] py-[9px] rounded-[7px] font-syne text-[13px] font-bold tracking-[0.04em] shadow-[0_4px_16px_rgba(201,168,76,0.28)] hover:-translate-y-px hover:shadow-[0_8px_28px_rgba(201,168,76,0.42)] transition-all"
            >
              {t('talkToUs')}
            </Link>
          </li>
        </ul>

        <button
          className="lg:hidden text-white p-2 -mr-2"
          onClick={() => setMobileOpen(!mobileOpen)}
          aria-label={mobileOpen ? t('close') : t('menu')}
          aria-expanded={mobileOpen}
        >
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            {mobileOpen ? (
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            ) : (
              <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
            )}
          </svg>
        </button>
      </nav>

      {mobileOpen && (
        <div className="fixed inset-0 z-[190] bg-[#060C18] pt-[72px] lg:hidden">
          <ul className="flex flex-col gap-1 p-6 list-none">
            {links.map((l) => (
              <li key={l.href}>
                <Link
                  href={l.href}
                  className="block py-4 px-4 font-syne text-[18px] font-semibold text-white/80 border-b border-white/5"
                  onClick={() => setMobileOpen(false)}
                >
                  {l.label}
                </Link>
              </li>
            ))}
            <li className="pt-6">
              <Link
                href={`${prefix}/contact`}
                className="block text-center bg-gradient-to-br from-[#C9A84C] to-[#E8C97A] text-[#060C18] px-6 py-4 rounded-lg font-syne text-[14px] font-bold"
              >
                {tCommon('bookDiscoveryCall')}
              </Link>
            </li>
            <li className="pt-4 flex justify-center">
              <LocaleSwitcher currentLocale={locale} />
            </li>
          </ul>
        </div>
      )}
    </>
  );
}
