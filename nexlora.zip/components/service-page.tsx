import Link from 'next/link';
import { useTranslations } from 'next-intl';
import type { ServiceContent } from '@/content/services';
import { RevealObserver } from './reveal';

export function ServicePage({ content, locale }: { content: ServiceContent; locale: string }) {
  const tCommon = useTranslations('Common');
  const prefix = locale === 'en' ? '' : `/${locale}`;

  return (
    <>
      <RevealObserver />

      {/* HERO */}
      <section className="relative bg-[#060C18] text-white pt-[140px] pb-24 px-6 md:px-[52px] overflow-hidden">
        <div className="hero-grain" />
        <div className="hero-grid" />
        <div className="relative z-10 max-w-[1160px] mx-auto">
          <div className="tag !text-[#E8C97A] mb-6 r v">{content.hero.eyebrow}</div>
          <h1 className="font-display font-black text-[clamp(40px,7vw,84px)] leading-[1.04] tracking-tight mb-8 r v" style={{ transitionDelay: '.1s' }}>
            {content.hero.title}
            <br />
            <span className="text-[#E8C97A] italic">{content.hero.titleEm}</span>
            {content.hero.titleEnd && <><br />{content.hero.titleEnd}</>}
          </h1>
          <p className="max-w-[760px] text-[18px] md:text-[19px] leading-[1.7] text-white/65 r v" style={{ transitionDelay: '.2s' }}>
            {content.hero.sub}
          </p>
          <div className="mt-10 flex flex-wrap gap-4 r v" style={{ transitionDelay: '.3s' }}>
            <Link href={`${prefix}/contact`} className="btn-gold">{tCommon('bookDiscoveryCall')}</Link>
            <Link href={`${prefix}/case-studies`} className="btn-ghost">{tCommon('viewAllCases')}</Link>
          </div>
        </div>
      </section>

      {/* INTRO */}
      <section className="section bg-white">
        <div className="wrap grid lg:grid-cols-12 gap-12">
          <div className="lg:col-span-5">
            <h2 className="sh r">{content.intro.heading}</h2>
          </div>
          <div className="lg:col-span-7">
            <p className="text-[17px] text-[#475569] leading-[1.8] r" style={{ transitionDelay: '.1s' }}>{content.intro.body}</p>
          </div>
        </div>
      </section>

      {/* PILLARS */}
      <section className="section bg-[#F8FAFD]">
        <div className="wrap">
          <div className="mb-16 max-w-[640px]">
            <div className="tag mb-3">Pillars</div>
            <h2 className="sh r">How we approach the work</h2>
          </div>
          <div className="grid md:grid-cols-2 gap-8">
            {content.pillars.map((p, i) => (
              <div key={p.num} className="bg-white border border-[#E2E8F0] p-8 rounded-2xl r" style={{ transitionDelay: `${i * 0.08}s` }}>
                <div className="font-mono text-[12px] text-[#C9A84C] tracking-widest mb-3">{p.num}</div>
                <h3 className="font-display text-[22px] font-bold text-[#060C18] mb-3 leading-tight">{p.title}</h3>
                <p className="text-[15px] text-[#64748B] leading-[1.75]">{p.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* OFFERINGS */}
      <section className="section bg-white">
        <div className="wrap">
          <div className="mb-16 max-w-[640px]">
            <div className="tag mb-3">What we deliver</div>
            <h2 className="sh r">Specific work, named.</h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {content.offerings.map((o, i) => (
              <div key={o.name} className="border border-[#E2E8F0] p-7 rounded-xl hover:border-[#C9A84C] transition-colors r" style={{ transitionDelay: `${i * 0.05}s` }}>
                <h3 className="font-syne text-[14px] font-bold text-[#060C18] mb-3 tracking-wide">{o.name}</h3>
                <p className="text-[14px] text-[#64748B] leading-[1.7]">{o.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* OUTCOMES */}
      <section className="section bg-[#060C18] text-white">
        <div className="wrap">
          <div className="mb-16 max-w-[640px]">
            <div className="tag mb-3">Outcomes</div>
            <h2 className="sh light r">Numbers we have shipped.</h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {content.outcomes.map((o, i) => (
              <div key={i} className="border border-white/10 p-8 rounded-2xl r" style={{ transitionDelay: `${i * 0.08}s` }}>
                <div className="font-display text-[44px] md:text-[52px] font-black text-[#E8C97A] leading-none mb-3">{o.metric}</div>
                <div className="text-[14px] text-white/55 leading-[1.6]">{o.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PROCESS */}
      <section className="section bg-white">
        <div className="wrap">
          <div className="mb-16 max-w-[640px]">
            <div className="tag mb-3">Process</div>
            <h2 className="sh r">How the engagement runs.</h2>
          </div>
          <div className="space-y-12">
            {content.process.map((p, i) => (
              <div key={p.phase} className="grid md:grid-cols-12 gap-8 items-start r" style={{ transitionDelay: `${i * 0.08}s` }}>
                <div className="md:col-span-3">
                  <div className="font-mono text-[12px] text-[#C9A84C] tracking-widest mb-2">{`${String(i + 1).padStart(2, '0')} · ${p.phase}`}</div>
                </div>
                <div className="md:col-span-9">
                  <h3 className="font-display text-[26px] font-bold text-[#060C18] mb-3 leading-tight">{p.title}</h3>
                  <p className="text-[16px] text-[#475569] leading-[1.8]">{p.body}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* TECH + INDUSTRIES */}
      <section className="section bg-[#F8FAFD]">
        <div className="wrap grid lg:grid-cols-2 gap-16">
          <div>
            <div className="tag mb-3">Technologies</div>
            <h3 className="sh text-[28px] r mb-8">We build with the right tool, not the trendy one.</h3>
            <div className="flex flex-wrap gap-2 r" style={{ transitionDelay: '.1s' }}>
              {content.techStack.map((t) => (
                <span key={t} className="bg-white border border-[#E2E8F0] px-3 py-1.5 rounded-full text-[12px] font-mono text-[#475569]">{t}</span>
              ))}
            </div>
          </div>
          <div>
            <div className="tag mb-3">Industries</div>
            <h3 className="sh text-[28px] r mb-8">Where we have shipped this work.</h3>
            <div className="flex flex-wrap gap-2 r" style={{ transitionDelay: '.1s' }}>
              {content.industries.map((ind) => (
                <span key={ind} className="bg-white border border-[#E2E8F0] px-3 py-1.5 rounded-full text-[12px] font-syne font-semibold text-[#060C18]">{ind}</span>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* FAQS */}
      <section className="section bg-white">
        <div className="wrap max-w-[860px]">
          <div className="mb-16">
            <div className="tag mb-3">Questions</div>
            <h2 className="sh r">The ones people actually ask.</h2>
          </div>
          <div className="space-y-6">
            {content.faqs.map((f, i) => (
              <details key={i} className="group border-b border-[#E2E8F0] pb-6 r" style={{ transitionDelay: `${i * 0.05}s` }}>
                <summary className="flex justify-between items-start cursor-pointer list-none">
                  <h3 className="font-display text-[20px] font-bold text-[#060C18] pr-8 leading-snug">{f.q}</h3>
                  <span className="text-[#C9A84C] text-2xl group-open:rotate-45 transition-transform shrink-0">+</span>
                </summary>
                <p className="mt-4 text-[16px] text-[#475569] leading-[1.8]">{f.a}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="section bg-[#060C18] text-white">
        <div className="wrap text-center max-w-[760px] mx-auto">
          <h2 className="font-display font-black text-[clamp(34px,5vw,56px)] leading-[1.06] tracking-tight mb-6 r">
            {content.cta.heading}
          </h2>
          <p className="text-[17px] text-white/65 leading-[1.75] mb-10 r" style={{ transitionDelay: '.1s' }}>
            {content.cta.sub}
          </p>
          <div className="flex flex-wrap gap-4 justify-center r" style={{ transitionDelay: '.2s' }}>
            <Link href={`${prefix}/contact`} className="btn-gold">{tCommon('bookDiscoveryCall')}</Link>
            <Link href={`${prefix}/case-studies`} className="btn-ghost">{tCommon('readCaseStudy')}</Link>
          </div>
        </div>
      </section>
    </>
  );
}
