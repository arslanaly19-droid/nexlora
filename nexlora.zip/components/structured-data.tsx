export function OrganizationSchema() {
  const data = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: 'Nexlora',
    legalName: 'Nexlora Ltd',
    url: process.env.NEXT_PUBLIC_SITE_URL || 'https://nexlora.com',
    logo: `${process.env.NEXT_PUBLIC_SITE_URL || 'https://nexlora.com'}/logo.png`,
    description:
      'Senior-led, AI-first technology partner for ambitious companies in the US, UK, and Gulf.',
    sameAs: ['https://linkedin.com/company/nexlora', 'https://x.com/nexlora'],
    contactPoint: [
      {
        '@type': 'ContactPoint',
        email: 'hello@nexlora.com',
        telephone: '+1-202-000-0000',
        contactType: 'sales',
        areaServed: ['US', 'GB', 'SA', 'AE', 'QA'],
        availableLanguage: ['English', 'Arabic']
      }
    ],
    address: [
      { '@type': 'PostalAddress', addressLocality: 'Reston', addressRegion: 'VA', addressCountry: 'US' },
      { '@type': 'PostalAddress', addressLocality: 'London', addressCountry: 'GB' },
      { '@type': 'PostalAddress', addressLocality: 'Riyadh', addressCountry: 'SA' }
    ]
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}

export function ServiceSchema({ name, description, url }: { name: string; description: string; url: string }) {
  const data = {
    '@context': 'https://schema.org',
    '@type': 'Service',
    name,
    description,
    provider: { '@type': 'Organization', name: 'Nexlora' },
    url,
    areaServed: ['US', 'GB', 'SA', 'AE', 'QA']
  };
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }} />;
}

export function BreadcrumbSchema({ items }: { items: { name: string; url: string }[] }) {
  const data = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: items.map((item, idx) => ({
      '@type': 'ListItem',
      position: idx + 1,
      name: item.name,
      item: item.url
    }))
  };
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }} />;
}
