'use client';

import Script from 'next/script';
import { useEffect, useState } from 'react';

export function Analytics() {
  const [enabled, setEnabled] = useState(false);
  const domain = process.env.NEXT_PUBLIC_PLAUSIBLE_DOMAIN;

  useEffect(() => {
    if (typeof window === 'undefined' || !domain) return;
    const stored = localStorage.getItem('nexlora-consent');
    if (stored === 'accept') setEnabled(true);
    const onGrant = () => setEnabled(true);
    window.addEventListener('nexlora-consent-granted', onGrant);
    return () => window.removeEventListener('nexlora-consent-granted', onGrant);
  }, [domain]);

  if (!enabled || !domain) return null;

  return (
    <Script
      strategy="afterInteractive"
      data-domain={domain}
      src="https://plausible.io/js/script.js"
    />
  );
}
