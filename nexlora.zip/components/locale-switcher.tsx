'use client';

import { usePathname, useRouter } from 'next/navigation';
import { useTranslations } from 'next-intl';
import { locales } from '@/i18n';

export function LocaleSwitcher({ currentLocale }: { currentLocale: string }) {
  const router = useRouter();
  const pathname = usePathname();
  const t = useTranslations('Common');

  const switchTo = (newLocale: string) => {
    let cleanPath = pathname.replace(/^\/(en|ar)(\/|$)/, '/');
    if (cleanPath === '') cleanPath = '/';
    const newPath = newLocale === 'en' ? cleanPath : `/${newLocale}${cleanPath === '/' ? '' : cleanPath}`;
    router.push(newPath);
    router.refresh();
  };

  return (
    <div className="flex items-center gap-1 bg-white/5 border border-white/10 rounded-full p-1" role="group" aria-label={t('language')}>
      {locales.map((loc) => (
        <button
          key={loc}
          onClick={() => switchTo(loc)}
          className={`font-syne text-[11px] font-bold tracking-wider px-3 py-1 rounded-full transition-all ${
            currentLocale === loc
              ? 'bg-gradient-to-br from-[#C9A84C] to-[#E8C97A] text-[#060C18]'
              : 'text-white/50 hover:text-white/80'
          }`}
          aria-pressed={currentLocale === loc}
          aria-label={loc === 'en' ? t('english') : t('arabic')}
        >
          {loc === 'en' ? 'EN' : 'AR'}
        </button>
      ))}
    </div>
  );
}
