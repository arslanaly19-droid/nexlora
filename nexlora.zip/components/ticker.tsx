export function Ticker({ items }: { items: { icon: string; label: string }[] }) {
  const doubled = [...items, ...items];
  return (
    <div className="bg-[#0A1525] border-t border-[rgba(201,168,76,0.08)] border-b border-white/5 py-4 overflow-hidden relative ticker-mask">
      <div className="flex animate-ticker w-max ticker-track">
        {doubled.map((item, i) => (
          <div
            key={i}
            className="flex items-center gap-2.5 px-10 whitespace-nowrap font-syne text-[11px] font-bold tracking-[0.12em] text-white/30 uppercase"
          >
            <span className="text-[#C9A84C] text-[15px]">{item.icon}</span>
            {item.label}
          </div>
        ))}
      </div>
    </div>
  );
}
