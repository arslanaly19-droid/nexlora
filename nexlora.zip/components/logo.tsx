export function Logo({ size = 'md' }: { size?: 'sm' | 'md' }) {
  const w = size === 'sm' ? 172 : 198;
  const h = size === 'sm' ? 44 : 48;
  return (
    <svg width={w} height={h} viewBox="0 0 198 48" fill="none" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Nexlora">
      <defs>
        <linearGradient id="nG" x1="0" y1="0" x2="44" y2="44" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#E8C97A" />
          <stop offset="100%" stopColor="#C9A84C" />
        </linearGradient>
        <linearGradient id="nS" x1="11" y1="8" x2="35" y2="38" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#FFFFFF" />
          <stop offset="55%" stopColor="#F0D98A" />
          <stop offset="100%" stopColor="#E8C97A" />
        </linearGradient>
        <filter id="nGlow">
          <feGaussianBlur stdDeviation="2" result="b" />
          <feMerge>
            <feMergeNode in="b" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>
      <rect x="1" y="1" width="42" height="42" rx="9" fill="url(#nG)" opacity=".1" />
      <rect x="1" y="1" width="42" height="42" rx="9" stroke="url(#nG)" strokeWidth="1" fill="none" />
      <path d="M10 36V12L22 30V12" stroke="url(#nS)" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round" fill="none" filter="url(#nGlow)" />
      <path d="M22 30V12L34 36" stroke="url(#nS)" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round" fill="none" filter="url(#nGlow)" />
      <circle cx="34" cy="12" r="4" fill="#C9A84C" opacity=".35" />
      <circle cx="34" cy="12" r="2.5" fill="#E8C97A" />
      <text x="54" y="28" fontFamily="'Playfair Display', Georgia, serif" fontSize="24" fontWeight="900" fontStyle="italic" fill="#FFFFFF" letterSpacing="-0.5">
        Nexlora
      </text>
      <text x="56" y="40" fontFamily="'Syne', Arial, sans-serif" fontSize="6.5" fontWeight="700" fill="#C9A84C" letterSpacing="2.6">
        INTELLIGENCE FORWARD
      </text>
    </svg>
  );
}
