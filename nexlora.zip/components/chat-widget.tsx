'use client';

import { useState, useRef, useEffect } from 'react';
import { useTranslations, useLocale } from 'next-intl';

type Msg = { role: 'user' | 'assistant'; content: string; time: string };

export function ChatWidget() {
  const t = useTranslations('Chat');
  const locale = useLocale();
  const [open, setOpen] = useState(false);
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const [showQuick, setShowQuick] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (msgs.length === 0) {
      setMsgs([{ role: 'assistant', content: t('greeting'), time: now() }]);
    }
  }, [t, msgs.length]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [msgs, sending]);

  useEffect(() => {
    if (open) inputRef.current?.focus();
  }, [open]);

  function now() {
    const d = new Date();
    return `${d.getHours()}:${String(d.getMinutes()).padStart(2, '0')}`;
  }

  async function send(text: string) {
    if (!text.trim() || sending) return;
    setShowQuick(false);
    const userMsg: Msg = { role: 'user', content: text, time: now() };
    const newHistory = [...msgs, userMsg];
    setMsgs(newHistory);
    setInput('');
    setSending(true);
    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: newHistory.map((m) => ({ role: m.role, content: m.content })),
          locale
        })
      });
      const data = await res.json();
      setMsgs((prev) => [...prev, { role: 'assistant', content: data.reply, time: now() }]);
    } catch {
      setMsgs((prev) => [
        ...prev,
        {
          role: 'assistant',
          content:
            locale === 'ar'
              ? 'عذراً، حدث خطأ في الاتصال. يرجى المحاولة لاحقاً أو مراسلتنا على hello@nexlora.com.'
              : "Sorry, I had trouble connecting. Please try again or email us at hello@nexlora.com."
        ,
          time: now()
        }
      ]);
    } finally {
      setSending(false);
    }
  }

  const quickPrompts = [
    { label: t('quickServices'), q: locale === 'ar' ? 'ما هي خدماتكم؟' : 'What services do you offer?' },
    { label: t('quickPricing'), q: locale === 'ar' ? 'كيف تحددون الأسعار؟' : 'How do you price engagements?' },
    { label: t('quickStartups'), q: locale === 'ar' ? 'هل تعملون مع الشركات الناشئة؟' : 'Do you work with startups?' },
    { label: t('quickGCC'), q: locale === 'ar' ? 'حدثوني عن خبرتكم في الخليج' : 'Tell me about your GCC experience' }
  ];

  return (
    <>
      <button
        onClick={() => setOpen(!open)}
        className={`fixed bottom-8 right-8 z-[500] w-14 h-14 rounded-full bg-gradient-to-br from-[#C9A84C] to-[#E8C97A] flex items-center justify-center shadow-[0_8px_28px_rgba(201,168,76,0.42)] hover:scale-105 transition-transform ${
          open ? 'rotate-90' : ''
        }`}
        aria-label={open ? t('closeChat') : t('openChat')}
        aria-expanded={open}
      >
        {open ? (
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#060C18" strokeWidth="2.5">
            <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
          </svg>
        ) : (
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#060C18" strokeWidth="2">
            <path strokeLinecap="round" strokeLinejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
          </svg>
        )}
      </button>

      {open && (
        <div
          className="fixed bottom-[104px] right-4 md:right-8 z-[499] w-[calc(100vw-32px)] md:w-[380px] max-h-[560px] bg-[#0A1525] border border-[rgba(201,168,76,0.2)] rounded-[20px] flex flex-col shadow-[0_24px_64px_rgba(0,0,0,0.5)]"
          role="dialog"
          aria-label="Chat with Nexlora AI"
        >
          <div className="px-5 py-4 border-b border-white/5 flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#C9A84C] to-[#E8C97A] flex items-center justify-center font-display italic font-black text-[#060C18]">
              N
            </div>
            <div>
              <div className="font-syne text-[13px] font-bold text-white">{t('name')}</div>
              <div className="flex items-center gap-1.5 text-[11px] text-white/40">
                <span className="w-1.5 h-1.5 rounded-full bg-green-500" />
                {t('status')}
              </div>
            </div>
          </div>

          <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3 max-h-[340px]">
            {msgs.map((m, i) => (
              <div key={i} className={`max-w-[88%] ${m.role === 'user' ? 'ml-auto' : ''}`}>
                <div
                  className={`px-4 py-2.5 text-[13px] leading-[1.6] ${
                    m.role === 'user'
                      ? 'bg-gradient-to-br from-[#C9A84C] to-[#E8C97A] text-[#060C18] rounded-[14px_4px_14px_14px] font-medium'
                      : 'bg-white/5 text-white/90 rounded-[4px_14px_14px_14px]'
                  }`}
                >
                  {m.content}
                </div>
                <div className={`text-[9px] font-mono text-white/20 mt-1 px-1 ${m.role === 'user' ? 'text-right' : ''}`}>
                  {m.time}
                </div>
              </div>
            ))}
            {sending && (
              <div className="max-w-[88%]">
                <div className="bg-white/5 rounded-[4px_14px_14px_14px] px-4 py-3 w-fit flex gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-white/40 animate-bounce" style={{ animationDelay: '0s' }} />
                  <span className="w-1.5 h-1.5 rounded-full bg-white/40 animate-bounce" style={{ animationDelay: '0.15s' }} />
                  <span className="w-1.5 h-1.5 rounded-full bg-white/40 animate-bounce" style={{ animationDelay: '0.3s' }} />
                </div>
              </div>
            )}
          </div>

          {showQuick && (
            <div className="px-4 py-2.5 flex gap-2 flex-wrap border-t border-white/5">
              {quickPrompts.map((qp) => (
                <button
                  key={qp.label}
                  onClick={() => send(qp.q)}
                  className="font-syne text-[10px] font-bold text-white/55 bg-white/5 border border-white/10 px-3 py-1.5 rounded-full hover:bg-[rgba(201,168,76,0.15)] hover:border-[rgba(201,168,76,0.3)] hover:text-[#E8C97A] transition-colors"
                >
                  {qp.label}
                </button>
              ))}
            </div>
          )}

          <div className="p-4 border-t border-white/5 flex gap-2.5 items-center">
            <textarea
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  send(input);
                }
              }}
              placeholder={t('placeholder')}
              rows={1}
              className="flex-1 bg-white/5 border border-white/10 rounded-[10px] px-3.5 py-2.5 text-[13px] text-white outline-none focus:border-[rgba(201,168,76,0.3)] resize-none"
              aria-label={t('placeholder')}
            />
            <button
              onClick={() => send(input)}
              disabled={!input.trim() || sending}
              aria-label={t('send')}
              className="w-9 h-9 rounded-[9px] bg-gradient-to-br from-[#C9A84C] to-[#E8C97A] text-[#060C18] flex items-center justify-center hover:scale-110 disabled:opacity-50 disabled:cursor-not-allowed transition-transform"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
              </svg>
            </button>
          </div>
        </div>
      )}
    </>
  );
}
